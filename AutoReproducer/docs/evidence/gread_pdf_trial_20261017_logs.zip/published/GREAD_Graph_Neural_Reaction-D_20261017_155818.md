# 论文复现与优化报告
<!-- autoreproducer-report-format: 2 -->

**生成时间**: 2026-10-17 15:58:48
**工具**: AutoReproducer v0.2.0

## 1. 论文信息
- **标题**: GREAD: Graph Neural Reaction-Diffusion Networks
- **方法**: Graph neural reaction-diffusion network (GREAD) with an encoder, a continuous reaction-diffusion layer combining a diffusion term with one of seven reaction terms (Fisher, Allen-Cahn, Zeldovich, Blurring-Sharpening, Source, Filter Bank, Filter Bank*), and an output layer; solved with ODE solvers.
- **数据集**: 
- **声明指标**: {}

- **论文全文阅读**: 完成；75045/75045 字符；1/1 批
- **阅读完成依据**: 连续覆盖全部提取文本，所有批次均返回有效结果；汇总笔记用于定位，实验判定引用原文。

## 2. 资源定位
- **代码仓库**: https://github.com/jeongwhanchoi/GREAD
- **数据集**: 未找到
- **置信度**: 1.00
- **仓库关联证据**: 直接获取并运行所选仓库；不进行论文匹配审核。
- **发现来源**: pinned_git_direct_execution
- **执行范围**: 定位仓库是资源发现结果；是否运行仓库由下方执行对象和实际步骤确认。
- **PDF 仓库来源**: pdf_text，第 5 页
- **原文仓库链接**: https://github.com/jeongwhanchoi/GREAD
- **证据类型**: author_code_statement
- **原文上下文**: eriments We first compare our method with other baselines for node classification tasks. We then discuss the ability of miti- gating oversmoothing on a synthetic graph and show the experiment with different heterophily levels on other syn- thetic graphs. Our code is available at https://github. com/jeongwhanchoi/GREAD . 4.1. Node Classification on Real-world Datasets Real-world Datasets We now evaluate the performance of GREAD and existing GNNs on a variety of real-world dat
- **来源 PDF SHA-256**: `d346cc029d4db2d1994d2dd73afe31e69bace4f5669b62b78652975578bbab7a`
- **从论文中提取URL**: 2 个
  - https://www.wandb.com/
  - https://github.com/jeongwhanchoi/GREAD

## 3. 环境配置
- **Python版本**: N/A
- **依赖数**: 0

### 自动环境恢复

- **运行环境**: 使用兼容的标准 Python 运行预设
- **磁盘统计**: 未测量（安装与执行后读取实际大小，不展示模型估值）

### requirements.txt
```
无
```

## 4. 代码执行
- **执行对象**: 固定版本作者仓库中的实验入口（多文件）
- **执行状态**: ⏳ 未运行（训练尚未开始）

### 官方仓库执行命令


### 执行输出(full)
```
无输出
```

## 5. 运行结果
- **复现状态**: ⚠️ 无法核验（论文证据不足，未执行论文实验）
- **分析**: 无
- **判定原因**: No runnable original author command: README/launchers contain no supported literal Python entrypoint. Author entrypoint 'run_GNN.py' is missing under cwd '.'. Matching pinned inventory paths: ["src/run_GNN.py"]. Read the relevant original source and choose its working directory; do not invent a root-level script.; Author entrypoint 'run_GNN.py' is missing under cwd '.'. Matching pinned inventory paths: ["src/run_GNN.py"]. Read the relevant original source and choose its working directory; do not invent a root-level script.

## 6. 智能优化
- **优化状态**: 未触发(运行已冻结作者实验协议)

## 7. 运行与用量统计
- **总步骤数**: 18
- **成功步数**: 4
- **错误步数**: 1
- **执行时长**: 29.25 秒
- **LLM 调用次数**: 5 （用于用量审计；全文阅读不设总调用预算）

---
*报告由 AutoReproducer 自动生成*

---

> 📎 **完整执行输出附件**: `GREAD_Graph_Neural_Reaction-D_20261017_155818_execution.txt`（同一目录下，未被截断）
