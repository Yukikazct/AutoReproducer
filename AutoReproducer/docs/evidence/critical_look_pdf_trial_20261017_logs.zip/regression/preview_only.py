"""Preview-only real browser regression; never starts a reproduction task."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1] / "AutoReproducer"
sys.path.insert(0, str(ROOT))
from src.pdf_input import extract_pdf_input
from frontend.backend_pipeline import ProgressStore
from playwright.sync_api import sync_playwright

TAG = "issue27_independent_critical_look_20261017_01"
runtime = ROOT / ".tmp/acceptance_pdf_browser_20261017/data/runtime"
pdf = ROOT / "examples/papers/candidates_20261017/critical-look-heterophily.pdf"
expected = "https://github.com/yandex-research/heterophilous-graphs"
digest = hashlib.sha256(pdf.read_bytes()).hexdigest()
assert digest == "9025d1a5a4258bc77dadc31528a68f7abbe6c08c3b9abf82ecb644e00811bd14"
links = list(extract_pdf_input(pdf).repository_links)
assert links[0]["url"] == expected and links[0]["source"] == "pdf_annotation"
assert any(link["url"] == expected[:-4] and link["source"] == "pdf_text" for link in links)
before = set(runtime.glob("progress_*.jsonl"))
originals = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in before}

with sync_playwright() as playwright:
    browser = playwright.chromium.launch(channel="chrome", headless=True)
    try:
        page = browser.new_page(viewport={"width": 1440, "height": 1100})
        page.goto("http://127.0.0.1:8504", wait_until="domcontentloaded")
        page.get_by_role("heading", name="论文复现工作台", exact=True).wait_for(timeout=60000)
        page.get_by_text("上传PDF", exact=True).click()
        page.get_by_test_id("stFileUploader").locator('input[type="file"]').set_input_files(str(pdf))
        label = page.get_by_text(re.compile("PDF 原文代码声明链接：" + re.escape(expected)))
        try:
            label.wait_for(timeout=60000)
        except Exception:
            page.screenshot(path=str(runtime / (TAG + "_preview_regression_failed.png")), full_page=True)
            (runtime / (TAG + "_preview_regression_failed.json")).write_text(
                json.dumps({"body_text": page.locator("body").inner_text(), "task_submitted": False}, ensure_ascii=False, indent=2),
                encoding="utf-8")
            raise
        preview = label.inner_text()
        page.screenshot(path=str(runtime / (TAG + "_preview_regression.png")), full_page=True)
        assert set(runtime.glob("progress_*.jsonl")) == before
        assert all(hashlib.sha256(p.read_bytes()).hexdigest() == d for p, d in originals.items())
        scopes = []
        for path in sorted(before):
            snap = ProgressStore.read_snapshot(str(path))
            counts = [len(snap[key]) for key in ("active_workers", "active_runs", "active_executions")]
            assert counts == [0, 0, 0] and snap["done"]
            scopes.append({"progress_file": path.name, "state": snap["state"], "counts": counts})
        assert hashlib.sha256(pdf.read_bytes()).hexdigest() == digest
        receipt = {"recorded_at": datetime.now(timezone.utc).isoformat(),
                   "kind": "real_browser_preview_regression", "paper_id": "critical-look-heterophily",
                   "product_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
                   "working_diff_sha256": hashlib.sha256(subprocess.check_output(["git", "diff", "--", "src/repository_evidence.py"])).hexdigest(),
                   "independent_claim": False, "task_submitted": False, "training_executed": False,
                   "preview": preview,
                   "no_new_task_created": True, "existing_progress_unchanged": True,
                   "pdf_sha256": digest, "pdf_unchanged": True, "owned_scopes": scopes,
                   "repository_links_after_fix": links}
        (runtime / (TAG + "_preview_regression.json")).write_text(
            json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(receipt, ensure_ascii=False))
    finally:
        browser.close()
