import json, platform, sys
from pathlib import Path
import torch, numpy
root = Path(__file__).resolve().parent
contract = json.loads((root / "config.json").read_text(encoding="utf-8"))["capture"]
record = {"python": sys.version, "platform": platform.platform(),
          "device": contract.get("device", "cpu"), "native_probe_pass": None,
          "status": "prepared", "checks": "disabled",
          "versions": {"torch": torch.__version__, "numpy": numpy.__version__}}
(root / "preflight.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record), flush=True)
