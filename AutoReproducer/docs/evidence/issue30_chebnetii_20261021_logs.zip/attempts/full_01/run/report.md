# 论文复现与优化报告
<!-- autoreproducer-report-format: 2 -->

**生成时间**: 2026-10-21 18:32:26
**工具**: AutoReproducer v0.2.0

## 1. 论文信息
- **标题**: Convolutional Neural Networks on Graphs with Chebyshev Approximation, Revisited
- **方法**: 未知
- **数据集**: 未知
- **声明指标**: {}

## 2. 资源定位
- **代码仓库**: https://github.com/ivam-he/ChebNetII
- **数据集**: 未找到
- **置信度**: 0.00
- **仓库关联证据**: 直接获取并运行所选仓库；不进行论文匹配审核。
- **发现来源**: pinned_git_direct_execution
- **执行范围**: 定位仓库是资源发现结果；是否运行仓库由下方执行对象和实际步骤确认。
- **PDF 仓库来源**: pdf_text，第 1 页
- **原文仓库链接**: https://github.com/ivam-he/ChebNetII
- **证据类型**: author_code_statement
- **原文上下文**: bi- trary graph convolutions and achieve superior performance in both full- and semi- supervised node classification tasks. Most notably, we scale ChebNetII to a billion graph ogbn-papers100M, showing that spectral-based GNNs have superior perfor- mance. Our code is available at https://github.com/ivam-he/ChebNetII . 1 Introduction Graph neural networks \(GNNs\) have received considerable attention in recent years due to their remarkable performance on a variety of graph le
- **来源 PDF SHA-256**: `c32e1ebcd886611ff66293f211e7f1b9e1ffebc6668a4b853de3bc0d2f357e37`

### 官方仓库实验来源
- **实验定义**: 依据本次 PDF 与固定作者源码生成的实验计划
- **论文版本/参考位置**: 
- **固定源码版本**: `ded6c18cbe9673234071031767d17826ad632aca`
- **实验定义SHA-256**: `f005ac5d98fb078c81567b5fb47132322d95448504391286723094a0adafc3d5`
- **独立运行目录**: `D:\code\AutoReproducer\.tmp\issue30_20261021\full_01\data\runs\repository_990cdd52b33841b7b518d94a45e31207`
- **参数**: {}
- **真实数据SHA-256**: `d28b48b278b1660e56908be05b9605fbb6eeb9be4bbe926abcaf63074eb7fc41`
- **数据切分**: 由原文引用冻结的作者实验划分
- **协议说明**: 核验原作者完整命令的实际运行和进程结束；尚未验收论文数值。

- **作者协议来源**: 
- **实现版本说明**: 

### 本次 PDF 与作者源码确定的运行计划

- **运行范围**: 所选作者入口及其原始参数。
- **结束条件**: 全部所选命令正常返回、退出码为 0，所属进程已结束并清理。
- **运行结果**: 记录作者输出和实际训练更新；不进行论文、协议或数值审核。

**原始作者命令**

- train\_cora\_semi\_rnd，目录：main
```json
["python", "training.py", "--net", "ChebNetII", "--dataset", "Cora", "--K", "10", "--prop_lr", "0.001", "--prop_wd", "0.05", "--dprate", "0.8", "--semi_rnd", "True"]
```

## 3. 环境配置
- **Python版本**: N/A
- **依赖数**: 16
- **环境适配**: 基于作者依赖与源码导入选择的项目 CPU 兼容环境；不是论文原始运行环境的等价声明。
- **磁盘统计**: 未测量（安装与执行后读取实际大小，不展示模型估值）

### requirements.txt
```
--extra-index-url https://download.pytorch.org/whl/cpu
--find-links https://data.pyg.org/whl/torch-2.5.0+cpu.html
aiohttp==3.10.10
fsspec==2024.10.0
jinja2==3.1.6
numpy==1.26.4
psutil==6.1.0
pyparsing==3.2.0
requests==2.32.3
scipy==1.14.1
seaborn==0.13.2
torch==2.5.1+cpu
torch-geometric==2.6.1
torch-scatter==2.1.2+pt25cpu
torch-sparse==0.6.18+pt25cpu
tqdm==4.67.1

```

## 4. 代码执行
- **执行对象**: 固定版本作者仓库中的实验入口（多文件）
- **执行状态**: ⏳ 未运行（训练尚未开始）

### 官方仓库执行命令


### 执行输出(full)
```
无输出
```

## 5. 运行结果
- **复现状态**: ⚠️ 无法核验（论文证据不足，未执行论文实验）
- **严格验收**: 未完成；保留普通作者执行结果
- **严格验收说明**: No evidence-bound experiment protocol: Training parameter is unsupported by its source: dprate
- **分析**: 无
- **判定原因**: Strict planning must pass before this acceptance training

## 6. 智能优化
- **优化状态**: 未触发(运行已冻结作者实验协议)

## 7. 运行与用量统计
- **总步骤数**: 11
- **成功步数**: 3
- **错误步数**: 1
- **执行时长**: 27.31 秒
- **LLM 调用次数**: 4 （用于用量审计；全文阅读不设总调用预算）

---
*报告由 AutoReproducer 自动生成*