"""Package explicit, credential-screened issue #30 evidence after a completed run.

This script has no import-time side effects and never imports the API probe.
It writes only to an explicitly supplied local output directory. Publication is
a separate decision: the JSON marks each ZIP eligible only below 20 MiB.

Example (run only after the final run directory has been confirmed):
  python package_evidence.py --final-run <owned run directory> --output <new dir>

Optional --tests-manifest is a JSON list of {path, generation, source_sha256,
command?}. Test batches are reported separately and never summed across versions.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import stat
import sys
import xml.etree.ElementTree as ET
import zipfile


ATTEMPTS = ('planning_02', 'full_01', 'full_02', 'full_03', 'full_04')
ATTEMPT_FILES = ('summary.json', 'request.json', 'source_freeze.json',
                 'strict_candidate.json', 'api_health.json', 'result.json')
RUN_FILES = (
    'experiment_protocol.json', 'experiment_spec.json', 'strict_validation.json',
    'strict_execution_verification.json', 'execution.json', 'execution_plan.json',
    'environment_preparation.json', 'environment_cleanup.json', 'partition_model_audit.json',
    'loader_input_audit.json',
    'result.json', 'report.md', 'adapter_manifest.json', 'dataset.json', 'repository.json',
    'runtime_manifest.json', 'environment.json', 'run_status.json', 'self_repair.json',
    'numeric_repairs.json', 'path_repairs.json', 'pyg_repairs.json',
    'dependency_repairs.json', 'import_repairs.json', 'model_dependency_repairs.json',
    'failure_analyses.json', 'planning_trace.json', 'source_packet.json',
    'strict_rejection_packet.json', 'repository_identity_attempts.json',
    'repository_identity_packet_1.json', 'author_execution_verification.json',
    'author_claim_comparison.json',
)
RUNTIME_FILES = ('config.json', 'capture.json', 'independent_metrics.json',
                 'preflight.json', 'prepared_datasets.json', 'requirements.json')
MODEL_RUNTIME_FILES = ('config.json', 'capture.json', 'independent_metrics.json',
                       'requirements.json', 'runtime.py', 'common.py', 'native_loop.py',
                       'author_values.py', 'split_counts.py',
                       'author_numeric_compatibility.py', 'strict_numeric_compatibility.py')
EXECUTION_FILES = ('execution.json', 'environment.json')
CAPTURE_DIR = '_autorepro_capture'
PUBLISH_LIMIT = 20 * 1024 * 1024
MAX_TEXT_BYTES = 64 * 1024 * 1024
MAX_BINARY_BYTES = 512 * 1024 * 1024
MAX_NESTED_TOTAL = 2 * 1024 * 1024 * 1024
SK_PATTERN = re.compile(rb'(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{16,}(?![A-Za-z0-9_-])')
AUTH_PATTERN = re.compile(rb'(?i)(authorization[\s\"\x27:]*bearer[ \t]+)[A-Za-z0-9._~+/-]{16,}')
STEP_ID = re.compile(r'[A-Za-z][A-Za-z0-9_-]{0,63}')
OWNED_ID = re.compile(r'[0-9a-f]{32}')
HARNESS_FILES = ('probe_planning.py', 'audit_export.py', 'audit_loader_inputs.py',
                 'reverify_saved_run.py', 'package_evidence.py')
FAILED_COMPLETED_AUDIT = 'final_completed_run_audit_failed_01.json'
FAILED_COMPLETED_AUDIT_SHA256 = 'a69811e2eb7271b80989c5e4d1d7eaf0ff0487a18de90dcd62039946c46f79e3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical_sha(value):
    return sha(json.dumps(value, sort_keys=True, ensure_ascii=False,
                          separators=(',', ':'), allow_nan=False).encode('utf-8'))


def archive_name(value):
    if not isinstance(value, str) or not value or '\\' in value or ':' in value:
        raise ValueError('Archive member has an unsafe path')
    path = PurePosixPath(value)
    if (path.is_absolute() or PureWindowsPath(value).drive or value != path.as_posix()
            or any(part in ('', '.', '..', '.git') for part in value.split('/'))):
        raise ValueError('Archive member escaped its explicit path')
    return value


def guarded(root, value, *, directory=False):
    """Reject path escape, symlinks, Windows junctions and hardlinked files."""
    root = Path(root).absolute()
    path = Path(value).absolute()
    if '..' in path.parts or not path.is_relative_to(root):
        raise ValueError('Evidence path escaped its permitted root')
    for current in (path, *path.parents):
        details = current.lstat()
        if stat.S_ISLNK(details.st_mode) or getattr(details, 'st_file_attributes', 0) & 0x400:
            raise ValueError('Evidence path contains a link or junction')
        if current == root:
            break
    if path.resolve(strict=True) != path or root.resolve(strict=True) != root:
        raise ValueError('Evidence path did not resolve to its literal location')
    details = path.stat()
    if directory:
        if not stat.S_ISDIR(details.st_mode):
            raise ValueError('Expected an evidence directory')
    elif not stat.S_ISREG(details.st_mode) or details.st_nlink != 1:
        raise ValueError('Evidence input is not a regular, unlinked file')
    return path


def read_bytes(root, path, *, binary=False):
    path = guarded(root, path)
    before = path.stat()
    limit = MAX_BINARY_BYTES if binary else MAX_TEXT_BYTES
    if before.st_size > limit:
        raise ValueError('An explicitly selected evidence file exceeds its size limit')
    value = path.read_bytes()
    after = path.stat()
    if (len(value) != before.st_size or before.st_size != after.st_size
            or before.st_mtime_ns != after.st_mtime_ns):
        raise ValueError('Evidence changed while being read')
    return value


def read_json(root, path):
    return json.loads(read_bytes(root, path).decode('utf-8-sig'))


def verify_original_inventory(base, run, excluded, expected):
    """Recheck the original run without copying its tree into the archive."""
    if not isinstance(expected, dict) or not expected:
        raise ValueError('Later verification lacks the original run inventory')
    current_names = set()
    for path in run.rglob('*'):
        if excluded is not None and path.is_relative_to(excluded):
            continue
        if path.is_dir():
            guarded(base, path, directory=True)
        else:
            guarded(base, path)
            current_names.add(path.relative_to(run).as_posix())
    if current_names != set(expected):
        raise ValueError('Original run file list changed after later verification')
    for relative, record in expected.items():
        name = PurePosixPath(relative)
        if (not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative
                or name.is_absolute() or relative != name.as_posix()
                or any(part in ('', '.', '..') for part in relative.split('/'))
                or not isinstance(record, dict)):
            raise ValueError('Original run inventory contains an unsafe entry')
        path = run / relative
        if excluded is not None and path.is_relative_to(excluded):
            raise ValueError('Original inventory unexpectedly includes later verification outputs')
        value = read_bytes(base, path, binary=True)
        if len(value) != record.get('bytes') or sha(value) != record.get('sha256'):
            raise ValueError('Original run artifact changed after later verification')
    return {'files': len(expected), 'inventory_sha256': canonical_sha(expected), 'verified': True}


def saved_reverification(base, run, result_path, manifest_path, *, prefix):
    """Bind an additive host recheck to its own unchanged original run."""
    directory = guarded(base, run / 'reverification', directory=True)
    result_path = guarded(base, result_path)
    manifest_path = guarded(base, manifest_path)
    if result_path.parent != directory or manifest_path.parent != directory:
        raise ValueError('Later verification must remain in its original run/reverification directory')
    verified = read_json(base, result_path)
    manifest = read_json(base, manifest_path)
    original = read_json(base, run / 'result.json')
    validation = (verified.get('data', {}).get('validation') or verified.get('validation')
                  or (verified if verified.get('strict_validation') is True else None))
    if (not isinstance(validation, dict) or original.get('state') not in ('ERROR', 'COMPLETED')
            or any(validation.get(key) is not True for key in
                   ('paper_metrics_verified', 'independent_metrics_pass', 'protocol_pass'))):
        raise ValueError('Later verification lacks a complete formal receipt or original terminal result')
    original_result_sha256 = sha(read_bytes(base, run / 'result.json'))
    original_report_sha256 = sha(read_bytes(base, run / 'report.md'))
    if (manifest.get('origin_result_sha256') != original_result_sha256
            or manifest.get('origin_report_sha256') != original_report_sha256
            or manifest.get('verified_result_sha256') != sha(read_bytes(base, result_path))
            or manifest.get('original_pipeline_state') != original.get('state')):
        raise ValueError('Later verification does not bind its unchanged original result and report')
    if (manifest.get('artifacts_unchanged') is not True
            or manifest.get('all_original_run_files_unchanged') is not True
            or manifest.get('training_rerun_after_later_changes') is not False
            or manifest.get('full_pipeline_rerun_after_later_changes') is not False):
        raise ValueError('Offline recheck must attest no training or original-artifact modification in that operation')
    inventory = verify_original_inventory(base, run, directory, manifest.get('original_files'))
    source_freeze_path = guarded(base, manifest['verifier_source_freeze_path'])
    source_freeze = read_json(base, source_freeze_path)
    if (source_freeze_path.parent != directory
            or canonical_sha(source_freeze['files']) != source_freeze.get('source_sha256')
            or source_freeze.get('source_sha256') != manifest.get('verifier_source_sha256')):
        raise ValueError('Later verifier lacks its own matching frozen source generation')
    training_freeze = read_json(base, run.parents[2] / 'source_freeze.json')
    if (training_freeze.get('source_sha256') != canonical_sha(training_freeze['files'])
            or manifest.get('training_source_sha256') != training_freeze['source_sha256']
            or manifest.get('spec_sha256') != read_json(base, run / 'experiment_spec.json')['sha256']):
        raise ValueError('Later verification changed the original training source or frozen spec')
    formal_path = guarded(base, directory / 'strict_execution_verification.json')
    if (manifest.get('strict_execution_verification_sha256') != sha(read_bytes(base, formal_path))
            or read_json(base, formal_path) != validation
            or sha(read_bytes(base, directory / 'original_report_copy.md')) != original_report_sha256):
        raise ValueError('Later formal receipt or preserved report copy differs from its bound record')
    report_path = guarded(base, manifest['report_revision_path'])
    if (not report_path.is_relative_to(directory)
            or manifest.get('report_revision_sha256') != sha(read_bytes(base, report_path))):
        raise ValueError('Later report revision differs from its recorded digest or output directory')
    files = [(result_path, prefix + '/verified_result.json'),
             (manifest_path, prefix + '/manifest.json'),
             (source_freeze_path, prefix + '/verifier_source_freeze.json'),
             (formal_path, prefix + '/strict_execution_verification.json'),
             (directory / 'reverification_input.json', prefix + '/reverification_input.json'),
             (directory / 'original_report_copy.md', prefix + '/original_report_copy.md'),
             (report_path, prefix + '/report_revision.md'),
             (report_path.parent / 'current.json', prefix + '/report_rendering_manifest.json')]
    metadata = {'scope': 'Offline host recheck of its original completed training and independent inference',
        'attempt': run.parents[2].name, 'run_dir': str(run), 'artifact_prefix': prefix,
        'original_pipeline_state': original['state'],
        'offline_pipeline_state': verified.get('state'),
        'result_artifact': prefix + '/verified_result.json', 'manifest_artifact': prefix + '/manifest.json',
        'report_revision_artifact': prefix + '/report_revision.md',
        'result_sha256': sha(read_bytes(base, result_path)), 'manifest_sha256': sha(read_bytes(base, manifest_path)),
        'origin_result_sha256': original_result_sha256, 'origin_report_sha256': original_report_sha256,
        'report_revision_sha256': sha(read_bytes(base, report_path)),
        'original_inventory_verified_at_packaging': inventory,
        'training_source_sha256': training_freeze['source_sha256'],
        'verifier_source_sha256': source_freeze['source_sha256'], 'spec_sha256': manifest['spec_sha256'],
        'artifacts_unchanged': True, 'training_executed_by_this_reverification': False,
        'pipeline_reexecuted_by_this_reverification': False,
        'strict_result': {key: validation.get(key) for key in
                          ('status', 'is_reproduced', 'paper_metrics_verified', 'comparisons', 'completion_checks')}}
    return {'metadata': metadata, 'validation': validation, 'source_freeze': source_freeze, 'files': files}


def add_saved_reverification(evidence, record):
    for path, member in record['files']:
        evidence.add(path, member, required=True)


def completed_run_audit(base, run, training_source, current_source, spec_sha256, historical):
    """Verify the externally saved complete-run audit against current evidence."""
    report_path = guarded(base, base / 'final_completed_run_audit.json')
    script_path = guarded(base, base / 'audit_completed_run.py')
    report = read_json(base, report_path)
    if (report.get('version') != 1 or report.get('pass') is not True
            or report.get('scope') != 'direct_completed_pdf_pipeline_audit'
            or guarded(base, report['run_dir'], directory=True) != run
            or report.get('spec_sha256') != spec_sha256
            or report.get('source_sha256') != current_source
            or report.get('training_source_sha256') != training_source
            or training_source != current_source
            or report.get('source_freeze_sha256') != sha(read_bytes(base, run.parents[2] / 'source_freeze.json'))
            or report.get('script_sha256') != sha(read_bytes(base, script_path))
            or report.get('run_files_unchanged') is not True):
        raise ValueError('Complete-run audit does not bind this completed run, spec and unchanged product source')
    expected = report.get('original_run_files')
    inventory = verify_original_inventory(base, run, None, expected)
    if (report.get('run_files_before_sha256') != inventory['inventory_sha256']
            or report.get('run_files_after_sha256') != inventory['inventory_sha256']):
        raise ValueError('Complete-run audit inventory differs from current original run files')
    runtime = run / 'repo' / CAPTURE_DIR
    receipt_hashes = {key + '_sha256': sha(read_bytes(base, runtime / (key + '.json')))
                      for key in ('config', 'capture', 'independent_metrics')}
    bindings = report.get('additional_audits')
    if not isinstance(bindings, dict) or set(bindings) != {'partition_model_audit.json', 'loader_input_audit.json'}:
        raise ValueError('Complete-run audit does not bind both additional audit receipts')
    for name, script in (('partition_model_audit.json', 'audit_export.py'),
                         ('loader_input_audit.json', 'audit_loader_inputs.py')):
        binding = bindings[name]
        additional = read_json(base, run / name)
        if (binding.get('sha256') != sha(read_bytes(base, run / name)) or binding.get('script') != script
                or binding.get('script_sha256') != sha(read_bytes(base, base / script))
                or binding.get('audit_pid') != additional.get('audit_pid')
                or additional.get('script_sha256') != binding.get('script_sha256')
                or any(binding.get(key) != value or additional.get(key) != value
                       for key, value in receipt_hashes.items())):
            raise ValueError('Complete-run additional audit binding changed before packaging')
    history = report.get('history')
    if not isinstance(history, dict) or historical is None:
        raise ValueError('Complete-run audit lacks the separate historical failure/offline recheck binding')
    if (guarded(base, history['run_dir'], directory=True) != Path(historical['run_dir'])
            or history.get('original_pipeline_state') != historical['original_pipeline_state']
            or history.get('offline_pipeline_state') != historical['offline_pipeline_state']
            or history.get('original_result_sha256') != historical['origin_result_sha256']
            or history.get('original_report_sha256') != historical['origin_report_sha256']
            or history.get('offline_manifest_sha256') != historical['manifest_sha256']
            or history.get('offline_result_sha256') != historical['result_sha256']
            or history.get('training_source_sha256') != historical['training_source_sha256']
            or history.get('verifier_source_sha256') != historical['verifier_source_sha256']
            or history.get('original_files_unchanged') is not True
            or history.get('historical_offline_only') is not True):
        raise ValueError('Complete-run audit historical boundary differs from the archived original/offline evidence')
    metadata = {'scope': report['scope'], 'pass': True, 'run_dir': str(run),
        'report_artifact': 'final_completed_run_audit.json',
        'script_artifact': 'harness_sources/audit_completed_run.py',
        'report_sha256': sha(read_bytes(base, report_path)), 'script_sha256': report['script_sha256'],
        'spec_sha256': spec_sha256, 'source_sha256': current_source,
        'training_source_sha256': training_source, 'original_inventory_verified_at_packaging': inventory,
        'additional_audit_bindings_verified': True, 'historical_boundary_verified': True}
    return {'metadata': metadata, 'report': report, 'report_path': report_path, 'script_path': script_path}


def screen(data, *, binary=False):
    """Never report the matched value; binary artifacts cannot be redacted."""
    if binary:
        if SK_PATTERN.search(data) or AUTH_PATTERN.search(data):
            raise ValueError('Credential pattern detected in a binary artifact; packaging stopped')
        return data, 0
    data.decode('utf-8-sig', errors='strict')
    value, count = SK_PATTERN.subn(b'[REDACTED]', data)
    value, authorizations = AUTH_PATTERN.subn(rb'\1[REDACTED]', value)
    return value, count + authorizations


def inspect_zip_payload(data, *, depth=0, budget=None):
    """Inspect TorchScript/torch.save nested ZIPs without extracting them."""
    screen(data, binary=True)
    budget = [MAX_NESTED_TOTAL, 100000] if budget is None else budget
    stream = io.BytesIO(data)
    if not zipfile.is_zipfile(stream):
        return
    if depth >= 3:
        raise ValueError('Unexpected deeply nested ZIP in evidence')
    with zipfile.ZipFile(stream) as archive:
        seen = set()
        for info in archive.infolist():
            name = archive_name(info.filename.rstrip('/'))
            if name.casefold() in seen:
                raise ValueError('Nested ZIP contains duplicate members')
            seen.add(name.casefold())
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode) or info.flag_bits & 1:
                raise ValueError('Nested ZIP contains a link or encrypted member')
            if mode and stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError('Nested ZIP contains a nonregular member')
            if info.is_dir():
                continue
            budget[0] -= info.file_size
            budget[1] -= 1
            if budget[0] < 0 or budget[1] < 0 or info.file_size > MAX_BINARY_BYTES:
                raise ValueError('Nested ZIP exceeds inspection limits')
            inspect_zip_payload(archive.read(info), depth=depth + 1, budget=budget)


@dataclass(frozen=True)
class Entry:
    path: Path | None
    name: str
    binary: bool = False
    generated: bytes | None = None
    expected_sha256: str | None = None


class Evidence:
    def __init__(self, root):
        self.root = root
        self.entries = []
        self.missing = []
        self.names = set()

    def add(self, path, name, *, required=False, binary=False, expected=None):
        name = archive_name(name)
        path = Path(path)
        # lstat catches dangling links; exists() alone would hide them.
        try:
            path.lstat()
        except FileNotFoundError:
            if required:
                raise ValueError('A required evidence file is missing: ' + name)
            self.missing.append(name)
            return
        guarded(self.root, path)
        if name.casefold() in self.names:
            raise ValueError('Duplicate selected evidence member')
        self.names.add(name.casefold())
        self.entries.append(Entry(path, name, binary, expected_sha256=expected))

    def generated(self, name, value):
        name = archive_name(name)
        if name.casefold() in self.names:
            raise ValueError('Duplicate generated evidence member')
        self.names.add(name.casefold())
        self.entries.append(Entry(None, name, generated=json.dumps(
            value, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')))


def write_archive(evidence, output):
    if output.exists():
        raise ValueError('Refusing to overwrite an existing evidence ZIP')
    temporary = output.with_suffix(output.suffix + '.tmp')
    if temporary.exists():
        raise ValueError('A previous temporary evidence ZIP already exists')
    records = []
    try:
        with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, allowZip64=True) as archive:
            for entry in evidence.entries:
                raw = (entry.generated if entry.generated is not None else
                       read_bytes(evidence.root, entry.path, binary=entry.binary))
                original_sha256 = sha(raw)
                if entry.expected_sha256 is not None and original_sha256 != entry.expected_sha256:
                    raise ValueError('Model/tensor SHA does not match its captured receipt')
                value, redactions = screen(raw, binary=entry.binary)
                if entry.binary:
                    inspect_zip_payload(value)
                info = zipfile.ZipInfo(entry.name)
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o600) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, value, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
                records.append({'path': entry.name, 'bytes': len(value), 'sha256': sha(value),
                                'original_bytes': len(raw), 'original_sha256': original_sha256,
                                'redactions': redactions})
            manifest = json.dumps({'version': 1, 'members': records,
                'manifest_excludes_itself': True}, ensure_ascii=False, indent=2).encode('utf-8')
            info = zipfile.ZipInfo('archive_member_manifest.json')
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o600) << 16
            archive.writestr(info, manifest, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            records.append({'path': info.filename, 'bytes': len(manifest), 'sha256': sha(manifest),
                            'original_bytes': len(manifest), 'original_sha256': sha(manifest), 'redactions': 0})
        with zipfile.ZipFile(temporary) as archive:
            if len(archive.infolist()) != len(records):
                raise ValueError('Final ZIP member count changed')
            for info, record in zip(archive.infolist(), records):
                archive_name(info.filename)
                value = archive.read(info)
                if (info.filename != record['path'] or sha(value) != record['sha256']
                        or stat.S_ISLNK(info.external_attr >> 16)):
                    raise ValueError('Final ZIP member integrity failed')
                screen(value, binary=True)
        temporary.rename(output)
    except BaseException:
        if temporary.exists():
            temporary.unlink()
        raise
    payload = read_bytes(evidence.root, output, binary=True)
    size = len(payload)
    return {'path': output.name, 'bytes': size, 'sha256': sha(payload), 'members': records,
            'publish_eligible_below_20_mib': size < PUBLISH_LIMIT,
            'publication': 'eligible_for_docs_review' if size < PUBLISH_LIMIT else 'local_only_manifest_in_docs',
            'credential_patterns_screened': ['sk-token', 'authorization-bearer'],
            'links_path_escape_and_nested_zip_checked': True}


def find_run(base, attempt):
    root = base / attempt
    summary = root / 'summary.json'
    if summary.is_file():
        named = read_json(base, summary).get('run_dir')
        if named:
            selected = guarded(base, named, directory=True)
            if selected.parent != root / 'data' / 'runs':
                raise ValueError('Attempt summary names another attempt or location')
            return selected
    runs = root / 'data' / 'runs'
    if not runs.exists():
        return None
    guarded(base, runs, directory=True)
    selected = [path for path in runs.iterdir() if path.name.startswith('repository_')]
    if len(selected) != 1:
        raise ValueError('Attempt run discovery is ambiguous: ' + attempt)
    return guarded(base, selected[0], directory=True)


def add_run(evidence, run, prefix):
    for name in RUN_FILES:
        evidence.add(run / name, prefix + '/run/' + name)
    runtime = run / 'repo' / CAPTURE_DIR
    for name in RUNTIME_FILES:
        evidence.add(runtime / name, prefix + '/runtime/' + name)
    identifiers = {'train', 'native_preflight', 'prepare_author_datasets', 'independent_evaluation'}
    for filename in ('execution_plan.json', 'experiment_spec.json'):
        path = run / filename
        if path.is_file():
            plan = read_json(evidence.root, path)
            plan = plan.get('spec', plan)
            for step in plan.get('steps', []):
                identifier = step.get('id')
                if not isinstance(identifier, str) or not STEP_ID.fullmatch(identifier):
                    raise ValueError('Frozen step ID is unsafe')
                identifiers.add(identifier)
    for identifier in sorted(identifiers):
        for kind in ('numeric', 'path', 'pyg'):
            name = kind + '_failure_' + identifier + '.json'
            evidence.add(runtime / name, prefix + '/runtime/' + name)
    owned = run / '.autorepro_repository_runs'
    if not owned.exists():
        return []
    guarded(evidence.root, owned, directory=True)
    owned_records = []
    for directory in sorted(owned.iterdir()):
        if not OWNED_ID.fullmatch(directory.name):
            raise ValueError('Unexpected entry in the owned execution directory')
        guarded(evidence.root, directory, directory=True)
        record_prefix = prefix + '/owned/' + directory.name
        for name in EXECUTION_FILES:
            evidence.add(directory / name, record_prefix + '/' + name)
        steps = []
        execution_path = directory / 'execution.json'
        execution = read_json(evidence.root, execution_path) if execution_path.is_file() else {}
        for step in execution.get('steps', []):
            identifier = step.get('id')
            if not isinstance(identifier, str) or not STEP_ID.fullmatch(identifier):
                raise ValueError('Owned execution step ID is unsafe')
            identifiers.add(identifier)
            steps.append({key: step.get(key) for key in
                          ('id', 'executed', 'success', 'exit_code', 'timed_out', 'cancelled')})
        for identifier in sorted(identifiers):
            for suffix in ('.json', '.stdout.log', '.stderr.log'):
                name = identifier + suffix
                evidence.add(directory / name, record_prefix + '/' + name)
        evidence.add(directory / 'environment_prepare' / 'pip-progress.log',
                     record_prefix + '/environment_prepare/pip-progress.log')
        owned_records.append({'execution_id': directory.name, 'success': execution.get('success'),
                              'steps': steps, 'artifact_prefix': record_prefix})
    return owned_records


def product_freeze(app):
    paths = [app / 'app.py']
    for name in ('src', 'frontend'):
        # Hashes only: none of these recursive product files is archived.
        paths.extend(path for path in (app / name).rglob('*')
                     if path.is_file() and '__pycache__' not in path.parts)
    paths.extend(app.glob('requirements*.txt'))
    paths.extend(app / 'scripts' / name for name in
                 ('freeze_holdout_source.py', 'verify_browser_pdf_holdout.py'))
    files = {path.relative_to(app).as_posix(): sha(read_bytes(app, path)) for path in sorted(paths)}
    return {'source_sha256': canonical_sha(files), 'files': files}


def parse_test_batch(base, record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = base / path
    path = guarded(base, path)
    generation = record.get('generation')
    fingerprint = record.get('source_sha256')
    if not isinstance(generation, str) or not generation.strip():
        raise ValueError('Each test batch needs its own explicit generation label')
    if fingerprint is not None and not re.fullmatch('[0-9a-f]{64}', fingerprint):
        raise ValueError('Test batch source fingerprint is invalid')
    document = ET.fromstring(read_bytes(base, path))
    cases = list(document.iter('testcase'))
    counts = {key: 0 for key in ('failures', 'errors', 'skipped')}
    passed = 0
    for case in cases:
        statuses = [key for key, tag in (('failures', 'failure'), ('errors', 'error'), ('skipped', 'skipped'))
                    if case.find(tag) is not None]
        for status in statuses:
            counts[status] += 1
        passed += not statuses
    return {'path': path.relative_to(base).as_posix(), 'generation': generation,
            'source_sha256': fingerprint, 'source_binding': 'explicit' if fingerprint else 'unbound_do_not_claim_final',
            'command': record.get('command'), 'tests': len(cases), 'passed': passed, **counts,
            'duration_seconds': sum(float(case.get('time', '0')) for case in cases),
            'not_aggregated_with_other_generations': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='New directory inside this local task folder')
    parser.add_argument('--tests-manifest', type=Path)
    parser.add_argument('--offline-report-v3-manifest', type=Path,
                        help='Explicit manifest for the separately rebuilt offline report')
    parser.add_argument('--offline-report-v3', type=Path,
                        help='Exact rebuilt offline report; supplied together with its manifest')
    parser.add_argument('--reverified-result', type=Path,
                        help='Later formal host verification result; does not replace the original pipeline result')
    parser.add_argument('--reverification-manifest', type=Path,
                        help='Manifest binding later host verification to original result, spec and verifier source')
    parser.add_argument('--historical-reverified-result', type=Path,
                        help='Separate full_03 offline recheck preserved when the selected run is a later attempt')
    parser.add_argument('--historical-reverification-manifest', type=Path,
                        help='Original-result/source binding for the separate historical full_03 recheck')
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    repository = base.parents[1]
    app = repository / 'AutoReproducer'
    final = guarded(base, args.final_run, directory=True)
    output = args.output.absolute()
    if not output.is_relative_to(base) or output == base or output.exists():
        raise ValueError('Output must be a new local directory inside this task folder')
    if any(output.is_relative_to(base / attempt) for attempt in (*ATTEMPTS, 'planning_01')):
        raise ValueError('Output must remain outside every preserved attempt tree')
    guarded(base, output.parent, directory=True)
    final_attempt = next((name for name in final.relative_to(base).parts if name in ATTEMPTS), None)
    if final_attempt is None:
        raise ValueError('Final run must belong to an explicitly listed attempt')
    if (final.parent != base / final_attempt / 'data' / 'runs'
            or not re.fullmatch(r'repository_[0-9a-f]{32}', final.name)):
        raise ValueError('Final run is not an exact owned repository run')
    if bool(args.reverified_result) != bool(args.reverification_manifest):
        raise ValueError('Later verification result and its manifest must be provided together')
    if bool(args.historical_reverified_result) != bool(args.historical_reverification_manifest):
        raise ValueError('Historical offline result and manifest must be provided together')
    if final_attempt == 'full_04' and not args.historical_reverified_result:
        raise ValueError('The full_04 evidence must preserve the explicit historical full_03 offline recheck')
    for name in ('experiment_protocol.json', 'experiment_spec.json',
                 'execution.json', 'environment_cleanup.json',
                 'partition_model_audit.json', 'loader_input_audit.json',
                 'result.json', 'report.md', 'adapter_manifest.json'):
        guarded(base, final / name)
    if args.reverified_result is None:
        guarded(base, final / 'strict_validation.json')
        guarded(base, final / 'strict_execution_verification.json')
    final_summary = read_json(base, base / final_attempt / 'summary.json')
    result = read_json(base, final / 'result.json')
    data = result.get('data', {})
    original_validation = data.get('validation') or {}
    validation = original_validation
    reverification = None
    selected_reverification = None
    if args.reverified_result:
        selected_reverification = saved_reverification(
            base, final, args.reverified_result, args.reverification_manifest, prefix='reverification')
        reverification = selected_reverification['metadata']
        validation = selected_reverification['validation']
    historical_reverification = None
    if args.historical_reverified_result:
        history_result_path = guarded(base, args.historical_reverified_result)
        history_run = guarded(base, history_result_path.parent.parent, directory=True)
        if (history_run == final or history_run.parent != base / 'full_03' / 'data' / 'runs'
                or not re.fullmatch(r'repository_[0-9a-f]{32}', history_run.name)):
            raise ValueError('Historical offline recheck must belong to a distinct owned full_03 run')
        historical_reverification = saved_reverification(
            base, history_run, history_result_path, args.historical_reverification_manifest,
            prefix='historical_reverification/full_03')
    cleanup = read_json(base, final / 'environment_cleanup.json')
    if (validation.get('paper_metrics_verified') is not True
            or validation.get('independent_metrics_pass') is not True
            or validation.get('protocol_pass') is not True):
        raise ValueError('Selected strict verification receipt is incomplete')
    if reverification is None:
        if final_summary.get('state') != 'COMPLETED' or result.get('state') != 'COMPLETED':
            raise ValueError('Original pipeline did not complete and no later host verification was supplied')
        if read_json(base, final / 'strict_execution_verification.json') != validation:
            raise ValueError('Selected original result differs from its formal strict verification receipt')
    elif (final_summary.get('state') not in ('ERROR', 'COMPLETED')
          or result.get('state') not in ('ERROR', 'COMPLETED')):
        raise ValueError('Later host verification cannot substitute for an unfinished original pipeline')
    if cleanup.get('status') != 'released' or cleanup.get('remaining') or cleanup.get('errors'):
        raise ValueError('Final environment cleanup is incomplete')
    runtime = final / 'repo' / CAPTURE_DIR
    capture = read_json(base, runtime / 'capture.json')
    metrics = read_json(base, runtime / 'independent_metrics.json')
    config = read_json(base, runtime / 'config.json')
    audit = read_json(base, final / 'partition_model_audit.json')
    loader_audit = read_json(base, final / 'loader_input_audit.json')
    if (capture.get('pass') is not True or metrics.get('pass') is not True or audit.get('pass') is not True
            or capture.get('spec_sha256') != metrics.get('spec_sha256')
            or capture.get('spec_sha256') != config.get('spec_sha256')
            or audit.get('spec_sha256') != config.get('spec_sha256')):
        raise ValueError('Final capture, metric and partition evidence do not reconcile')
    if metrics.get('capture_sha256') != sha(read_bytes(base, runtime / 'capture.json')):
        raise ValueError('Independent metric receipt does not bind the captured artifacts')
    if (loader_audit.get('pass') is not True or loader_audit.get('repository_files_unchanged') is not True
            or loader_audit.get('spec_sha256') != config.get('spec_sha256')
            or loader_audit.get('capture_sha256') != sha(read_bytes(base, runtime / 'capture.json'))
            or loader_audit.get('independent_metrics_sha256') != sha(read_bytes(base, runtime / 'independent_metrics.json'))
            or len(loader_audit.get('runs', [])) != config['capture']['expected_runs']
            or any(row.get('exact_loader_match') is not True for row in loader_audit.get('runs', []))):
        raise ValueError('Exact original author loader input audit is incomplete or inconsistent')
    if reverification is not None and reverification['spec_sha256'] != config.get('spec_sha256'):
        raise ValueError('Later host verification used another frozen experiment spec')
    process_ids = [capture.get('process_pid'), metrics.get('process_pid'), audit.get('audit_pid')]
    if (any(type(value) is not int or value <= 0 for value in process_ids)
            or len(set(process_ids)) != 3
            or metrics.get('capture_process_pid') != capture['process_pid']):
        raise ValueError('Training and independent verification processes are not distinct')
    training_freeze = read_json(base, base / final_attempt / 'source_freeze.json')
    if canonical_sha(training_freeze['files']) != training_freeze['source_sha256']:
        raise ValueError('Training source freeze has an invalid fingerprint')
    current_freeze = product_freeze(app)
    changed = [name for name in sorted(set(training_freeze['files']) | set(current_freeze['files']))
               if training_freeze['files'].get(name) != current_freeze['files'].get(name)]
    logs, artifacts = Evidence(base), Evidence(base)
    for name in HARNESS_FILES:
        logs.add(base / name, 'harness_sources/' + name, required=True)
    final_run_audit = None
    failed_completed_audit_harness = None
    if final_attempt == 'full_04':
        final_run_audit = completed_run_audit(
            base, final, training_freeze['source_sha256'], current_freeze['source_sha256'], config['spec_sha256'],
            historical_reverification['metadata'] if historical_reverification else None)
        logs.add(final_run_audit['script_path'], 'harness_sources/audit_completed_run.py', required=True,
                 expected=final_run_audit['metadata']['script_sha256'])
        logs.add(final_run_audit['report_path'], 'final_completed_run_audit.json', required=True,
                 expected=final_run_audit['metadata']['report_sha256'])
        failed_path = guarded(base, base / FAILED_COMPLETED_AUDIT)
        failed = read_json(base, failed_path)
        if (sha(read_bytes(base, failed_path)) != FAILED_COMPLETED_AUDIT_SHA256
                or failed.get('pass') is not False
                or failed.get('error') != {'type': 'ValueError', 'message': 'Official result uses another frozen specification'}
                or guarded(base, failed['run_dir'], directory=True) != final
                or failed.get('source_sha256') != training_freeze['source_sha256']
                or failed.get('run_files_unchanged') is not True
                or final_run_audit['metadata']['pass'] is not True):
            raise ValueError('Explicit failed harness audit differs from its known immutable schema-error evidence')
        failed_member = 'harness/' + FAILED_COMPLETED_AUDIT
        logs.add(failed_path, failed_member, required=True, expected=FAILED_COMPLETED_AUDIT_SHA256)
        failed_completed_audit_harness = {
            'attempt': 'completed_run_audit_failed_01', 'classification': 'harness_schema_validation_error',
            'related_pipeline_attempt': final_attempt, 'artifact': failed_member,
            'artifact_sha256': FAILED_COMPLETED_AUDIT_SHA256, 'audit_pass': False,
            'error_type': 'ValueError', 'product_training_failure': False, 'product_pipeline_failure': False,
            'original_run_files_unchanged': True,
            'failed_audit_script_sha256': failed.get('script_sha256'),
            'failed_audit_script_source_archived': False,
            'superseding_successful_audit_artifact': 'final_completed_run_audit.json',
            'superseding_successful_audit_pass': True,
            'classification_source': 'Maintainer and audit author confirmed the temporary checker compared the UI specification to the raw grounded plan; the corrected audit checks grounded_repository_plan.',
            'note': 'The immutable failed checker report is preserved as harness evidence. The official full_04 pipeline result and report were not changed by this correction.'}
    # Only these explicitly named source bundles are selected. No source tree,
    # credential helper, environment or dependency directory is copied.
    source_archives = []
    source_a_verification = read_json(base, base / 'full_03_training_sources_verification.json')
    if source_a_verification.get('source_sha256') != read_json(
            base, base / 'full_03' / 'source_freeze.json')['source_sha256']:
        raise ValueError('Source A bundle does not bind the recorded training generation')
    combined_freeze_path = base / 'final_series_report_candidate_source_freeze.json'
    combined_freeze = read_json(base, combined_freeze_path)
    combined_verification = read_json(base, base / 'final_series_report_candidate_verification.json')
    if (combined_freeze.get('archive_sha256') != combined_verification.get('source_archive_sha256')
            or combined_verification.get('all_frozen_files_unchanged_after_test') is not True
            or combined_verification.get('freeze_manifest_sha256') != sha(read_bytes(base, combined_freeze_path))):
        raise ValueError('Source B combined manifest does not bind its verified test inventory')
    source_b_freeze_path = base / 'final_verifier_product_source_freeze.json'
    source_b_freeze = read_json(base, source_b_freeze_path)
    source_b_verification = read_json(base, base / 'final_verifier_product_sources_verification.json')
    if (source_b_freeze.get('source_sha256') != canonical_sha(source_b_freeze['files'])
            or source_b_verification.get('source_sha256') != source_b_freeze['source_sha256']
            or source_b_verification.get('source_freeze_sha256') != sha(read_bytes(base, source_b_freeze_path))
            or source_b_verification.get('combined_manifest_sha256') != sha(read_bytes(base, combined_freeze_path))
            or source_b_verification.get('combined_inventory_sha256') != canonical_sha(combined_freeze['files'])
            or source_b_verification.get('all_production_members_match_combined_357_freeze') is not True
            or source_b_verification.get('all_archive_member_hashes_verified') is not True
            or any(combined_freeze['files'].get(name) != value for name, value in source_b_freeze['files'].items())):
        raise ValueError('Source B product archive does not bind the tested production inventory')
    if reverification is not None and source_b_freeze['source_sha256'] != reverification['verifier_source_sha256']:
        raise ValueError('Source B product archive differs from the later formal host verifier generation')
    if (historical_reverification is not None
            and historical_reverification['metadata']['verifier_source_sha256'] != source_b_freeze['source_sha256']):
        raise ValueError('Source B product archive differs from the historical full_03 host verifier generation')
    generations = {source_a_verification['source_sha256']: 'A', source_b_freeze['source_sha256']: 'B'}
    if training_freeze['source_sha256'] not in generations:
        raise ValueError('Selected training source has no explicitly archived production generation')
    selected_generation = generations[training_freeze['source_sha256']]
    if final_attempt == 'full_04' and selected_generation != 'B':
        raise ValueError('The selected full_04 run was not frozen from the corrected source B')
    for label, archive, manifest, verification, expected, inventory in (
        ('A_training_product', 'full_03_training_sources.zip', 'full_03/source_freeze.json',
         'full_03_training_sources_verification.json', source_a_verification['archive_sha256'],
         read_json(base, base / 'full_03' / 'source_freeze.json')['files']),
        ('B_corrected_product', 'final_verifier_product_sources.zip',
         'final_verifier_product_source_freeze.json', 'final_verifier_product_sources_verification.json',
         source_b_verification['archive_sha256'], source_b_freeze['files']),
    ):
        logs.add(base / archive, 'source_bundles/' + archive, required=True, binary=True, expected=expected)
        logs.add(base / manifest, 'source_bundles/' + label + '_source_freeze.json', required=True)
        logs.add(base / verification, 'source_bundles/' + label + '_verification.json', required=True)
        source_archives.append({'generation': label, 'artifact': 'source_bundles/' + archive,
            'archive_sha256': expected, 'files': len(inventory), 'inventory_sha256': canonical_sha(inventory),
            'inventory_scope': 'product_only', 'product_source_sha256': canonical_sha(inventory),
            'product_hash_and_product_inventory_hash_are_equal': True,
            'selected_training_generation': canonical_sha(inventory) == training_freeze['source_sha256'],
            'combined_product_and_tests_hash_must_be_kept_separate': True})
    # The immutable combined archive contains synthetic credential fixtures in
    # test sources. Keep that original archive local; do not redact it, bypass
    # the scanner, or place its bytes in the publication candidate.
    combined_archive = guarded(base, base / 'final_series_report_candidate_sources.zip')
    combined_archive_sha256 = sha(read_bytes(base, combined_archive, binary=True))
    if combined_archive_sha256 != combined_freeze['archive_sha256']:
        raise ValueError('Local-only combined source archive does not match its frozen digest')
    logs.add(combined_freeze_path, 'source_bundles/B_product_and_tests_source_freeze.json', required=True)
    logs.add(base / 'final_series_report_candidate_verification.json',
             'source_bundles/B_product_and_tests_verification.json', required=True)
    source_archives.append({'generation': 'B_product_and_tests_inventory', 'artifact': None,
        'local_archive_path': combined_archive.relative_to(base).as_posix(),
        'archive_sha256': combined_archive_sha256, 'archive_bytes': combined_archive.stat().st_size,
        'files': len(combined_freeze['files']), 'inventory_sha256': canonical_sha(combined_freeze['files']),
        'inventory_scope': 'product_and_tests', 'publication': 'local_only_not_archived',
        'manifest_artifact': 'source_bundles/B_product_and_tests_source_freeze.json',
        'verification_artifact': 'source_bundles/B_product_and_tests_verification.json',
        'archive_exclusion_reason': 'Original immutable test-source archive includes synthetic credential fixture tokens; no scanner exemption or rewritten archive.',
        'inventory_hash_is_not_interchangeable_with_product_hash': True})
    logs.generated('source_bundle_index.json', source_archives)
    if selected_reverification is not None:
        add_saved_reverification(logs, selected_reverification)
    if historical_reverification is not None:
        add_saved_reverification(logs, historical_reverification)
    harness_attempts = []
    if failed_completed_audit_harness is not None:
        harness_attempts.append(failed_completed_audit_harness)
    harness = base / 'planning_01'
    if harness.exists():
        guarded(base, harness, directory=True)
        for name in ATTEMPT_FILES:
            logs.add(harness / name, 'harness/planning_01/' + name)
        harness_run = find_run(base, 'planning_01')
        harness_owned = add_run(logs, harness_run, 'harness/planning_01') if harness_run else []
        harness_attempts.append({'attempt': 'planning_01', 'classification': 'harness_argument_error',
            'classification_source': 'Maintainer confirmed harness parameter misuse before the actual attempt series',
            'terminal_summary_present': (harness / 'summary.json').is_file(),
            'owned_run_present': harness_run is not None, 'owned_executions': harness_owned,
            'product_training_failure': False,
            'note': 'Existing source freeze, API health and request records are preserved; absent summary is not a product training result.'})
    attempts = []
    for label in ATTEMPTS:
        root = base / label
        if not root.exists():
            if label == 'full_04':
                attempts.append({'attempt': label, 'state': 'not_present_at_packaging',
                                 'training_executed': None, 'source_sha256': None})
                continue
            raise ValueError('Expected attempt directory is missing: ' + label)
        guarded(base, root, directory=True)
        for name in ATTEMPT_FILES:
            logs.add(root / name, 'attempts/' + label + '/' + name,
                     required=name in ('request.json', 'source_freeze.json'))
        run = find_run(base, label)
        summary = read_json(base, root / 'summary.json') if (root / 'summary.json').is_file() else {}
        frozen = read_json(base, root / 'source_freeze.json')
        owned = add_run(logs, run, 'attempts/' + label) if run else []
        attempts.append({'attempt': label, 'state': summary.get('state', 'summary_missing'),
                         'training_executed': summary.get('training_executed'),
                         'strict_status': (summary.get('strict_validation') or {}).get('status'),
                         'source_sha256': frozen.get('source_sha256'), 'owned_executions': owned,
                         'artifact_prefix': 'attempts/' + label})
    tests_manifest = read_json(base, args.tests_manifest) if args.tests_manifest else []
    if args.tests_manifest is None:
        if (base / 'plan_replay.xml').is_file():
            tests_manifest.append({'path': 'plan_replay.xml',
                'generation': 'Full_03 frozen generation; planning replay after strict dependency audit repair',
                'source_sha256': read_json(base, base / 'full_03' / 'source_freeze.json')['source_sha256']})
        if (base / 'runtime_regression.xml').is_file():
            tests_manifest.append({'path': 'runtime_regression.xml',
                'generation': 'Earlier runtime batch before strict dependency replay repair; exact freeze not recorded',
                'source_sha256': None})
    if not isinstance(tests_manifest, list):
        raise ValueError('Tests manifest must contain separate batch records')
    tests = [parse_test_batch(base, record) for record in tests_manifest]
    for index, batch in enumerate(tests):
        logs.add(base / batch['path'], 'tests/' + str(index + 1) + '_' + Path(batch['path']).name, required=True)
    offline_report = None
    if bool(args.offline_report_v3_manifest) != bool(args.offline_report_v3):
        raise ValueError('Offline report v3 and its manifest must be provided together')
    if args.offline_report_v3_manifest:
        report_manifest = guarded(base, args.offline_report_v3_manifest)
        report_path = guarded(base, args.offline_report_v3)
        manifest_data = read_json(base, report_manifest)
        report_sha256 = sha(read_bytes(base, report_path))
        expected_report_sha256 = (manifest_data.get('report_revision_sha256')
                                  or manifest_data.get('report_sha256'))
        if expected_report_sha256 != report_sha256:
            raise ValueError('Offline report does not match its manifest digest')
        report_source_sha256 = (manifest_data.get('source_sha256')
                                or manifest_data.get('verifier_source_sha256'))
        if report_source_sha256 is not None and report_source_sha256 != source_b_freeze['source_sha256']:
            raise ValueError('Offline report source generation differs from the archived verifier/report product')
        logs.add(report_manifest, 'offline_report_v3/manifest.json', required=True)
        logs.add(report_path, 'offline_report_v3/report.md', required=True)
        logs.add(report_path.parent / 'current.json', 'offline_report_v3/rendering_manifest.json')
        offline_report = {'generation': 'offline_report_v3',
            'manifest_artifact': 'offline_report_v3/manifest.json',
            'report_artifact': 'offline_report_v3/report.md',
            'manifest_sha256': sha(read_bytes(base, report_manifest)),
            'report_sha256': report_sha256,
            'source_sha256': report_source_sha256,
            'note': 'Separately rebuilt offline report, not a new training or independent-paper run.'}
    runs = config['capture']['expected_runs']
    if type(runs) is not int or runs != 10 or len(capture['runs']) != runs:
        raise ValueError('This ChebNetII regression requires all ten native runs')
    if (len(metrics.get('runs', [])) != runs or len(audit.get('runs', [])) != runs
            or audit.get('expected') != {'train_per_class': 20, 'validation': 500, 'test': 1000, 'runs': 10}
            or any(row.get('disjoint') is not True
                   or row.get('counts', {}).get('val_mask') != 500
                   or row.get('counts', {}).get('test_mask') != 1000
                   or row.get('train_per_class') != [20] * row.get('classes', 0)
                   for row in audit['runs'])):
        raise ValueError('Actual all-run partition audit is incomplete or inconsistent')
    for index in range(runs):
        for suffix in ('model.pt', 'tensors.pt'):
            name = f'run_{index:03d}_{suffix}'
            expected = capture['runs'][index]['files_sha256'].get(name)
            if not isinstance(expected, str) or not re.fullmatch('[0-9a-f]{64}', expected):
                raise ValueError('A captured model/tensor lacks its exact SHA256')
            artifacts.add(runtime / name, name, required=True, binary=True, expected=expected)
    adapter_manifest = read_json(base, final / 'adapter_manifest.json')
    adapter_files = adapter_manifest.get('files') or {}
    for name in MODEL_RUNTIME_FILES:
        expected = adapter_files.get(CAPTURE_DIR + '/' + name)
        if name.endswith('.py') and expected is None:
            raise ValueError('Recomputation runtime lacks a frozen adapter manifest entry')
        artifacts.add(runtime / name, name, required=True, expected=expected)
    artifacts.add(final / 'adapter_manifest.json', 'adapter_manifest.json', required=True)
    author_manifest = {'version': 1, 'repository': read_json(base, final / 'experiment_spec.json')['spec']['repository'],
        'files': config['source_files'], 'files_count': len(config['source_files']),
        'source_tree_copied_into_evidence': False,
        'note': 'Acquire this exact author revision and verify every listed file before fresh evaluation.'}
    logs.generated('original_author_source_manifest.json', author_manifest)
    artifacts.generated('original_author_source_manifest.json', author_manifest)
    artifacts.generated('recompute_manifest.json', {'version': 1,
        'scope': 'Fresh evaluation of all ten archived trained TorchScript models',
        'recomputation_executes_training': False, 'fully_self_contained': False,
        'model_origin_attempt': final_attempt, 'model_origin_training_source_sha256': training_freeze['source_sha256'],
        'external_frozen_author_checkout_required': True,
        'repository': author_manifest['repository'],
        'layout': 'Place all model ZIP members in the exact author checkout/_autorepro_capture directory.',
        'argv_from_author_checkout': ['python', '_autorepro_capture/runtime.py', 'evaluate'],
        'requirements_artifact': 'requirements.json', 'source_manifest': 'original_author_source_manifest.json',
        'operator_imports': config.get('operator_imports', []),
        'spec_sha256': config['spec_sha256'], 'expected_runs': runs,
        'capture_sha256': sha(read_bytes(base, runtime / 'capture.json')),
        'independent_metrics_sha256': sha(read_bytes(base, runtime / 'independent_metrics.json')),
        'instructions': ['Verify every archived member against archive_member_manifest.json.',
                         'Acquire the recorded author revision and verify original_author_source_manifest.json.',
                         'Use a compatible CPU Python environment with the recorded requirements; no dependencies are bundled.',
                         'Preserve the archived independent_metrics.json before evaluation, because evaluate replaces that receipt.',
                         'Run the recorded evaluation argv and compare all ten predictions, per-run metrics and aggregate.']})
    selected_execution = read_json(base, final / 'execution.json')
    selected_original_pipeline_completed = (
        reverification is None and result.get('state') == 'COMPLETED'
        and final_summary.get('state') == 'COMPLETED' and selected_execution.get('success') is True)
    source_b_pipeline_rerun_verified = selected_original_pipeline_completed and selected_generation == 'B'
    final_audit_metadata = final_run_audit['metadata'] if final_run_audit else None
    source_a_original = read_json(base, find_run(base, 'full_03') / 'result.json')
    historical_metadata = historical_reverification['metadata'] if historical_reverification else None
    sources = {
        'selected_training_and_independent_execution': {
            'attempt': final_attempt, 'generation': selected_generation,
            'source_sha256': training_freeze['source_sha256'],
            'original_pipeline_state': result.get('state'),
            'original_pipeline_completed_with_its_training_source': selected_original_pipeline_completed},
        'historical_source_A_training': {'attempt': 'full_03',
            'source_sha256': source_a_verification['source_sha256'],
            'original_pipeline_state': source_a_original.get('state'),
            'offline_host_reverification': historical_metadata},
        'corrected_source_B': {'source_sha256': source_b_freeze['source_sha256'],
            'training_reexecuted_after_A_to_B_changes': source_b_pipeline_rerun_verified,
            'full_pipeline_rerun_verified': source_b_pipeline_rerun_verified,
            'full_pipeline_rerun_attempt': final_attempt if source_b_pipeline_rerun_verified else None,
            'complete_run_audit': final_audit_metadata,
            'rerun_claim_basis': 'Selected original COMPLETED pipeline with source B freeze and complete strict runtime evidence'
                                if source_b_pipeline_rerun_verified else None},
        'selected_run_later_host_reverification': reverification,
        'offline_report_v3_generation': offline_report,
        'product_tree_at_packaging': current_freeze,
        'changed_current_product_files_against_selected_training_source': changed,
        'selected_training_and_current_product_tree_identical': not changed,
        'selected_original_pipeline_validates_current_product_tree': selected_original_pipeline_completed and not changed,
        'note': ('Selected training, independent evaluation and original pipeline completion bind corrected source B. '
                 'The separate full_03 source A failure and its later offline B recheck remain historical evidence.'
                 if source_b_pipeline_rerun_verified else
                 'Selected original training and any later host recheck retain separate source generations; '
                 'a recheck operation alone does not establish a new end-to-end pipeline run.')}
    logs.generated('source_generations.json', sources)
    logs.generated('test_batches.json', tests)
    logs.generated('selection_manifest.json', {'version': 1,
        'selected_paths': [entry.name for entry in logs.entries],
        'optional_files_absent': logs.missing, 'recursive_workspace_or_dependencies_included': False})
    # All run validation and input selection finish before creating output.
    output.mkdir()
    logs_zip = write_archive(logs, output / 'issue30_chebnetii_20261021_logs.zip')
    models_zip = write_archive(artifacts, output / 'issue30_chebnetii_20261021_models.zip')
    evidence = {'version': 1, 'recorded_at': datetime.now(timezone.utc).isoformat(),
        'issue': 'https://github.com/Yukikazct/AutoReproducer/issues/30',
        'scope': 'ChebNetII Cora regression with strict selected-experiment verification',
        'paper_eligibility': {'paper': 'ChebNetII', 'status': 'retired_regression_sample',
                              'new_paper_independent_acceptance': False,
                              'reason': 'Previously exercised paper; this is regression evidence, not unused-paper acceptance.'},
        'selected_attempt': final_attempt, 'source_generations': sources,
        'attempts': attempts, 'harness_attempts': harness_attempts,
        'offline_report_v3': offline_report,
        'original_pipeline': {'state': result.get('state'), 'summary_state': final_summary.get('state'),
            'result_sha256': sha(read_bytes(base, final / 'result.json')),
            'report_sha256': sha(read_bytes(base, final / 'report.md')),
            'validation_status': original_validation.get('status'),
            'paper_metrics_verified': original_validation.get('paper_metrics_verified'),
            'is_reproduced': original_validation.get('is_reproduced'),
            'original_result_and_report_preserved': True},
        'later_host_reverification': reverification,
        'historical_host_reverification': historical_metadata,
        'complete_run_audit': final_audit_metadata,
        'source_bundles': source_archives,
        'strict_result_basis': 'later_host_reverification_of_original_artifacts' if reverification else 'original_pipeline',
        'tests': tests, 'test_counts_combined_across_generations': False,
        'strict_result': {key: validation.get(key) for key in
            ('status', 'is_reproduced', 'paper_metrics_verified', 'protocol_pass', 'independent_metrics_pass',
             'comparisons', 'training_summary', 'numeric_compatibility', 'completion_checks')},
        'native_runs': {'count': runs, 'optimizer_steps': capture.get('optimizer_steps'),
            'spec_sha256': config['spec_sha256'], 'capture_process_pid': capture.get('process_pid'),
            'independent_process_pid': metrics.get('process_pid'), 'partition_audit_pid': audit.get('audit_pid'),
            'partition_audit_pass': audit.get('pass'), 'exact_loader_input_audit_pass': loader_audit.get('pass')},
        'partition_evidence': {'authoritative': 'actual ten captured masks and fresh partition_model_audit.json',
            'actual_training_per_class': 20, 'actual_validation_nodes': 500, 'actual_test_nodes': 1000,
            'frozen_plan_partition_verification': read_json(base, final / 'experiment_spec.json')['spec'].get('partition_verification'),
            'caveat': 'The original frozen partition declaration is retained unchanged. The authoritative partition evidence is all ten actual masks, including any mismatch with an unverified planning declaration.'},
        'environment_cleanup': {'status': cleanup.get('status'), 'remaining': cleanup.get('remaining'),
                                'errors': cleanup.get('errors')},
        'archives': [logs_zip, models_zip],
        'limitations': ['This previously used ChebNetII sample is not new-paper independent acceptance.',
                       'An original pipeline ERROR remains ERROR; a later host verification receipt is recorded separately.',
                       'An offline host recheck alone does not establish a new end-to-end run; separately recorded original pipeline completion can.',
                       'Each test batch retains its own source generation; counts are not combined.',
                       'Training success does not validate later product edits without another run.',
                       'ZIPs at or above 20 MiB remain local; only their manifests are eligible for docs.']}
    encoded, _ = screen(json.dumps(evidence, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8'))
    (output / 'issue30_chebnetii_20261021.json').write_bytes(encoded)
    print(json.dumps({'output': str(output), 'archives': [
        {key: archive[key] for key in ('path', 'bytes', 'sha256', 'publish_eligible_below_20_mib')}
        for archive in (logs_zip, models_zip)]}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # Never echo unknown exception text: it may contain a credential-bearing
        # malformed input or URL. The type is enough to locate a failure locally.
        print('Evidence packaging stopped: ' + type(error).__name__, file=sys.stderr)
        raise SystemExit(1)
