"""Recheck unchanged completed runtime evidence with the corrected host verifier.

This is an additive audit, not a rerun of the PDF pipeline. Original failures,
plans, source, weights, receipts, reports and logs remain byte-for-byte intact.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
APP = BASE.parents[1] / 'AutoReproducer'
sys.path.insert(0, str(APP))

from src.discovered_repository_reproduction import verify_snapshot
from src.holdout_registry import product_hashes, digest
from src.report_revisions import REPORT_FORMAT_VERSION, regenerate_report, report_format_version
from src.strict_validation import verify_strict_execution


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text('utf-8'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def inventory(root, excluded=None):
    values = {}
    for path in sorted(root.rglob('*')):
        if excluded is not None and path.is_relative_to(excluded):
            continue
        if path.is_symlink() or path.is_junction():
            raise ValueError('Linked evidence cannot be reverified')
        if path.is_file():
            values[path.relative_to(root).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    return values


def verify_additional_audits(run, plan, spec_hash):
    """Bind both fresh-process audits to current immutable runtime evidence."""
    root = run / 'repo' / '_autorepro_capture'
    config = read(root / 'config.json')
    captured = read(root / 'capture.json')
    evaluated = read(root / 'independent_metrics.json')
    expected = plan['capture']['expected_runs']
    assert config['spec_sha256'] == captured['spec_sha256'] == evaluated['spec_sha256'] == spec_hash
    assert config['capture'] == plan['capture']
    assert captured['pass'] is True and evaluated['pass'] is True
    assert len(captured['runs']) == len(evaluated['runs']) == expected
    assert evaluated['capture_sha256'] == sha(root / 'capture.json')
    receipt_hashes = {key + '_sha256': sha(root / (name + '.json')) for key, name in
                      (('config', 'config'), ('capture', 'capture'),
                       ('independent_metrics', 'independent_metrics'))}
    audits, bindings = {}, {}
    for name, script in (('partition_model_audit.json', 'audit_export.py'),
                         ('loader_input_audit.json', 'audit_loader_inputs.py')):
        audit = read(run / name)
        assert audit['pass'] is True and audit['spec_sha256'] == spec_hash
        assert len(audit['runs']) == expected
        assert [row['index'] for row in audit['runs']] == list(range(expected))
        assert all(audit[key] == value for key, value in receipt_hashes.items())
        assert audit['script_sha256'] == sha(BASE / script), 'Audit script changed after evidence collection'
        assert audit['capture_pid'] == captured['process_pid']
        assert audit['independent_evaluation_pid'] == evaluated['process_pid']
        audits[name] = audit
        bindings[name] = {'sha256': sha(run / name), 'script': script,
                          'script_sha256': audit['script_sha256'], 'audit_pid': audit['audit_pid'],
                          **receipt_hashes}
    partition, loader = audits['partition_model_audit.json'], audits['loader_input_audit.json']
    pids = [captured['process_pid'], evaluated['process_pid'], partition['audit_pid'],
            loader['audit_pid'], os.getpid()]
    assert all(type(pid) is int and pid > 0 for pid in pids) and len(set(pids)) == len(pids)
    assert partition['capture_files_unchanged'] is True
    assert partition['capture_tree_before'] == partition['capture_tree_after'] == inventory(root)
    assert partition['expected']['runs'] == expected
    assert partition['expected']['test'] == plan['capture']['expected_test_samples'][0]
    assert loader['repository_files_unchanged'] is True
    assert loader['repository_before'] == loader['repository_after'] == inventory(run / 'repo', root)
    assert loader['repository_before_sha256'] == loader['repository_after_sha256'] == digest(loader['repository_before'])
    assert loader['expected_runs'] == expected
    assert loader['random_masks_reconstructed'] is False
    assert loader['frozen_source_files'] == len(config['source_files'])
    assert loader['frozen_source_manifest_sha256'] == digest(config['source_files'])
    loader_path = loader['loader']['path']
    assert loader_path in config['source_files']
    assert loader['loader']['source_sha256'] == config['source_files'][loader_path]
    for index, (model_row, input_row) in enumerate(zip(partition['runs'], loader['runs'])):
        original = captured['runs'][index]
        assert model_row['predictions_match'] is True and model_row['disjoint'] is True
        assert input_row['exact_loader_match'] is True
        assert model_row['files_sha256'] == original['files_sha256']
        assert input_row['tensor_bundle_sha256'] == original['files_sha256'][f'run_{index:03d}_tensors.pt']
        assert input_row['fields'] == loader['loader_graph_tensors']
        assert model_row['input_sha256'] == {field: details['sha256'] for field, details in input_row['fields'].items()}
        assert model_row['optimizer_steps'] == original['optimizer_steps']
        assert model_row['selected_optimizer_steps'] == original['validation_selection']['optimizer_steps']
        assert abs(model_row['fresh_test_accuracy'] - evaluated['runs'][index]['accuracy']) < 1e-12
    assert abs(partition['mean_test_accuracy_percent'] - evaluated['accuracy'] * 100) < 1e-10
    return bindings


def main():
    if not __debug__:
        raise RuntimeError('Optimized Python disables audit assertions and is unsupported')
    run = Path(sys.argv[1]).resolve(strict=True)
    assert run.is_relative_to(BASE) and run.parent.name == 'runs'
    output = run / 'reverification'
    assert not output.exists()
    source = product_hashes(APP)
    original = read(run / 'result.json')
    data = original['data']
    execution = read(run / 'execution.json')
    spec = read(run / 'experiment_spec.json')
    plan, spec_hash = spec['spec'], spec['sha256']
    packet = read(run / 'source_packet.json')
    workspace = run / 'repo'
    snapshot = read(run / 'repository.json')
    generated = read(run / 'adapter_manifest.json')['files']
    cleanup = read(run / 'environment_cleanup.json')
    assert cleanup['status'] == 'released' and not cleanup.get('remaining') and not cleanup.get('errors')
    assert execution['success'] is True, 'Only complete successful training and evaluation can be reverified'
    assert data['execution']['run_dir'] == execution['run_dir']
    if original['state'] == 'ERROR':
        assert data['validation']['failure_phase'] == 'finish_execution'
        assert original['error'] == 'Author printed accuracy and fresh model evaluation disagree'
    else:
        assert original['state'] == 'COMPLETED'
    audit_bindings = verify_additional_audits(run, plan, spec_hash)
    training_freeze = read(run.parents[2] / 'source_freeze.json')
    assert digest(training_freeze['files']) == training_freeze['source_sha256']
    materialized_sources = {}
    for copied, source_file in (
            ('runtime.py', 'src/experiments/discovered_series_capture.py'),
            ('common.py', 'src/experiments/discovered_capture.py'),
            ('strict_numeric_compatibility.py', 'src/experiments/strict_numeric_compatibility.py'),
            ('author_numeric_compatibility.py', 'src/experiments/author_numeric_compatibility.py'),
            ('author_values.py', 'src/author_values.py'),
            ('split_counts.py', 'src/split_counts.py'),
            ('native_loop.py', 'src/native_loop.py')):
        actual = sha(workspace / '_autorepro_capture' / copied)
        assert actual == training_freeze['files'][source_file], 'Materialized runtime does not match training source A'
        materialized_sources[copied] = {'source_file': source_file, 'sha256': actual}
    changed = sorted(name for name in set(source) | set(training_freeze['files'])
                     if source.get(name) != training_freeze['files'].get(name))
    before = inventory(run, output)
    verify_snapshot(workspace, snapshot, generated)
    validation = verify_strict_execution(plan, packet, workspace, execution, spec_hash)
    assert validation['paper_metrics_verified'] and validation['independent_metrics_pass']
    validation['dataset_provenance_verified'] = data['dataset_provenance']['verified']
    note = ('本结果使用修复后的核验器离线重新核验已保存的完整训练和独立预测证据；'
            '没有重训、改写模型或调整协议，不代表修复后源码重新执行整条 PDF 流程。')
    validation.setdefault('warnings', []).append(note)
    revision = {
        'kind': 'offline_saved_runtime_reverification', 'verified_at': datetime.now(timezone.utc).isoformat(),
        'origin_result_sha256': sha(run / 'result.json'), 'origin_report_sha256': sha(run / 'report.md'),
        'original_pipeline_state': original['state'], 'original_pipeline_error': original.get('error'),
        'spec_sha256': spec_hash, 'training_source_sha256': training_freeze['source_sha256'],
        'verifier_source_sha256': digest(source), 'changed_product_files_after_training': changed,
        'verifier_source_freeze_path': str(output / 'verifier_source_freeze.json'),
        'artifacts_unchanged': True,
        'training_rerun_after_later_changes': False, 'full_pipeline_rerun_after_later_changes': False,
        'all_original_run_files_unchanged': True, 'original_files': before,
        'additional_audits': audit_bindings, 'materialized_training_runtime_sources': materialized_sources,
        'note': note,
    }
    result = deepcopy(original)
    result.update(state='COMPLETED', error=None)
    result['data']['validation'] = validation
    result['data']['verification_revision'] = revision
    strict = result['data']['strict_validation']
    strict.update(status='verified', result=validation['status'],
                  reason='保存的完整执行证据已通过修复后核验器的离线复核')
    strict.pop('failure_phase', None)
    output.mkdir()
    save(output / 'verifier_source_freeze.json', {'source_sha256': digest(source), 'files': source})
    save(output / 'strict_execution_verification.json', validation)
    source_report = output / 'original_report_copy.md'
    source_report.write_bytes((run / 'report.md').read_bytes())
    result['report_path'] = str(source_report)
    result['data'].update(report_path=str(source_report), report=source_report.read_text('utf-8'))
    save(output / 'reverification_input.json', result)
    updated = regenerate_report(result, data_root=run.parents[1])
    report_path = Path(updated['report_path']).resolve(strict=True)
    assert report_path != source_report.resolve(strict=True) and report_path.is_relative_to(output.resolve())
    assert updated['data']['report_path'] == updated['report_path']
    assert updated['data']['validation'] == validation
    assert updated['state'] == 'COMPLETED' and updated.get('error') is None
    assert REPORT_FORMAT_VERSION == 3 and report_format_version(updated['data']['report']) == 3
    assert updated['data']['report_format_version'] == 3
    assert report_path.read_text('utf-8') == updated['data']['report']
    assert sha(source_report) == sha(run / 'report.md'), 'Original report copy changed'
    assert note in updated['data']['report']
    assert '完整独立复算证据已核验' in updated['data']['report']
    for comparison in validation['comparisons']:
        assert str(comparison['actual']) in updated['data']['report']
    for repair in validation.get('numeric_compatibility', []):
        if repair.get('kind') in {'numpy_float_reciprocal', 'numpy_builtin_alias', 'numpy_ragged_summary'}:
            assert '数值兼容来源' in updated['data']['report']
            assert repair['source_sha256'] in updated['data']['report']
    save(output / 'verified_result.json', updated)
    revision['verified_result_sha256'] = sha(output / 'verified_result.json')
    revision['strict_execution_verification_sha256'] = sha(output / 'strict_execution_verification.json')
    revision['report_revision_path'] = updated['report_path']
    revision['report_revision_sha256'] = sha(Path(updated['report_path']))
    verify_snapshot(workspace, snapshot, generated)
    assert before == inventory(run, output), 'Reverification modified the original run'
    assert source == product_hashes(APP), 'Verifier changed during evidence recheck'
    assert audit_bindings == verify_additional_audits(run, plan, spec_hash), 'Additional audit evidence changed during recheck'
    save(output / 'reverification_manifest.json', revision)
    print(json.dumps({'state': updated['state'], 'original_pipeline_state': original['state'],
                      'reproduced': validation['is_reproduced'], 'comparison': validation['comparisons'],
                      'output': str(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
