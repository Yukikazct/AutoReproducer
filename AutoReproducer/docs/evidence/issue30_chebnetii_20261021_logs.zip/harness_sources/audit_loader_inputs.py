"""Compare exported graph tensors with the pinned author's existing loader.

Run only after the native run and fresh evaluation have completed. The caller
provides the already installed CPU runtime through PYTHONPATH. This script never
installs dependencies, regenerates processed data, or reconstructs random masks.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

import torch
import torch_geometric
import torch_scatter
import torch_sparse


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def object_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False).encode("utf-8")).hexdigest()


def confined(root, relative):
    require(isinstance(relative, str) and relative, "A nonempty relative path is required")
    part = Path(relative)
    require(not part.is_absolute() and not part.drive and ".." not in part.parts,
            "Manifest path is not repository-relative")
    current = root
    for name in part.parts:
        current = current / name
        info = current.lstat()
        require(not stat.S_ISLNK(info.st_mode)
                and not (getattr(info, "st_file_attributes", 0)
                         & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)),
                "Links and junctions are unsupported audit inputs")
    resolved = current.resolve(strict=True)
    require(resolved.is_relative_to(root), "Input escaped its pinned repository")
    return resolved


def repository_snapshot(root, excluded):
    """Freeze the complete author tree, including all raw/processed inputs."""
    result = {}
    for directory, directories, files in os.walk(root, followlinks=False):
        directory = Path(directory)
        selected = []
        for name in sorted(directories):
            child = directory / name
            if child == excluded:
                continue
            confined(root, child.relative_to(root).as_posix())
            selected.append(name)
        directories[:] = selected
        for name in sorted(files):
            path = directory / name
            relative = path.relative_to(root).as_posix()
            path = confined(root, relative)
            require(path.is_file(), "Repository inventory contains a non-file")
            result[relative] = {"bytes": path.stat().st_size, "sha256": sha(path)}
    return result


def graph_layouts(value):
    if isinstance(value, dict):
        if value.get("kind") == "torch_geometric_data":
            yield value
        else:
            for child in value.values():
                yield from graph_layouts(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            yield from graph_layouts(child)


def tensor_record(value):
    require(isinstance(value, torch.Tensor), "Graph field is not a tensor")
    value = value.detach().cpu().contiguous()
    raw = value.view(torch.uint8).numpy().tobytes()
    return {"shape": list(value.shape), "dtype": str(value.dtype),
            "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture_root", type=Path)
    parser.add_argument("--loader-relative", required=True)
    parser.add_argument("--function", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--cwd", required=True)
    args = parser.parse_args()
    capture_root = args.capture_root.resolve(strict=True)
    repo = capture_root.parent
    run_dir = repo.parent
    output = run_dir / "loader_input_audit.json"
    original_cwd, original_path = Path.cwd(), list(sys.path)
    original_bytecode = sys.dont_write_bytecode
    guard = {"active": False}
    before = None
    result = {"pass": False, "scope": "pinned_author_loader_exported_graph_inputs",
              "audit_pid": os.getpid(), "script_sha256": sha(Path(__file__).resolve()),
              "random_masks_reconstructed": False,
              "filesystem_guard": "deny Python filesystem mutations and network/subprocess execution; compare complete author tree before and after"}

    def read_only_hook(event, arguments):
        if not guard["active"]:
            return
        if event == "open":
            mode = arguments[1]
            flags = arguments[2] if len(arguments) > 2 else 0
            if ((isinstance(mode, str) and any(char in mode for char in "wax+"))
                    or (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))):
                raise PermissionError("Read-only loader audit denied a file write")
        if event in {"os.remove", "os.rmdir", "os.rename", "os.mkdir", "os.link", "os.symlink",
                     "os.truncate", "os.chmod", "os.chown", "os.utime", "os.setxattr", "os.removexattr",
                     "subprocess.Popen", "os.system", "os.posix_spawn", "os.spawn", "os.exec",
                     "socket.connect", "socket.connect_ex", "socket.getaddrinfo", "urllib.Request"}:
            raise PermissionError("Read-only loader audit denied mutation or external execution: " + event)

    sys.addaudithook(read_only_hook)
    failure = None
    try:
        config = json.loads((capture_root / "config.json").read_text("utf-8"))
        capture = json.loads((capture_root / "capture.json").read_text("utf-8"))
        independent = json.loads((capture_root / "independent_metrics.json").read_text("utf-8"))
        require(capture.get("pass") is True and independent.get("pass") is True,
                "Complete successful capture and independent evaluation are required")
        require(capture["spec_sha256"] == independent["spec_sha256"] == config["spec_sha256"],
                "Capture, evaluation, and config belong to different frozen plans")
        require(independent["capture_sha256"] == sha(capture_root / "capture.json"),
                "Independent evaluation does not bind the current capture")
        require(len({capture["process_pid"], independent["process_pid"], os.getpid()}) == 3,
                "Loader audit must use another fresh process")
        expected_runs = config["capture"]["expected_runs"]
        require(type(expected_runs) is int and expected_runs > 0,
                "Frozen plan does not specify the complete native series")
        require(len(capture["runs"]) == len(independent["runs"]) == expected_runs,
                "Capture or evaluation omits native repetitions")
        loader = confined(repo, args.loader_relative)
        cwd = confined(repo, args.cwd)
        require(loader.is_file() and cwd.is_dir(), "Loader or working directory is invalid")
        frozen_sources = config["source_files"]
        require(args.loader_relative in frozen_sources,
                "Loader is absent from the frozen source manifest")
        require(sha(loader) == frozen_sources[args.loader_relative],
                "Loader source differs from the frozen author source")
        for relative, digest in frozen_sources.items():
            require(sha(confined(repo, relative)) == digest,
                    "Frozen source or bundled data changed: " + relative)
        for relative, digest in config.get("data_files", {}).items():
            require(sha(confined(repo, relative)) == digest,
                    "Frozen external data changed: " + relative)
        before = repository_snapshot(repo, capture_root)
        result.update(spec_sha256=config["spec_sha256"], capture_sha256=sha(capture_root / "capture.json"),
                      config_sha256=sha(capture_root / "config.json"),
                      independent_metrics_sha256=sha(capture_root / "independent_metrics.json"),
                      capture_pid=capture["process_pid"], independent_evaluation_pid=independent["process_pid"],
                      expected_runs=expected_runs,
                      loader={"path": args.loader_relative, "function": args.function,
                              "dataset": args.dataset, "cwd": args.cwd, "source_sha256": sha(loader)},
                      frozen_source_files=len(frozen_sources), frozen_source_manifest_sha256=object_sha(frozen_sources),
                      repository_before=before, repository_before_sha256=object_sha(before))
        # Suppress bytecode writes before executing any pinned author import.
        sys.dont_write_bytecode = True
        sys.path[:0] = [str(cwd), str(loader.parent)]
        os.chdir(cwd)
        guard["active"] = True
        import torch_geometric
        from torch_geometric.data import Data
        module_spec = importlib.util.spec_from_file_location("_pinned_author_loader_audit", loader)
        require(module_spec is not None and module_spec.loader is not None, "Loader import is unavailable")
        module = importlib.util.module_from_spec(module_spec)
        sys.modules[module_spec.name] = module
        module_spec.loader.exec_module(module)
        function = getattr(module, args.function)
        require(callable(function), "Requested author loader function is not callable")
        loaded = function(args.dataset)
        original = loaded if isinstance(loaded, Data) else loaded[0]
        require(isinstance(original, Data), "Author loader did not return a graph dataset")
        fields = ("x", "y", "edge_index")
        source_tensors = {name: getattr(original, name) for name in fields}
        original_records = {name: tensor_record(value) for name, value in source_tensors.items()}
        result["runtime"] = {"python": sys.executable, "torch": torch.__version__,
                             "torch_path": str(Path(torch.__file__).resolve()),
                             "torch_geometric": torch_geometric.__version__,
                             "torch_geometric_path": str(Path(torch_geometric.__file__).resolve())}
        result["loader_output_type"] = type(loaded).__module__ + "." + type(loaded).__qualname__
        result["loader_graph_tensors"] = original_records
        rows = []
        for index, captured in enumerate(capture["runs"]):
            require(captured["index"] == index, "Capture repetition indexes are incomplete")
            tensor_name = f"run_{index:03d}_tensors.pt"
            tensor_path = confined(capture_root, tensor_name)
            require(sha(tensor_path) == captured["files_sha256"][tensor_name],
                    "Captured tensor bundle differs from its receipt")
            bundle = torch.load(tensor_path, map_location="cpu", weights_only=True)
            layouts = list(graph_layouts(bundle["input_layouts"]))
            require(len(layouts) == 1, "Expected exactly one complete exported graph input")
            inputs = bundle["inputs"]
            actual_records = {}
            for name in fields:
                layout = layouts[0]["fields"][name]
                require(layout["kind"] == "tensor" and type(layout["index"]) is int,
                        "Exported graph field has no tensor layout")
                require(0 <= layout["index"] < len(inputs), "Exported graph tensor index is invalid")
                actual = inputs[layout["index"]]
                expected = source_tensors[name]
                require(isinstance(actual, torch.Tensor) and actual.dtype == expected.dtype
                        and actual.shape == expected.shape and torch.equal(actual.cpu(), expected.cpu()),
                        f"Run {index} {name} differs from the original author's loader")
                actual_records[name] = tensor_record(actual)
                require(actual_records[name] == original_records[name], "Exact graph tensor hash differs")
            rows.append({"index": index, "tensor_bundle_sha256": sha(tensor_path),
                         "exact_loader_match": True, "fields": actual_records})
        result["runs"] = rows
        result["pass"] = True
    except BaseException as exc:
        failure = exc
        result["error"] = {"type": type(exc).__name__, "message": str(exc)}
    finally:
        guard["active"] = False
        os.chdir(original_cwd)
        sys.path[:] = original_path
        sys.dont_write_bytecode = original_bytecode
        if before is not None:
            try:
                after = repository_snapshot(repo, capture_root)
                result["repository_after"] = after
                result["repository_after_sha256"] = object_sha(after)
                result["repository_files_unchanged"] = before == after
                if before != after:
                    result["pass"] = False
                    result["file_changes"] = {"added": sorted(after.keys() - before.keys()),
                                              "removed": sorted(before.keys() - after.keys()),
                                              "changed": sorted(name for name in before.keys() & after.keys()
                                                                if before[name] != after[name])}
                    failure = failure or ValueError("Author loader audit changed repository inputs")
            except BaseException as exc:
                result["pass"] = False
                result["snapshot_error"] = {"type": type(exc).__name__, "message": str(exc)}
                failure = failure or exc
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"pass": result["pass"], "audit_pid": os.getpid(),
                      "runs": len(result.get("runs", [])), "report": str(output),
                      "repository_files_unchanged": result.get("repository_files_unchanged")}))
    if failure is not None:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
