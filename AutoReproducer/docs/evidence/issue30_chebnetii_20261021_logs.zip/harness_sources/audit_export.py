"""Reload every exported model and audit complete graph partitions.

This additional audit does not rerun training or establish unused-paper
acceptance. Optimizer counts come from separately verified capture receipts.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch
import torch_scatter
import torch_sparse


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tensor_sha(value):
    value = value.detach().cpu().contiguous()
    return hashlib.sha256(value.view(torch.uint8).numpy().tobytes()).hexdigest()


def confined(root, name):
    part = Path(name)
    if not isinstance(name, str) or not name or part.is_absolute() or part.drive or '..' in part.parts:
        raise ValueError('Capture manifest path must remain relative')
    current = root
    for component in part.parts:
        current = current / component
        if current.is_symlink() or current.is_junction():
            raise ValueError('Linked capture inputs are unsupported')
    if not current.resolve(strict=True).is_relative_to(root):
        raise ValueError('Capture input escaped its pinned root')
    return current


def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink() or path.is_junction():
            raise ValueError('Linked capture evidence cannot be audited')
        if path.is_file():
            result[path.relative_to(root).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    return result


def main():
    if not __debug__:
        raise RuntimeError('Optimized Python disables audit assertions and is unsupported')
    parser = argparse.ArgumentParser()
    parser.add_argument('runtime', type=Path)
    parser.add_argument('--train-per-class', type=int, required=True)
    parser.add_argument('--validation', type=int, required=True)
    parser.add_argument('--test', type=int, required=True)
    parser.add_argument('--runs', type=int, required=True)
    args = parser.parse_args()
    root = args.runtime.resolve(strict=True)
    output = root.parent.parent / 'partition_model_audit.json'
    if output.exists():
        raise ValueError('Preserve the existing audit; reruns require a new output location')
    assert all(value > 0 for value in (args.train_per_class, args.validation, args.test, args.runs))
    config = json.loads((root / 'config.json').read_text('utf-8'))
    capture = json.loads((root / 'capture.json').read_text('utf-8'))
    independent = json.loads((root / 'independent_metrics.json').read_text('utf-8'))
    assert capture.get('pass') is True and independent.get('pass') is True
    assert capture['spec_sha256'] == independent['spec_sha256'] == config['spec_sha256']
    assert independent['capture_sha256'] == sha(root / 'capture.json')
    assert len(capture['runs']) == len(independent['runs']) == config['capture']['expected_runs'] == args.runs
    assert config['capture']['expected_test_samples'] == [args.test] * args.runs
    assert len({capture['process_pid'], independent['process_pid'], os.getpid()}) == 3
    before = inventory(root)
    rows = []
    base_inputs = None
    for index, captured in enumerate(capture['runs']):
        assert captured['index'] == independent['runs'][index]['index'] == index
        assert (captured.get('natural_return') is True or captured.get('native_loop_completed') is True)
        assert captured.get('parameters_changed') is True
        for name, digest in captured['files_sha256'].items():
            assert sha(confined(root, name)) == digest
        model_name, tensor_name = f'run_{index:03d}_model.pt', f'run_{index:03d}_tensors.pt'
        assert captured['files_sha256'][model_name] == sha(confined(root, model_name))
        assert captured['files_sha256'][tensor_name] == sha(confined(root, tensor_name))
        bundle = torch.load(confined(root, tensor_name), map_location='cpu', weights_only=True)
        layouts, inputs = bundle['input_layouts'], bundle['inputs']
        graphs = [layout for layout in layouts if layout['kind'] == 'torch_geometric_data']
        assert len(graphs) == 1, 'Expected one complete original graph input'
        fields = graphs[0]['fields']
        def tensor(name):
            layout = fields[name]
            assert layout['kind'] == 'tensor'
            assert type(layout['index']) is int and 0 <= layout['index'] < len(inputs)
            assert isinstance(inputs[layout['index']], torch.Tensor)
            return inputs[layout['index']]
        labels = tensor('y')
        assert labels.ndim == 1 and torch.equal(labels, bundle['labels'])
        masks = {name: tensor(name) for name in ('train_mask', 'val_mask', 'test_mask')}
        assert all(mask.dtype == torch.bool and mask.shape == labels.shape for mask in masks.values())
        assert torch.equal(masks['test_mask'], bundle['test_indices'])
        classes = torch.unique(labels, sorted=True)
        per_class = [int(((labels == value) & masks['train_mask']).sum()) for value in classes]
        assert per_class == [args.train_per_class] * len(classes)
        counts = {name: int(mask.sum()) for name, mask in masks.items()}
        assert counts['val_mask'] == args.validation and counts['test_mask'] == args.test
        assert all(not torch.any(masks[a] & masks[b]) for a, b in
            [('train_mask', 'val_mask'), ('train_mask', 'test_mask'), ('val_mask', 'test_mask')])
        original_inputs = {name: tensor_sha(tensor(name)) for name in ('x', 'y', 'edge_index')}
        if base_inputs is None:
            base_inputs = original_inputs
        assert original_inputs == base_inputs, 'Native runs used different graph data'
        model = torch.jit.load(str(confined(root, model_name)), map_location='cpu').eval()
        with torch.no_grad():
            logits = model(*inputs)
        assert torch.allclose(logits, bundle['outputs'], atol=1e-6, rtol=1e-5)
        assert torch.equal(logits.argmax(1), bundle['outputs'].argmax(1))
        predictions = logits.argmax(1).numpy()
        selected = masks['test_mask'].numpy()
        accuracy = float(np.mean(predictions[selected] == labels.numpy()[selected]))
        assert abs(accuracy - independent['runs'][index]['accuracy']) < 1e-12
        assert abs(accuracy - captured['validation_selection']['accuracy']) < 1e-8
        rows.append({'index': index, 'nodes': len(labels), 'classes': len(classes),
            'counts': counts, 'train_per_class': per_class, 'disjoint': True,
            'mask_sha256': {name: tensor_sha(mask) for name, mask in masks.items()},
            'input_sha256': original_inputs, 'fresh_test_accuracy': accuracy,
            'predictions_match': True,
            'files_sha256': {name: sha(root / name) for name in (model_name, tensor_name)},
            'optimizer_steps': captured['optimizer_steps'],
            'selected_optimizer_steps': captured['validation_selection']['optimizer_steps']})
    after = inventory(root)
    assert before == after, 'Model audit modified the original saved capture evidence'
    result = {'pass': True, 'scope': 'exported model and complete graph partition audit',
        'unused_paper_acceptance': False, 'optimizer_steps_source': 'capture_receipt',
        'script_sha256': sha(Path(__file__).resolve()),
        'spec_sha256': config['spec_sha256'], 'audit_pid': os.getpid(),
        'config_sha256': sha(root / 'config.json'), 'capture_sha256': sha(root / 'capture.json'),
        'independent_metrics_sha256': sha(root / 'independent_metrics.json'),
        'capture_tree_before': before, 'capture_tree_after': after, 'capture_files_unchanged': True,
        'capture_pid': capture['process_pid'], 'independent_evaluation_pid': independent['process_pid'],
        'expected': {'train_per_class': args.train_per_class, 'validation': args.validation,
            'test': args.test, 'runs': args.runs}, 'runs': rows,
        'mean_test_accuracy_percent': float(np.mean([row['fresh_test_accuracy'] for row in rows])) * 100,
        'unique_partition_count': len({json.dumps(row['mask_sha256'], sort_keys=True) for row in rows}),
        'optimizer_steps': sum(row['optimizer_steps'] for row in rows)}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    print(json.dumps({key: result[key] for key in ('pass', 'mean_test_accuracy_percent', 'optimizer_steps')}))


if __name__ == '__main__':
    main()
