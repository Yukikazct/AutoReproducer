"""Read-only final audit of a naturally completed frozen PDF pipeline.

The only output is a new JSON file beside this script. Neither the completed
run nor the historical failed run is rewritten. This audit does not retrain or
replace the pipeline's official result with an offline result.
"""
import sys

sys.dont_write_bytecode = True

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

import reverify_saved_run as shared


BASE, APP = shared.BASE, shared.APP
sha, read, inventory, digest = shared.sha, shared.read, shared.inventory, shared.digest


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_cleanup(run, cleanup):
    def visit(value):
        if isinstance(value, dict):
            require(not value.get('errors') and not value.get('remaining'), 'Cleanup contains errors or remaining resources')
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(cleanup)
    require(cleanup['status'] == 'released', 'Environment cleanup is not released')
    for key in ('training_python', 'docker', 'runtime_downloads'):
        require(cleanup[key]['status'] == 'released', 'A cleanup component is not released')
    trial = run.parents[2]
    paths = {trial / 'data' / 'training_python', trial / 'deps' / 'repository'}
    for item in cleanup.get('removed', []):
        path = Path(item['path'])
        paths.add(path if path.is_absolute() else trial / 'deps' / path)
    for item in cleanup['training_python'].get('removed', []):
        paths.add(Path(item['path']))
    runtime = read(run / 'runtime_manifest.json')
    interpreter = Path(runtime['python_executable'])
    require(interpreter.is_relative_to(trial), 'This audit expects the trial-owned training interpreter')
    paths.add(interpreter)
    for path in paths:
        require(path.is_relative_to(trial), 'Cleanup path is outside the owned trial')
        require(not path.exists() and not path.is_symlink(), 'A removed environment path still exists')
    return {'status': 'released', 'checked_absent_paths': sorted(str(path) for path in paths),
            'remaining': [], 'errors': [], 'cleanup_sha256': sha(run / 'environment_cleanup.json')}


def process_snapshot():
    if sys.platform == 'win32':
        command = ('[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new(); '
                   'Get-CimInstance -ClassName Win32_Process | '
                   'Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | '
                   'ConvertTo-Json -Depth 3 -Compress')
        completed = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', command],
                                   capture_output=True, encoding='utf-8', errors='strict', timeout=45, check=True)
        values = json.loads(completed.stdout.lstrip('\ufeff'))
        if isinstance(values, dict):
            values = [values]
        return [{'pid': int(value['ProcessId']), 'ppid': int(value['ParentProcessId']),
                 'exe': value.get('ExecutablePath') or '', 'command': value.get('CommandLine') or ''}
                for value in values]
    import psutil
    result = []
    for process in psutil.process_iter(['pid', 'ppid', 'exe', 'cmdline']):
        try:
            item = process.info
            result.append({'pid': item['pid'], 'ppid': item['ppid'], 'exe': item.get('exe') or '',
                           'command': ' '.join(item.get('cmdline') or [])})
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return result


def verify_processes(run, captured, evaluated, status, audit_bindings):
    values = process_snapshot()
    by_pid = {value['pid']: value for value in values}
    excluded, current = {os.getpid()}, os.getpid()
    while current in by_pid and by_pid[current]['ppid'] not in excluded:
        current = by_pid[current]['ppid']
        excluded.add(current)
    known = {status['pid'], captured['process_pid'], evaluated['process_pid'],
             *(value['audit_pid'] for value in audit_bindings.values())}
    require(all(type(pid) is int and pid > 0 for pid in known), 'Owned process IDs are invalid')
    trial_key = str(run.parents[2]).replace('\\', '/').casefold()
    owned = set(known)
    for value in values:
        path_text = (value['exe'] + ' ' + value['command']).replace('\\', '/').casefold()
        if value['pid'] not in excluded and trial_key in path_text:
            owned.add(value['pid'])
    while True:
        children = {value['pid'] for value in values if value['ppid'] in owned and value['pid'] not in excluded}
        if children.issubset(owned):
            break
        owned.update(children)
    alive = sorted(pid for pid in owned if pid in by_pid and pid not in excluded)
    # Do not persist command lines: unrelated processes may contain credentials.
    summary = {'method': 'system_process_snapshot_owned_pids_trial_paths_and_descendants',
               'recorded_pids': sorted(known), 'scanned_processes': len(values),
               'audit_and_ancestor_pids_excluded': sorted(excluded), 'alive_owned_pids': alive,
               'recorded_pid_presence': {str(pid): pid in by_pid for pid in sorted(known)},
               'command_lines_persisted': False}
    require(not alive, 'An owned execution or audit process remains alive')
    return summary


def verify_history(history, source_hash):
    original = read(history / 'result.json')
    manifest_path = history / 'reverification' / 'reverification_manifest.json'
    manifest = read(manifest_path)
    verified_path = history / 'reverification' / 'verified_result.json'
    verified = read(verified_path)
    require(original['state'] == manifest['original_pipeline_state'] == 'ERROR', 'Historical original failure was not preserved')
    require(verified['state'] == 'COMPLETED' and verified.get('error') is None, 'Historical offline verification did not complete')
    require(manifest['kind'] == 'offline_saved_runtime_reverification', 'Historical revision is not an explicit offline audit')
    require(manifest['training_rerun_after_later_changes'] is False
            and manifest['full_pipeline_rerun_after_later_changes'] is False, 'Historical A/B boundary changed')
    require(manifest['origin_result_sha256'] == sha(history / 'result.json')
            and manifest['origin_report_sha256'] == sha(history / 'report.md'), 'Historical original evidence changed')
    require(manifest['verified_result_sha256'] == sha(verified_path), 'Historical offline result changed')
    require(manifest['original_files'] == inventory(history, history / 'reverification'), 'Historical run file inventory changed')
    require(manifest['verifier_source_sha256'] == source_hash, 'Direct run source B differs from historical offline verifier B')
    source_a = read(history.parents[2] / 'source_freeze.json')
    require(digest(source_a['files']) == source_a['source_sha256'] == manifest['training_source_sha256'], 'Historical training source A is inconsistent')
    require(source_a['source_sha256'] != source_hash, 'Source A/B distinction disappeared')
    return {'run_dir': str(history), 'original_pipeline_state': 'ERROR', 'offline_pipeline_state': 'COMPLETED',
            'original_result_sha256': sha(history / 'result.json'), 'original_report_sha256': sha(history / 'report.md'),
            'offline_manifest_sha256': sha(manifest_path), 'offline_result_sha256': sha(verified_path),
            'training_source_sha256': source_a['source_sha256'], 'verifier_source_sha256': source_hash,
            'original_files_unchanged': True, 'historical_offline_only': True}


def main():
    if not __debug__:
        raise RuntimeError('Optimized Python disables shared audit assertions and is unsupported')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    parser.add_argument('--history-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=BASE / 'final_completed_run_audit.json')
    args = parser.parse_args()
    run, history = args.run.resolve(strict=True), args.history_run.resolve(strict=True)
    output = args.output.absolute()
    require(output.parent.resolve(strict=True) == BASE and not output.exists() and not output.is_symlink(),
            'Final audit must create a new external file in the task directory')
    require(run.is_relative_to(BASE) and history.is_relative_to(BASE)
            and run.parent.name == history.parent.name == 'runs' and run != history, 'Run paths are invalid')
    result = {'version': 1, 'pass': False, 'scope': 'direct_completed_pdf_pipeline_audit',
              'run_dir': str(run), 'audit_pid': os.getpid(), 'script_sha256': sha(Path(__file__).resolve()),
              'unused_paper_acceptance': False, 'full_pipeline_rerun': True,
              'audited_at': datetime.now(timezone.utc).isoformat()}
    before, product_before, failure, checks_complete = None, None, None, False
    try:
        before = inventory(run)
        product_before = shared.product_hashes(APP)
        source_hash = digest(product_before)
        freeze = read(run.parents[2] / 'source_freeze.json')
        require(digest(freeze['files']) == freeze['source_sha256'] == source_hash
                and product_before == freeze['files'], 'Direct pipeline did not use the unchanged frozen source B')
        result.update(original_run_files=before, run_files_before_sha256=digest(before),
                      source_sha256=source_hash, training_source_sha256=freeze['source_sha256'],
                      source_freeze_sha256=sha(run.parents[2] / 'source_freeze.json'))
        original, execution = read(run / 'result.json'), read(run / 'execution.json')
        data, status = original['data'], read(run / 'run_status.json')
        require(original['state'] == 'COMPLETED' and original.get('error') is None, 'Official pipeline did not naturally complete')
        require(status['status'] == 'completed' and status.get('environment_cleanup') == 'released', 'Run worker is not terminal and cleaned')
        require(not (run / 'reverification').exists() and 'verification_revision' not in data,
                'Direct completion must not be substituted by an offline revision')
        require(execution['success'] is True and execution['executed'] is True and data['execution'] == execution,
                'Official execution receipts are incomplete or inconsistent')
        frozen_spec = read(run / 'experiment_spec.json')
        plan, spec_hash = frozen_spec['spec'], frozen_spec['sha256']
        require(data['spec_sha256'] == spec_hash and data['grounded_repository_plan'] == plan,
                'Official result uses another frozen grounded specification')
        # experiment_spec is the UI summary; the complete cited plan is stored
        # in grounded_repository_plan and in experiment_spec.json["spec"].
        ui_spec = data['experiment_spec']
        require(ui_spec['adapter_id'] == 'discovered' and ui_spec['repository'] == plan['repository']
                and ui_spec['parameters'] == plan['parameters']
                and ui_spec['validation']['scope'] == plan['scope'],
                'UI specification does not summarize the frozen grounded plan')
        result['spec_sha256'] = spec_hash
        workspace, root = run / 'repo', run / 'repo' / '_autorepro_capture'
        snapshot, generated = read(run / 'repository.json'), read(run / 'adapter_manifest.json')['files']
        config, captured, evaluated = (read(root / name) for name in ('config.json', 'capture.json', 'independent_metrics.json'))
        shared.verify_snapshot(workspace, snapshot, generated)
        require(config['source_files'] == snapshot['files'], 'Capture source manifest omits original author files')
        dataset_files = {}
        for dataset in plan['datasets']:
            for name, expected_hash in dataset.get('files_sha256', {}).items():
                require(sha(workspace / name) == expected_hash, 'Frozen dataset bytes changed')
                dataset_files[name] = expected_hash
        materialized = {}
        for copied, source_file in (
                ('runtime.py', 'src/experiments/discovered_series_capture.py'),
                ('common.py', 'src/experiments/discovered_capture.py'),
                ('strict_numeric_compatibility.py', 'src/experiments/strict_numeric_compatibility.py'),
                ('author_numeric_compatibility.py', 'src/experiments/author_numeric_compatibility.py'),
                ('author_values.py', 'src/author_values.py'), ('split_counts.py', 'src/split_counts.py'),
                ('native_loop.py', 'src/native_loop.py')):
            actual = sha(root / copied)
            require(actual == freeze['files'][source_file], 'Materialized capture code differs from source B')
            materialized[copied] = {'source_file': source_file, 'sha256': actual}
        validation, strict = read(run / 'strict_execution_verification.json'), read(run / 'strict_validation.json')
        require(validation == data['validation'] == execution['strict_execution_verification'], 'Official strict verification receipts disagree')
        require(strict == data['strict_validation'] and strict['status'] == 'verified', 'Strict pipeline status is not verified')
        fresh = shared.verify_strict_execution(plan, read(run / 'source_packet.json'), workspace, execution, spec_hash)
        fresh['dataset_provenance_verified'] = data['dataset_provenance']['verified']
        require(fresh == validation, 'Read-only host recheck differs from official direct result')
        require(validation['strict_validation'] is True and validation['paper_metrics_verified'] is True
                and validation['independent_metrics_pass'] is True and validation['is_reproduced'] is True,
                'Official direct result did not pass the complete frozen numerical rule')
        numeric = validation.get('numeric_compatibility', [])
        require(config.get('numeric_compatibility', []) == captured.get('numeric_compatibility', [])
                == evaluated.get('numeric_compatibility', []) == numeric, 'Numeric compatibility receipts disagree')
        audit_bindings = shared.verify_additional_audits(run, plan, spec_hash)
        report = (run / 'report.md').read_text('utf-8')
        require(data['report'] == report and Path(data['report_path']).resolve(strict=True) == (run / 'report.md').resolve(),
                'Official report is not the direct run report')
        require(shared.REPORT_FORMAT_VERSION == shared.report_format_version(report) == 3, 'Official direct report is not format 3')
        require('完整独立复算证据已核验' in report, 'Official report omits successful strict verification')
        require('本结果使用修复后的核验器离线重新核验' not in report, 'Direct report was mislabeled as an offline substitution')
        for comparison in validation['comparisons']:
            require(str(comparison['actual']) in report, 'Official report omits actual strict metric')
        for repair in numeric:
            require('数值兼容来源' in report and repair['source_sha256'] in report, 'Official report omits numeric compatibility provenance')
        cleanup = verify_cleanup(run, read(run / 'environment_cleanup.json'))
        processes = verify_processes(run, captured, evaluated, status, audit_bindings)
        result.update(official_state=original['state'], official_result_sha256=sha(run / 'result.json'),
                      strict_execution_verification_sha256=sha(run / 'strict_execution_verification.json'),
                      strict_validation_sha256=sha(run / 'strict_validation.json'), report_sha256=sha(run / 'report.md'),
                      report_format_version=3, comparisons=validation['comparisons'],
                      complete_native_runs=len(captured['runs']), optimizer_steps=captured['optimizer_steps'],
                      numeric_compatibility=numeric, additional_audits=audit_bindings,
                      frozen_author_files=len(snapshot['files']), frozen_dataset_files=dataset_files,
                      materialized_runtime_sources=materialized, cleanup=cleanup, owned_processes=processes,
                      history=verify_history(history, source_hash))
        require(audit_bindings == shared.verify_additional_audits(run, plan, spec_hash), 'Additional audit bindings changed during final review')
        shared.verify_snapshot(workspace, snapshot, generated)
        checks_complete = True
    except BaseException as exc:
        failure = exc
        result['error'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            if before is not None:
                after = inventory(run)
                result['run_files_after_sha256'] = digest(after)
                result['run_files_unchanged'] = before == after
                require(before == after, 'Final audit modified original direct-run evidence')
            if product_before is not None:
                require(product_before == shared.product_hashes(APP), 'Product source changed during final audit')
            result['pass'] = checks_complete and failure is None
        except BaseException as exc:
            result['pass'] = False
            failure = failure or exc
            result['immutability_error'] = {'type': type(exc).__name__, 'message': str(exc)}
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    print(json.dumps({key: result.get(key) for key in ('pass', 'run_dir', 'source_sha256', 'spec_sha256',
                                                      'complete_native_runs', 'comparisons', 'run_files_unchanged')},
                     ensure_ascii=False))
    if failure is not None or result['pass'] is not True:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
