"""Real PDF/API preparation regression. Credentials remain in process memory."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'AutoReproducer'
OUT = Path(__file__).parent / (sys.argv[1] if len(sys.argv) > 1 else 'planning_01')
EXECUTE = '--execute' in sys.argv
OUT.mkdir(parents=True, exist_ok=False)
os.environ['AUTOREPRO_DATA_ROOT'] = str(OUT / 'data')
os.environ['AUTOREPRO_DEPS_ROOT'] = str(OUT / 'deps')
sys.path.insert(0, str(ROOT))

from src.audit.audit_logger import AuditLogger
from src.discovered_repository_reproduction import DiscoveredRepositoryReproduction
from src.holdout_registry import digest, product_hashes
from src.llm.llm_client import LLMClient


def human_credential():
    # Reuse only the human-provided credential in this conversation, never print it.
    helper = ROOT / '.tmp/strict_validation_20261021/probe_real_planning.py'
    tree = ast.parse(helper.read_text('utf-8'))
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'credential')
    namespace = {'os': os, 'Path': Path, 'json': json, 're': re}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(helper), 'exec'), namespace)
    return namespace['credential']()


def main():
    key = human_credential()
    def clean(value):
        if isinstance(value, str):
            return value.replace(key, '[REDACTED]')
        if isinstance(value, list):
            return [clean(v) for v in value]
        if isinstance(value, dict):
            return {k: clean(v) for k, v in value.items()}
        return value
    def save(name, value):
        encoded = json.dumps(clean(value), ensure_ascii=False, indent=2, allow_nan=False)
        assert key not in encoded
        (OUT / name).write_text(encoded, encoding='utf-8')
    frozen = product_hashes(ROOT)
    save('source_freeze.json', {'source_sha256': digest(frozen), 'files': frozen})
    old = BASE / '.tmp/acceptance-chebnetii-cora-8akt_qpe'
    snapshot = json.loads((old / 'snapshot.json').read_text('utf-8'))
    cache = Path(snapshot['cache_path'])
    destination = OUT / 'data' / 'repository_cache' / cache.parent.name / cache.name
    shutil.copytree(cache, destination)
    client = LLMClient(api_key=key, base_url='https://api.deepseek.com', model='deepseek-chat', timeout=120)
    health = client.chat('Return exactly the word READY.', temperature=0, task='issue30_api_health')
    save('api_health.json', {'success': health.strip().upper() == 'READY', 'calls': client.get_call_count()})
    assert health.strip().upper() == 'READY', 'Real API health check failed'
    print('Real API ready; starting frozen PDF planning.', flush=True)
    logger = AuditLogger(log_dir=str(OUT / 'logs'), ledger_dir=str(OUT / 'ledger'))
    from src import strict_validation as strict_module
    original_assert = strict_module.assert_strict_plan
    def traced_assert(plan, packet, workspace):
        save('strict_candidate.json', plan)
        return original_assert(plan, packet, workspace)
    strict_module.assert_strict_plan = traced_assert
    request = {'pdf_path': str(ROOT / 'examples/papers/pdf/chebnetii_independent_20261011_function.pdf'),
        'offline': not EXECUTE, 'prepare_only': not EXECUTE, 'strict_validation': True,
        'paper_info': {'title': 'Convolutional Neural Networks on Graphs with Chebyshev Approximation, Revisited'},
        'resources': {'code_repo_url': snapshot['url'],
            'repo_discovery': {'selected_repo': snapshot['url'], 'pinned_revision': snapshot['revision']}}}
    save('request.json', request)
    def event(item):
        if item.get('type') in ('state', 'repository_output'):
            print(json.dumps(clean(item), ensure_ascii=False), flush=True)
    class CoraRegression(DiscoveredRepositoryReproduction):
        def _execute_frozen(self, request, data, plan, snapshot, *args):
            if EXECUTE:
                # Assert the regression target before consuming training resources.
                # This changes no plan or product workflow; mismatches remain failures.
                expected = ['python', 'training.py', '--net', 'ChebNetII', '--dataset', 'Cora',
                    '--K', '10', '--prop_lr', '0.001', '--prop_wd', '0.05', '--dprate', '0.8', '--semi_rnd', 'True']
                train = next(s for s in plan['steps'] if s['kind'] == 'train')
                assert plan['scope'] == 'selected_paper_experiment', 'Strict planning must pass before this acceptance training'
                assert train['cwd'] == 'main' and train['argv'] == expected, 'Automatic plan selected a different author experiment'
                assert plan['capture']['expected_runs'] == 10, 'Regression requires all ten native runs'
                assert all(d['kind'] == 'bundled' for d in plan['datasets']), 'Regression expects the actual bundled Cora inputs'
            return super()._execute_frozen(request, data, plan, snapshot, *args)
    try:
        result = CoraRegression(OUT / 'data', logger, llm=client).run(request, on_event=event)
    finally:
        strict_module.assert_strict_plan = original_assert
    assert frozen == product_hashes(ROOT), 'Product changed during real PDF planning'
    save('result.json', result)
    data = result['data']
    summary = {'state': result['state'], 'error': result.get('error'), 'strict_validation': data.get('strict_validation'),
        'run_dir': data.get('run_dir'), 'validation': data.get('validation'),
        'environment_cleanup': data.get('environment_cleanup'), 'calls': client.get_call_count(),
        'source_sha256': digest(frozen), 'training_executed': data.get('repository_executed')}
    save('summary.json', summary)
    print(json.dumps(clean({k: v for k, v in summary.items() if k != 'strict_validation'}), ensure_ascii=False), flush=True)
    strict = summary.get('strict_validation') or {}
    print(json.dumps(clean({'strict_status': strict.get('status'), 'strict_reason': strict.get('reason')}), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
