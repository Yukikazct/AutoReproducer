# 论文复现与优化报告
<!-- autoreproducer-report-format: 2 -->

**生成时间**: 2026-10-17 17:53:36
**工具**: AutoReproducer v0.2.0

## 1. 论文信息
- **标题**: A Critical Look at the Evaluation of GNNs under Heterophily: Are We Really Making Progress?
- **方法**: 论文质疑异配图（heterophily）下 GNN 的评测方式：指出 squirrel 和 chameleon 数据集存在大量重复节点导致训练-测试数据泄漏，提出五个新的异配图数据集（roman-empire、amazon-ratings、minesweeper、tolokers、questions）作为基准，并系统比较标准 GNN 与异配专用模型的性能。
- **数据集**: 
- **声明指标**: {}

- **论文全文阅读**: 完成；56110/56110 字符；1/1 批
- **阅读完成依据**: 连续覆盖全部提取文本，所有批次均返回有效结果；汇总笔记用于定位，实验判定引用原文。

## 2. 资源定位
- **代码仓库**: https://github.com/yandex-research/heterophilous-graphs
- **数据集**: 未找到
- **置信度**: 0.99
- **仓库关联证据**: 直接获取并运行所选仓库；不进行论文匹配审核。
- **发现来源**: pinned_git_direct_execution
- **执行范围**: 定位仓库是资源发现结果；是否运行仓库由下方执行对象和实际步骤确认。
- **PDF 仓库来源**: pdf_annotation，第 1 页
- **原文仓库链接**: https://github.com/yandex-research/heterophilous-graphs
- **证据类型**: author_code_statement
- **原文上下文**: of GNNs under heterophily. We show that standard GNNs achiev e strong results on these heterophilous graphs, almost always outpe rforming specialized models. Our datasets and the code for reproducing our experi ments are available at arXiv:2302.11640v2 \[cs.LG\] 2 Mar 2024 https://github.com/yandex-research/heterophilous-gr aphs .
- **来源 PDF SHA-256**: `9025d1a5a4258bc77dadc31528a68f7abbe6c08c3b9abf82ecb644e00811bd14`
- **从论文中提取URL**: 8 个
  - https://github.com/yandex-research/heterophilous-gr
  - http://www.cs.cmu.edu/afs/cs.cmu.edu/project/theo-1
  - https://snap.stanford.edu/data/amazon-meta.html
  - http://snap.stanford.edu/data
  - https://github.com/Toloka/TolokerGraph

### 官方仓库实验来源
- **实验定义**: 依据本次 PDF 与固定作者源码生成的实验计划
- **论文版本/参考位置**: 
- **固定源码版本**: `a431395582e929d88271309716bea4fe24ce6318`
- **实验定义SHA-256**: `7c1ecae36a2e24a38a7977256da735a89af198cc1147c1d17fdab530ebe0c3df`
- **独立运行目录**: `D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\data\runs\repository_d55b996038514ddd83831c4604e82155`
- **参数**: {}
- **真实数据SHA-256**: `9048289e642c97daa1542018bb066fc4e282c7414bc9eaf647f359c9646bfa34`
- **数据切分**: 由原文引用冻结的作者实验划分
- **协议说明**: 核验原作者完整命令的实际运行和进程结束；尚未验收论文数值。

- **作者协议来源**: 
- **实现版本说明**: 

### 本次 PDF 与作者源码确定的运行计划

- **运行范围**: 所选作者入口及其原始参数。
- **结束条件**: 全部所选命令正常返回、退出码为 0，所属进程已结束并清理。
- **运行结果**: 记录作者输出和实际训练更新；不进行论文、协议或数值审核。

**原始作者命令**

- train-resnet-roman-empire-l1，目录：.
```json
["python", "train.py", "--name", "ResNet_l1", "--dataset", "roman-empire", "--model", "ResNet", "--num_layers", "1", "--device", "cuda:0"]
```

## 3. 环境配置
- **Python版本**: 3.12
- **依赖数**: 13
- **环境适配**: 基于作者依赖与源码导入选择的项目 CUDA 兼容环境；不是论文原始运行环境的等价声明。

### 训练解释器尝试

- CPython 3.12：isolated\_existing

### 自动环境恢复

- **运行环境**: 使用兼容的标准 Python 运行预设
- **实际依赖检查**: 2/4 次通过（导入、版本与原生运算）
- **缓存修复**: 0/1 项完成；依赖版本与实验协议保持冻结

### 根据运行报错补充依赖

- 第 1 轮：缺少 dgl，安装 dgl 后重试；原失败日志保留在运行目录。

### 执行失败分析

- execution\_failure；动作：blocked；The author code imports 'dgl' \(from dgl import ops in modules.py\), but the installed compatibility requirements do not include dgl, and the author declaration lists 'dgl-cuda11.7' which is not installable on Python 3.12 / torch 2.5.1+cu121. No pip error naming a candidate dgl version is present, so no replacement pin can be derived.
- installation\_failed；动作：blocked；The unpinned 'dgl' requirement resolved to a DGL wheel whose C++ graphbolt native library \(graphbolt\_pytorch\_2.5.1.dll\) is missing for this Windows/Python 3.12/torch 2.5.1 environment; the pip install itself exited 0, so this is a missing prebuilt binary, not a version conflict. No pip error names a candidate replacement version, and 'dgl' is an author-declared dependency \(author\_requirements lists dgl-cuda11.7\), so a compatibility pin replacement is not permitted.
- **磁盘统计**: 未测量（安装与执行后读取实际大小，不展示模型估值）

### requirements.txt
```
--extra-index-url https://download.pytorch.org/whl/cu121
numpy==1.26.4
pyyaml==6.0.2
scikit-learn==1.5.2
torch==2.5.1+cu121
tqdm==4.67.1
dgl
scipy==1.14.1
networkx==2.8.8
requests==2.32.3
psutil==6.1.0
setuptools==69.5.1
packaging==24.2

```

## 4. 代码执行
- **执行对象**: 固定版本作者仓库中的实验入口（多文件）
- **执行状态**: ⚠️ 未运行（仓库实验尚未执行）
- **未运行原因**: 依赖安装失败（已尝试 2 轮），无法在本地环境执行:
第 1 轮（https://pypi.tuna.tsinghua.edu.cn/simple, exit=0）:  依赖健康检查失败(exit=1): df_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\__init__.py", line 13, in <module>
    from .dataloader import *
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\dataloader.py", line 27, in <module>
    from ..distributed import DistGraph
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\__init__.py", line 5, in <module>
    from .dist_graph import DistGraph, DistGraphServer, edge_split, node_split
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\dist_graph.py", line 11, in <module>
    from .. import backend as F, graphbolt as gb, heterograph_index
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 36, in <module>
    load_graphbolt()
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 26, in load_graphbolt
    raise FileNotFoundError(
FileNotFoundError: Cannot find DGL C++ graphbolt library at D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\graphbolt_pytorch_2.5.1.dll
第 2 轮（https://pypi.tuna.tsinghua.edu.cn/simple, exit=0）:  依赖健康检查失败(exit=1): df_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\__init__.py", line 13, in <module>
    from .dataloader import *
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\dataloader.py", line 27, in <module>
    from ..distributed import DistGraph
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\__init__.py", line 5, in <module>
    from .dist_graph import DistGraph, DistGraphServer, edge_split, node_split
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\dist_graph.py", line 11, in <module>
    from .. import backend as F, graphbolt as gb, heterograph_index
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 36, in <module>
    load_graphbolt()
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 26, in load_graphbolt
    raise FileNotFoundError(
FileNotFoundError: Cannot find DGL C++ graphbolt library at D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\graphbolt_pytorch_2.5.1.dll
依赖清单: --extra-index-url https://download.pytorch.org/[URL details removed]
numpy==1.26.4
pyyaml==6.0.2
scikit-learn==1.5.2
torch==2.5.1+cu121
tqdm==4.67.1
dgl
scipy==1.14.1
networkx==2.8.8
requests==2.32.3
...

### 官方仓库执行命令

- **train-resnet-roman-empire-l1** · cwd: `.`
```json
["python", "-u", "_autorepro_capture/observe_author.py", "train-resnet-roman-empire-l1"]
```

### 执行输出(full)
```

```
### 诊断输出（stderr）
```
依赖安装失败（已尝试 2 轮），无法在本地环境执行:
第 1 轮（https://pypi.tuna.tsinghua.edu.cn/simple, exit=0）:  依赖健康检查失败(exit=1): df_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\__init__.py", line 13, in <module>
    from .dataloader import *
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\dataloader.py", line 27, in <module>
    from ..distributed import DistGraph
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\__init__.py", line 5, in <module>
    from .dist_graph import DistGraph, DistGraphServer, edge_split, node_split
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\dist_graph.py", line 11, in <module>
    from .. import backend as F, graphbolt as gb, heterograph_index
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 36, in <module>
    load_graphbolt()
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 26, in load_graphbolt
    raise FileNotFoundError(
FileNotFoundError: Cannot find DGL C++ graphbolt library at D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\graphbolt_pytorch_2.5.1.dll
第 2 轮（https://pypi.tuna.tsinghua.edu.cn/simple, exit=0）:  依赖健康检查失败(exit=1): df_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\__init__.py", line 13, in <module>
    from .dataloader import *
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\dataloader.py", line 27, in <module>
    from ..distributed import DistGraph
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\__init__.py", line 5, in <module>
    from .dist_graph import DistGraph, DistGraphServer, edge_split, node_split
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\dist_graph.py", line 11, in <module>
    from .. import backend as F, graphbolt as gb, heterograph_index
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 36, in <module>
    load_graphbolt()
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 26, in load_graphbolt
    raise FileNotFoundError(
FileNotFoundError: Cannot find DGL C++ graphbolt library at D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\graphbolt_pytorch_2.5.1.dll
依赖清单: --extra-index-url https://download.pytorch.org/[URL details removed]
numpy==1.26.4
pyyaml==6.0.2
scikit-learn==1.5.2
torch==2.5.1+cu121
tqdm==4.67.1
dgl
scipy==1.14.1
networkx==2.8.8
requests==2.32.3
...
```

## 5. 运行结果
- **复现状态**: ❌ 执行失败（不能判定论文数值复现）
- **分析**: 无
- **判定原因**: 作者训练或独立评估未完整结束：owser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\graphbolt_pytorch_2.5.1.dll
第 2 轮（https://pypi.tuna.tsinghua.edu.cn/simple, exit=0）:  依赖健康检查失败(exit=1): df_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\__init__.py", line 13, in <module>
    from .dataloader import *
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\dataloading\dataloader.py", line 27, in <module>
    from ..distributed import DistGraph
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\__init__.py", line 5, in <module>
    from .dist_graph import DistGraph, DistGraphServer, edge_split, node_split
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\distributed\dist_graph.py", line 11, in <module>
    from .. import backend as F, graphbolt as gb, heterograph_index
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 36, in <module>
    load_graphbolt()
  File "D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\__init__.py", line 26, in load_graphbolt
    raise FileNotFoundError(
FileNotFoundError: Cannot find DGL C++ graphbolt library at D:\code\AutoReproducer\AutoReproducer\.tmp\acceptance_pdf_browser_20261017\deps\repository\cpython-312-win32-AMD64\d90d01c545e4af64\dgl\graphbolt\graphbolt_pytorch_2.5.1.dll
依赖清单: --extra-index-url https://download.pytorch.org/[URL details removed]
numpy==1.26.4
pyyaml==6.0.2
scikit-learn==1.5.2
torch==2.5.1+cu121
tqdm==4.67.1
dgl
scipy==1.14.1
networkx==2.8.8
requests==2.32.3
...

## 6. 智能优化
- **优化状态**: 未触发(运行已冻结作者实验协议)

## 7. 运行与用量统计
- **总步骤数**: 29
- **成功步数**: 8
- **错误步数**: 2
- **执行时长**: 1360.19 秒
- **LLM 调用次数**: 6 （用于用量审计；全文阅读不设总调用预算）

---
*报告由 AutoReproducer 自动生成*

---

> 📎 **完整执行输出附件**: `A_Critical_Look_at_the_Evaluat_20261017_173056_execution.txt`（同一目录下，未被截断）
