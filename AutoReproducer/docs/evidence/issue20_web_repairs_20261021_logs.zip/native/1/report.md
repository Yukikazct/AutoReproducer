# 论文复现与优化报告
<!-- autoreproducer-report-format: 2 -->

**生成时间**: 2026-10-21 17:25:57
**工具**: AutoReproducer v0.2.0

## 1. 论文信息
- **标题**: Invented protocol integration fixture
- **方法**: 未知
- **数据集**: 未知
- **声明指标**: {}

## 2. 资源定位
- **代码仓库**: https://github.com/invented-fixtures/signals
- **数据集**: 未找到
- **置信度**: 0.00
- **仓库关联证据**: 直接获取并运行所选仓库；不进行论文匹配审核。
- **发现来源**: pinned_git_direct_execution
- **执行范围**: 定位仓库是资源发现结果；是否运行仓库由下方执行对象和实际步骤确认。
- **PDF 仓库来源**: pdf_text，第 1 页
- **原文仓库链接**: https://github.com/invented-fixtures/signals
- **证据类型**: author_code_statement
- **原文上下文**: Separating Signed Signals Abstract Our source code is available at https://github.com/invented-fixtures/signals Signal Linear uses the complete SignGrid dataset and fixed test split.
- **来源 PDF SHA-256**: `70def0e5f75486872053168d89357eb12a9ca5c6a8ea2c68c8ade09affd41df2`

### 官方仓库实验来源
- **实验定义**: 依据本次 PDF 与固定作者源码生成的实验计划
- **论文版本/参考位置**: 
- **固定源码版本**: `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
- **实验定义SHA-256**: `563440cc03e1311eccb19d7354b8b6b4977f9833f5a29d3a63765431bc3ce4dd`
- **独立运行目录**: `D:\code\AutoReproducer\.tmp\issue20-final-acceptance\test_real_service_two_file_rep0\service\runs\repository_a651db77ea0c41beb94237920e3328e3`
- **参数**: {}
- **真实数据SHA-256**: `0d237357348ea2771ad6a01b295a11f83632210852170672086a5ff8bbc31b48`
- **数据切分**: 由原文引用冻结的作者实验划分
- **协议说明**: 核验原作者完整命令的实际运行和进程结束；尚未验收论文数值。

- **作者协议来源**: 
- **实现版本说明**: 

### 本次 PDF 与作者源码确定的运行计划

- **运行范围**: 所选作者入口及其原始参数。
- **结束条件**: 全部所选命令正常返回、退出码为 0，所属进程已结束并清理。
- **运行结果**: 记录作者输出和实际训练更新；不进行论文、协议或数值审核。

**原始作者命令**

- train，目录：.
```json
["python", "train.py", "--epochs", "40", "--seed", "7", "--cpu"]
```


### 兼容性源码修复

- **状态**: succeeded
- **授权范围**: train.py, author\_model.py
- **补丁轮数**: 1 / 2；每轮整体校验、完整原命令重跑，失败或取消整体回滚。
- 原始源码、来源包与冻结计划保留；补丁仅作用于独立修复副本。修改后执行不构成原始源码严格复现或独立论文数值核验。
- **原始副本**: D:\\code\\AutoReproducer\\.tmp\\issue20-final-acceptance\\test\_real\_service\_two\_file\_rep0\\service\\runs\\repository\_a651db77ea0c41beb94237920e3328e3\\repo
- **修复副本**: D:\\code\\AutoReproducer\\.tmp\\issue20-final-acceptance\\test\_real\_service\_two\_file\_rep0\\service\\runs\\repository\_a651db77ea0c41beb94237920e3328e3\\repair\_workspace
- **修复结果与失败报告**: \\\\?\\D:\\code\\AutoReproducer\\.tmp\\issue20-final-acceptance\\test\_real\_service\_two\_file\_rep0\\service\\runs\\repository\_a651db77ea0c41beb94237920e3328e3\\.autorepro\_repository\_repairs\\5bde45a0ea2a4fea889e51e0ee217de7\\repair\_report.md
- **结构化审计记录**: \\\\?\\D:\\code\\AutoReproducer\\.tmp\\issue20-final-acceptance\\test\_real\_service\_two\_file\_rep0\\service\\runs\\repository\_a651db77ea0c41beb94237920e3328e3\\.autorepro\_repository\_repairs\\5bde45a0ea2a4fea889e51e0ee217de7\\repairs.json
- **修复清单 SHA-256**: `262c4a17518471467e74bc57e215da9e4db98dab54926e4c71a1f129dea6121e`

- 第 1 轮：succeeded；Align existing no-op initialization API spellings.
  author\_model.py：`e1769bde5d7baeb20fc351272973e55a1efbaabf40aa8830e23e5bb1e1b26fe9` → `0d701d3677368b6134ac77dd59794e93938d7d860dec0268d055040df04633da`
  train.py：`02293d51dde99ff99e1c37d9a27bf13516145413097385c9c27a9204d0b922a0` → `20184723ef57f17a29e9583f096ee44b5f977b759226a968b4dfcf1585c3d069`

[源码修复证据 ZIP](report_assets/source_repair_2c0c25ccfc2312864469c7776889929def5bd3479e1a49f51c211eeb6882ad5d.zip) <!-- sha256:2c0c25ccfc2312864469c7776889929def5bd3479e1a49f51c211eeb6882ad5d -->
附件包含逐轮 proposal、diff、结果、回滚记录与完整进程日志；成员哈希与脱敏状态见 evidence_manifest.json。
## 3. 环境配置
- **Python版本**: 3.12
- **依赖数**: 3
- **环境适配**: 基于作者依赖与源码导入选择的项目 CPU 兼容环境；不是论文原始运行环境的等价声明。

### 训练解释器尝试

- CPython 3.12：isolated\_existing

### 自动环境恢复

- **实际依赖检查**: 3/3 次通过（导入、版本与原生运算）

### 自动诊断与修复

- 状态：缺少可验证的自动修复方案；当前错误没有通过校验的自动修复方案；保留实际错误和源码依据。
- 每次修复都重跑原命令；此处记录运行恢复情况，论文数值核验另行记录。

### 执行失败分析

- execution\_failure；动作：blocked；保留原始错误与所需条件
- **磁盘统计**: 未测量（安装与执行后读取实际大小，不展示模型估值）

### requirements.txt
```
--extra-index-url https://download.pytorch.org/whl/cpu
numpy==1.26.4
torch==2.5.1+cpu

```

## 4. 代码执行
- **执行对象**: 兼容补丁后的独立作者源码副本（多文件）；原始源码保留
- **执行状态**: ✅ 成功
  - full: ✅ 通过 (退出码 0)

### 官方仓库执行命令

- **train** · cwd: `D:\code\AutoReproducer\.tmp\issue20-final-acceptance\test_real_service_two_file_rep0\service\runs\repository_a651db77ea0c41beb94237920e3328e3\repair_workspace`
```json
["D:\\code\\AutoReproducer\\.tmp\\issue20-final-acceptance\\test_real_service_two_file_rep0\\service\\training_python\\envs\\cpython-3.12\\Scripts\\python.exe", "train.py", "--epochs", "40", "--seed", "7", "--cpu"]
```
- 完整日志: `\\?\D:\code\AutoReproducer\.tmp\issue20-final-acceptance\test_real_service_two_file_rep0\service\runs\repository_a651db77ea0c41beb94237920e3328e3\.autorepro_repository_runs\f27edd37f01a4117a0b7939d9baa9f38\train.stdout.log`

### 执行输出(full)
```
Test Accuracy: 1.0

```

## 5. 运行结果
- **复现状态**: 作者仓库代码运行完成（未进行论文数值审核）
- **分析**: 无
- **判定原因**: 兼容性源码修改后的完整原命令已正常结束；原始来源保留，尚未判定论文数值复现。
- **运行说明**: 执行使用明确授权的兼容性源码补丁；未独立核验算法语义、训练更新或论文数值。
- **执行级别**: 原作者命令运行完成

### 作者输出与论文宣称对比

No paper claim selected by this fixture model. 本次实际输出来自兼容补丁后的源码，未作为原始源码或独立论文复现证明。

本表使用作者程序输出，尚未独立复算。数值对比不影响代码完成状态。
实际输出中的指标保留在下方证据表；未将其他数据集或基线指标作为参考。


### 实际指标证据
| 指标 | 实测值 | 单位 | 数据划分 | 阶段 | 来源 |
|------|------|------|----------|------|------|
| accuracy | 1.0 | 未标注 | test | final | train:stdout:1 |

## 6. 智能优化
- **优化状态**: 未触发(运行已冻结作者实验协议)

## 7. 运行与用量统计
- **总步骤数**: 17
- **成功步数**: 6
- **错误步数**: 0
- **执行时长**: 21.63 秒
- **LLM 调用次数**: 4 （用于用量审计；全文阅读不设总调用预算）

---
*报告由 AutoReproducer 自动生成*