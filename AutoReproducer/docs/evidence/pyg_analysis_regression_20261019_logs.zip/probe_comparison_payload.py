"""One diagnostic request with the original oversized comparison context."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from src.author_claim_comparison import compare_author_claims
from src.llm.llm_client import LLMClient

read = lambda path: json.loads(path.read_text('utf-8'))
original = base / 'data/runs/repository_01d9e1f2edf945eba2f813ee9bb352f6'
out = base / 'pyg_comparison_payload_diagnostic.json'
key = os.environ.pop('AUTOREPRO_TEST_KEY')
class ProbeDone(BaseException):
    pass
class ProbeClient(LLMClient):
    def chat(self, prompt, **kwargs):
        # Keep the originally failing input even if the bounded-view repair is
        # concurrently installed before this diagnostic process imports it.
        from src.discovered_repository_plan import _planning_view, _canonical
        prompt = prompt.split('\nOriginal sources:\n', 1)[0] + '\nOriginal sources:\n' + _canonical(_planning_view(packet))
        response = super().chat(prompt, **kwargs)
        safe = str(response).replace(key, '[REDACTED]')
        safe = re.sub(r'\bsk-[A-Za-z0-9_-]{24,}', '[REDACTED]', safe)
        record = {'evaluation_type': 'one_request_diagnostic_only', 'training_rerun': False,
                  'prompt_characters': len(prompt), 'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
                  'response_sha256': hashlib.sha256(str(response).encode()).hexdigest(),
                  'response': safe[:12000], 'finish_reason': self.last_finish_reason,
                  'usage': self.last_usage}
        with out.open('x', encoding='utf-8') as stream:
            json.dump(record, stream, ensure_ascii=False, indent=2)
        print(json.dumps(record, ensure_ascii=False), flush=True)
        raise ProbeDone()
packet = read(original / 'source_packet.json')
plan = read(original / 'experiment_spec.json')['spec']
execution = read(original / 'execution.json')
client = ProbeClient(api_key=key, base_url='https://api.deepseek.com', model='deepseek-chat', timeout=60)
try:
    compare_author_claims(client, packet, plan, original / 'repo', execution,
        sources={p: r['sha256'] for p, r in packet['file_inventory'].items()})
except ProbeDone:
    pass
