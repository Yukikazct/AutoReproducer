"""Publish and verify a separately labelled analysis regression report."""
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / '.tmp/browser-tools'), str(ROOT)]
from src.agents.report_generator import ReportGeneratorAgent
from src.report_revisions import sanitize_report_result
from frontend.backend_pipeline import ProgressStore, _sync_run_report
from scripts.verify_browser_pdf_holdout import verify_claim_comparison, verify_report_reconnect
from playwright.sync_api import sync_playwright

base = Path(__file__).resolve().parent
out = base / 'pyg_analysis_replay_01'
result = json.loads((out / 'result_before_report.json').read_text('utf-8'))
data = result['data']
original = Path(data['analysis_replay']['original_run'])
verify_claim_comparison(result)
data['execution']['author_execution_verification'] = data['validation']
data['run_dir'] = str(out)
report = base / 'data/reports/pyg_analysis_replay_20261019_01.md'
data['report_path'] = result['report_path'] = str(report)
text = ReportGeneratorAgent()._build_report(data, report_path=report)
text += '\n\n> 分析回归验证：复用已完成的作者训练日志，从同一 PDF 重新解析证据；未重新训练，不作为新论文独立验收。\n'
attachment = report.with_name(report.stem + '_execution.txt')
attachment.write_bytes(next(original.glob('*_execution.txt')).read_bytes())
text += '\n\n---\n\n> 📎 **完整执行输出附件**: `' + attachment.name + '`（同一目录下，未被截断）\n'
data.update(report=text, report_length=len(text))
report.write_text(text, encoding='utf-8')
safe = sanitize_report_result(result)
_sync_run_report(safe)
report.with_suffix('.result.json').write_text(json.dumps(safe, ensure_ascii=False, indent=2), encoding='utf-8')
runtime = base / 'data/runtime'
progress = runtime / ('progress_' + str(int(time.time() * 1000)) + '.jsonl')
ProgressStore(str(progress)).emit({'type': 'done', 'result': safe})
(out / 'report_locations.json').write_text(json.dumps({'progress': str(progress), 'report': str(report)}, indent=2), encoding='utf-8')
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(channel='chrome', headless=True)
    page = browser.new_page()
    page.goto('http://127.0.0.1:8505/?run=' + progress.name, wait_until='domcontentloaded')
    try:
        evidence = verify_report_reconnect(page, SimpleNamespace(port=8505, tag='pyg_analysis_replay_20261019_01'),
                                           progress, runtime, safe)
    finally:
        page.screenshot(path=str(out / 'report.png'), full_page=True)
        (out / 'browser_text.txt').write_text(page.locator('body').inner_text(), encoding='utf-8')
        browser.close()
evidence.update(training_rerun=False, independent_acceptance=False)
(out / 'browser_verification.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'browser_report_verified': True, 'report': str(report), 'output': str(out)}, ensure_ascii=False))
