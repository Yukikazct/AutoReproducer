"""Separate analysis regression on completed immutable author training."""
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from src.author_claim_comparison import compare_author_claims, collect_author_metrics
from src.author_comparison_context import prepare_comparison_packet, comparison_view, comparison_plan
from src.discovered_repository_plan import _canonical
from src.llm.llm_client import LLMClient
from src.pdf_input import extract_pdf_input
from src.holdout_registry import digest, product_hashes
from scripts.verify_browser_pdf_holdout import verify_claim_comparison

read = lambda path: json.loads(path.read_text('utf-8'))
original = base / 'data/runs/repository_01d9e1f2edf945eba2f813ee9bb352f6'
packet = read(original / 'source_packet.json')
plan = read(original / 'experiment_spec.json')['spec']
execution = read(original / 'execution.json')
document = extract_pdf_input(ROOT / 'examples/papers/candidates_20261019_highstar/pyg.pdf')
assert document.sha256 == packet['pdf']['sha256']
packet['pdf']['pages'] = [{'page': i, 'text': text, 'sha256': hashlib.sha256(text.encode()).hexdigest()}
                         for i, text in enumerate(document.page_texts, 1)]
prepared = prepare_comparison_packet(packet, plan, original / 'repo')
records, _ = collect_author_metrics(execution, workspace=original / 'repo', plan=plan,
    sources={p: r['sha256'] for p, r in packet['file_inventory'].items()})
view = comparison_view(prepared, plan, records)
assert 'benchmark/citation/train_eval.py' in view['repository']['files']
print(json.dumps({'view_characters': len(_canonical(view)), 'plan_characters': len(_canonical(comparison_plan(plan))),
    'source_selection': view['source_selection'], 'discovery': prepared['comparison_source_discovery']}, ensure_ascii=False), flush=True)
if '--inspect' in sys.argv:
    raise SystemExit(0)
out = base / os.environ.get('AUTOREPRO_REPLAY_TAG', 'pyg_analysis_replay_01')
out.mkdir(exist_ok=False)
key = os.environ.pop('AUTOREPRO_TEST_KEY')
class TraceClient(LLMClient):
    def chat(self, prompt, **kwargs):
        response = super().chat(prompt, **kwargs)
        calls.append({'prompt_characters': len(prompt), 'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
                      'finish_reason': self.last_finish_reason, 'usage': self.last_usage})
        return response
calls = []
client = TraceClient(api_key=key, base_url='https://api.deepseek.com', model='deepseek-chat', timeout=180)
snapshot = product_hashes(ROOT)
(out / 'source_packet.json').write_text(json.dumps(prepared, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(out / 'source_freeze.json').write_text(json.dumps({'product_sha256': digest(snapshot), 'files': snapshot}, indent=2), encoding='utf-8')
comparison = compare_author_claims(client, packet, plan, original / 'repo', execution,
    sources={p: r['sha256'] for p, r in packet['file_inventory'].items()})
assert snapshot == product_hashes(ROOT), 'Product changed during analysis replay'
result = read(original / 'result.json')
data = result['data']
data['validation']['author_claim_comparison'] = comparison
data['validation']['metric_records'] = comparison['metric_records']
data['metric_parse_errors'] = comparison['parse_errors']
data['analysis_replay'] = {'original_run': str(original), 'training_rerun': False,
    'independent_acceptance': False, 'product_source_sha256': digest(snapshot),
    'pdf_reextracted_from_original_bytes': True, 'model_calls': calls,
    'original_execution_sha256': hashlib.sha256((original / 'execution.json').read_bytes()).hexdigest()}
for name, value in [('author_claim_comparison.json', comparison), ('result_before_report.json', result)]:
    encoded = json.dumps(value, ensure_ascii=False, indent=2)
    assert key not in encoded
    (out / name).write_text(encoded + '\n', encoding='utf-8')
print(json.dumps({'status': comparison['status'], 'errors': comparison['validation_errors'],
    'diagnostic': comparison.get('diagnostic'), 'model_calls': calls,
    'rows': [{'actual': row['actual'], 'reference': row['reference'], 'status': row['status'],
              'difference': row['difference'], 'limitations': row['limitations']} for row in comparison['comparisons']]},
    ensure_ascii=False), flush=True)
verify_claim_comparison(result)
print(json.dumps({'comparison_verified': True, 'output': str(out)}), flush=True)
