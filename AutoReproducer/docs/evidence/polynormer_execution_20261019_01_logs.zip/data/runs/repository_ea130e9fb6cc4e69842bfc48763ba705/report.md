# 论文复现与优化报告
<!-- autoreproducer-report-format: 2 -->

**生成时间**: 2026-10-19 11:40:12
**工具**: AutoReproducer v0.2.0

## 1. 论文信息
- **标题**: Polynormer: Polynomial-Expressive Graph Transformer in Linear Time
- **方法**: Polynormer 是一种线性复杂度的多项式表达图 Transformer。它基于一个显式学习输入特征高阶多项式的基模型，通过分别结合图拓扑与节点特征，导出局部与全局等变注意力模型，并采用局部到全局的线性注意力方案学习系数由注意力分数控制的高阶等变多项式。
- **数据集**: 
- **声明指标**: {}

- **论文全文阅读**: 完成；89993/89993 字符；1/1 批
- **阅读完成依据**: 连续覆盖全部提取文本，所有批次均返回有效结果；汇总笔记用于定位，实验判定引用原文。

## 2. 资源定位
- **代码仓库**: https://github.com/cornell-zhang/Polynormer
- **数据集**: 未找到
- **置信度**: 0.95
- **仓库关联证据**: 直接获取并运行所选仓库；不进行论文匹配审核。
- **发现来源**: pinned_git_direct_execution
- **执行范围**: 定位仓库是资源发现结果；是否运行仓库由下方执行对象和实际步骤确认。
- **PDF 仓库来源**: pdf_text，第 1 页
- **原文仓库链接**: https://github.com/cornell-zhang/Polynormer
- **证据类型**: repository_link
- **原文上下文**: ets, including large graphs with millions of nodes. Our extensive experiment results show that Polynormer outperforms state-of-the-art GNN and GT baselines on most datasets, even without the use of nonlinear activation functions. Source code of Polynormer is freely available at: github.com/cornell-zhang/Polynormer. 1 I NTRODUCTION As conventional graph neural networks \(GNNs\) are built upon the message passing scheme by ex- changing information between adjacent nodes, they
- **来源 PDF SHA-256**: `b48d05ad91bc923b4406b3cc4d29295ccc3ea23ffebfb82fc5fcdaa0af48bb7c`
- **从论文中提取URL**: 10 个
  - https://openreview.net/forum?id=JHcqXGaqiGn
  - https://openreview.net/forum?id=0pdSt3oyJa1
  - https://proceedings.mlr.press/v162/chen22r.html
  - https://openreview.net/forum?
  - https://openreview.net/forum?id=huAdB-Tj4yG

### 官方仓库实验来源
- **实验定义**: 依据本次 PDF 与固定作者源码生成的实验计划
- **论文版本/参考位置**: 
- **固定源码版本**: `fc8c276c9c5dfbd616d83f65338a3392188a5e08`
- **实验定义SHA-256**: `5cb98bcdb96d87323907384eb9e3316229836798876df3d5adbd96ad58fd6be8`
- **独立运行目录**: `D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705`
- **参数**: {}
- **数据来源核验**: 尚未完整核验；作者程序负责加载输入，不据此认定数据规模或论文数值通过。
- **协议说明**: 核验原作者完整命令的实际运行和进程结束；尚未验收论文数值。

- **作者协议来源**: 
- **实现版本说明**: 

### 本次 PDF 与作者源码确定的运行计划

- **运行范围**: 所选作者入口及其原始参数。
- **结束条件**: 全部所选命令正常返回、退出码为 0，所属进程已结束并清理。
- **运行结果**: 记录作者输出和实际训练更新；不进行论文、协议或数值审核。

**原始作者命令**

- train-amazon-computer，目录：.
```json
["python", "main.py", "--dataset", "amazon-computer", "--hidden_channels", "64", "--local_epochs", "200", "--global_epochs", "1000", "--lr", "0.001", "--runs", "1", "--local_layers", "5", "--global_layers", "1", "--weight_decay", "5e-5", "--dropout", "0.7", "--in_dropout", "0.2", "--num_heads", "8", "--device", "0", "--save_model"]
```

## 3. 环境配置
- **Python版本**: 3.12
- **依赖数**: 16
- **环境适配**: 基于作者依赖与源码导入选择的项目 CUDA 兼容环境；不是论文原始运行环境的等价声明。

### 训练解释器尝试

- CPython 3.12：isolated\_existing

### 自动环境恢复

- **运行环境**: 使用兼容的标准 Python 运行预设
- **实际依赖检查**: 3/3 次通过（导入、版本与原生运算）

### 自动诊断与修复

- 状态：原命令重跑通过；修复后的原命令已实际重跑并正常退出。
- 每次修复都重跑原命令；此处记录运行恢复情况，论文数值核验另行记录。
- 第 1 轮：install\_missing\_dependency；原命令重跑通过；根据实际错误安装 gdown，重跑原命令验证。

### 根据运行报错补充依赖

- 第 1 轮：缺少 gdown，安装 gdown 后重试；原失败日志保留在运行目录。
- **磁盘统计**: 未测量（安装与执行后读取实际大小，不展示模型估值）

### requirements.txt
```
--extra-index-url https://download.pytorch.org/whl/cu121
aiohttp==3.10.10
fsspec==2024.10.0
jinja2==3.1.6
numpy==1.26.4
ogb==1.3.6
pandas==2.2.3
psutil==6.1.0
pyparsing==3.2.0
requests==2.32.3
scikit-learn==1.5.2
scipy==1.14.1
torch==2.5.1+cu121
torch-geometric==2.6.1
tqdm==4.67.1
gdown

```

## 4. 代码执行
- **执行对象**: 固定版本作者仓库中的实验入口（多文件）
- **执行状态**: ✅ 成功
  - full: ✅ 通过 (退出码 0)

### 官方仓库执行命令

- **train-amazon-computer** · cwd: `D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo`
```json
["D:\\code\\AutoReproducer\\AutoReproducer\\.tmp\\pdf_selfrepair_20261019\\data\\training_python\\envs\\cpython-3.12\\Scripts\\python.exe", "-u", "_autorepro_capture/observe_author.py", "train-amazon-computer"]
```
- 完整日志: `D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\.autorepro_repository_runs\fdb1b2a34f764bbeb45833d4b4307b93\train-amazon-computer.stdout.log`

### 执行输出(full)
```
Namespace(dataset='amazon-computer', data_dir='./data/', device=0, seed=42, cpu=False, local_epochs=200, global_epochs=1000, runs=1, metric='acc', method='poly', hidden_channels=64, local_layers=5, global_layers=1, num_heads=8, beta=-1.0, pre_ln=False, lr=0.001, weight_decay=5e-05, in_dropout=0.2, dropout=0.7, global_dropout=0.7, display_step=1, save_model=True, model_dir='./model/', save_result=False)
amazon-computer
dataset amazon-computer | num nodes 13752 | num edge 491722 | num node feats 767 | num classes 10
MODEL: Polynormer(
  (h_lins): ModuleList(
    (0-4): 5 x Linear(in_features=512, out_features=512, bias=True)
  )
  (local_convs): ModuleList(
    (0-4): 5 x GATConv(512, 64, heads=8)
  )
  (lins): ModuleList(
    (0-4): 5 x Linear(in_features=512, out_features=512, bias=True)
  )
  (lns): ModuleList(
    (0-4): 5 x LayerNorm((512,), eps=1e-05, elementwise_affine=True)
  )
  (lin_in): Linear(in_features=767, out_features=512, bias=True)
  (ln): LayerNorm((512,), eps=1e-05, elementwise_affine=True)
  (global_attn): GlobalAttn(
    (h_lins): ModuleList(
      (0): Linear(in_features=512, out_features=512, bias=True)
    )
    (k_lins): ModuleList(
      (0): Linear(in_features=512, out_features=512, bias=True)
    )
    (v_lins): ModuleList(
      (0): Linear(in_features=512, out_features=512, bias=True)
    )
    (lns): ModuleList(
      (0): LayerNorm((512,), eps=1e-05, elementwise_affine=True)
    )
    (lin_out): Linear(in_features=512, out_features=512, bias=True)
  )
  (pred_local): Linear(in_features=512, out_features=10, bias=True)
  (pred_global): Linear(in_features=512, out_features=10, bias=True)
)
Epoch: 00, Loss: 2.4456, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 01, Loss: 2.1874, Train: 15.80%, Valid: 16.29%, Test: 14.69%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 02, Loss: 2.1331, Train: 15.50%, Valid: 16.00%, Test: 15.38%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 03, Loss: 2.0816, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 04, Loss: 2.0517, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 05, Loss: 2.0626, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 06, Loss: 2.0227, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 07, Loss: 2.0114, Train: 37.53%, Valid: 36.11%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 08, Loss: 2.0102, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 09, Loss: 1.9880, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 10, Loss: 1.9830, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 11, Loss: 1.9743, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 12, Loss: 1.9749, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 13, Loss: 1.9639, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 14, Loss: 1.9640, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 15, Loss: 1.9689, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 16, Loss: 1.9386, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 17, Loss: 1.9298, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 18, Loss: 1.9293, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 19, Loss: 1.9339, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 20, Loss: 1.9206, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 21, Loss: 1.9146, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 22, Loss: 1.9189, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 23, Loss: 1.9099, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 24, Loss: 1.9049, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 25, Loss: 1.9102, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 26, Loss: 1.8956, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 27, Loss: 1.8884, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 28, Loss: 1.8832, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 29, Loss: 1.8844, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 30, Loss: 1.8709, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 31, Loss: 1.8735, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 32, Loss: 1.8673, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 33, Loss: 1.8652, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 34, Loss: 1.8574, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 35, Loss: 1.8510, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 36, Loss: 1.8441, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 37, Loss: 1.8274, Train: 37.61%, Valid: 36.11%, Test: 38.53%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 38, Loss: 1.8119, Train: 37.55%, Valid: 36.00%, Test: 38.50%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 39, Loss: 1.7807, Train: 37.73%, Valid: 35.96%, Test: 38.42%, Best Valid: 36.18%, Best Test: 38.53%
Epoch: 40, Loss: 1.7394, Train: 44.66%, Valid: 43.89%, Test: 45.18%, Best Valid: 43.89%, Best Test: 45.18%
Epoch: 41, Loss: 1.7008, Train: 46.95%, Valid: 46.73%, Test: 47.15%, Best Valid: 46.73%, Best Test: 47.15%
Epoch: 42, Loss: 1.6438, Train: 43.51%, Valid: 42.87%, Test: 43.37%, Best Valid: 46.73%, Best Test: 47.15%
Epoch: 43, Loss: 1.6688, Train: 37.64%, Valid: 36.04%, Test: 38.68%, Best Valid: 46.73%, Best Test: 47.15%
Epoch: 44, Loss: 1.9209, Train: 62.08%, Valid: 60.44%, Test: 61.47%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 45, Loss: 1.5193, Train: 39.67%, Valid: 38.62%, Test: 38.75%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 46, Loss: 1.7754, Train: 57.61%, Valid: 55.82%, Test: 57.40%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 47, Loss: 1.4977, Train: 42.30%, Valid: 40.33%, Test: 42.97%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 48, Loss: 1.7033, Train: 55.52%, Valid: 53.96%, Test: 56.13%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 49, Loss: 1.4905, Train: 45.95%, Valid: 44.22%, Test: 46.31%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 50, Loss: 1.5310, Train: 42.98%, Valid: 41.56%, Test: 43.11%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 51, Loss: 1.5383, Train: 55.41%, Valid: 53.02%, Test: 55.58%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 52, Loss: 1.4096, Train: 54.54%, Valid: 52.76%, Test: 54.89%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 53, Loss: 1.4600, Train: 55.50%, Valid: 53.64%, Test: 56.09%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 54, Loss: 1.4032, Train: 56.79%, Valid: 54.91%, Test: 57.03%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 55, Loss: 1.3483, Train: 56.70%, Valid: 54.58%, Test: 55.87%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 56, Loss: 1.3589, Train: 56.08%, Valid: 54.62%, Test: 55.58%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 57, Loss: 1.3162, Train: 58.05%, Valid: 56.25%, Test: 57.87%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 58, Loss: 1.2458, Train: 58.62%, Valid: 57.05%, Test: 59.40%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 59, Loss: 1.2544, Train: 61.27%, Valid: 59.31%, Test: 60.89%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 60, Loss: 1.1782, Train: 59.41%, Valid: 57.31%, Test: 58.81%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 61, Loss: 1.1463, Train: 61.11%, Valid: 58.91%, Test: 60.45%, Best Valid: 60.44%, Best Test: 61.47%
Epoch: 62, Loss: 1.1087, Train: 63.54%, Valid: 61.24%, Test: 62.63%, Best Valid: 61.24%, Best Test: 62.63%
Epoch: 63, Loss: 1.0672, Train: 63.46%, Valid: 61.38%, Test: 62.60%, Best Valid: 61.38%, Best Test: 62.60%
Epoch: 64, Loss: 1.0298, Train: 64.95%, Valid: 63.53%, Test: 64.41%, Best Valid: 63.53%, Best Test: 64.41%
Epoch: 65, Loss: 0.9899, Train: 66.09%, Valid: 64.40%, Test: 66.34%, Best Valid: 64.40%, Best Test: 66.34%
Epoch: 66, Loss: 0.9496, Train: 69.37%, Valid: 67.42%, Test: 67.90%, Best Valid: 67.42%, Best Test: 67.90%
Epoch: 67, Loss: 0.9372, Train: 70.02%, Valid: 68.65%, Test: 70.48%, Best Valid: 68.65%, Best Test: 70.48%
Epoch: 68, Loss: 0.9003, Train: 71.97%, Valid: 70.44%, Test: 72.26%, Best Valid: 70.44%, Best Test: 72.26%
Epoch: 69, Loss: 0.8608, Train: 75.01%, Valid: 74.11%, Test: 75.10%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 70, Loss: 0.8621, Train: 65.98%, Valid: 64.65%, Test: 66.45%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 71, Loss: 0.8972, Train: 71.39%, Valid: 69.82%, Test: 71.57%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 72, Loss: 0.8169, Train: 74.14%, Valid: 72.95%, Test: 73.54%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 73, Loss: 0.9627, Train: 70.62%, Valid: 69.42%, Test: 71.03%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 74, Loss: 0.8401, Train: 65.37%, Valid: 64.00%, Test: 66.48%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 75, Loss: 0.9540, Train: 67.31%, Valid: 66.22%, Test: 66.67%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 76, Loss: 0.9894, Train: 69.16%, Valid: 67.16%, Test: 69.83%, Best Valid: 74.11%, Best Test: 75.10%
Epoch: 77, Loss: 0.8582, Train: 76.11%, Valid: 74.98%, Test: 76.55%, Best Valid: 74.98%, Best Test: 76.55%
Epoch: 78, Loss: 0.8309, Train: 73.18%, Valid: 73.05%, Test: 72.59%, Best Valid: 74.98%, Best Test: 76.55%
Epoch: 79, Loss: 0.8622, Train: 75.02%, Valid: 75.27%, Test: 76.01%, Best Valid: 75.27%, Best Test: 76.01%
Epoch: 80, Loss: 0.7451, Train: 72.56%, Valid: 71.31%, Test: 73.46%, Best Valid: 75.27%, Best Test: 76.01%
Epoch: 81, Loss: 0.7737, Train: 73.08%, Valid: 73.09%, Test: 74.77%, Best Valid: 75.27%, Best Test: 76.01%
Epoch: 82, Loss: 0.7148, Train: 72.09%, Valid: 71.45%, Test: 72.92%, Best Valid: 75.27%, Best Test: 76.01%
Epoch: 83, Loss: 0.7382, Train: 75.46%, Valid: 75.67%, Test: 75.83%, Best Valid: 75.67%, Best Test: 75.83%
Epoch: 84, Loss: 0.6662, Train: 74.94%, Valid: 74.80%, Test: 75.39%, Best Valid: 75.67%, Best Test: 75.83%
Epoch: 85, Loss: 0.7217, Train: 79.81%, Valid: 79.02%, Test: 79.79%, Best Valid: 79.02%, Best Test: 79.79%
Epoch: 86, Loss: 0.6775, Train: 78.22%, Valid: 78.00%, Test: 79.39%, Best Valid: 79.02%, Best Test: 79.79%
Epoch: 87, Loss: 0.6723, Train: 78.35%, Valid: 78.76%, Test: 79.35%, Best Valid: 79.02%, Best Test: 79.79%
Epoch: 88, Loss: 0.6634, Train: 78.33%, Valid: 78.22%, Test: 79.06%, Best Valid: 79.02%, Best Test: 79.79%
Epoch: 89, Loss: 0.6664, Train: 80.04%, Valid: 79.09%, Test: 81.24%, Best Valid: 79.09%, Best Test: 81.24%
Epoch: 90, Loss: 0.6068, Train: 79.53%, Valid: 78.47%, Test: 79.83%, Best Valid: 79.09%, Best Test: 81.24%
Epoch: 91, Loss: 0.6355, Train: 78.85%, Valid: 79.02%, Test: 79.46%, Best Valid: 79.09%, Best Test: 81.24%
Epoch: 92, Loss: 0.6129, Train: 76.98%, Valid: 76.33%, Test: 77.14%, Best Valid: 79.09%, Best Test: 81.24%
Epoch: 93, Loss: 0.6136, Train: 78.86%, Valid: 79.60%, Test: 80.33%, Best Valid: 79.60%, Best Test: 80.33%
Epoch: 94, Loss: 0.5985, Train: 81.59%, Valid: 81.75%, Test: 82.77%, Best Valid: 81.75%, Best Test: 82.77%
Epoch: 95, Loss: 0.6169, Train: 81.46%, Valid: 80.84%, Test: 82.19%, Best Valid: 81.75%, Best Test: 82.77%
Epoch: 96, Loss: 0.5761, Train: 80.38%, Valid: 80.44%, Test: 81.17%, Best Valid: 81.75%, Best Test: 82.77%
Epoch: 97, Loss: 0.5847, Train: 81.25%, Valid: 81.20%, Test: 81.93%, Best Valid: 81.75%, Best Test: 82.77%
Epoch: 98, Loss: 0.5687, Train: 81.74%, Valid: 81.02%, Test: 82.30%, Best Valid: 81.75%, Best Test: 82.77%
Epoch: 99, Loss: 0.5605, Train: 82.90%, Valid: 82.73%, Test: 82.95%, Best Valid: 82.73%, Best Test: 82.95%
Epoch: 100, Loss: 0.5461, Train: 82.50%, Valid: 81.93%, Test: 82.55%, Best Valid: 82.73%, Best Test: 82.95%
Epoch: 101, Loss: 0.5538, Train: 83.11%, Valid: 82.95%, Test: 83.50%, Best Valid: 82.95%, Best Test: 83.50%
Epoch: 102, Loss: 0.5333, Train: 83.65%, Valid: 83.49%, Test: 83.82%, Best Valid: 83.49%, Best Test: 83.82%
Epoch: 103, Loss: 0.5255, Train: 82.57%, Valid: 82.44%, Test: 82.84%, Best Valid: 83.49%, Best Test: 83.82%
Epoch: 104, Loss: 0.5323, Train: 82.18%, Valid: 83.02%, Test: 83.13%, Best Valid: 83.49%, Best Test: 83.82%
Epoch: 105, Loss: 0.5260, Train: 83.59%, Valid: 84.15%, Test: 84.44%, Best Valid: 84.15%, Best Test: 84.44%
Epoch: 106, Loss: 0.5137, Train: 83.81%, Valid: 84.25%, Test: 84.70%, Best Valid: 84.25%, Best Test: 84.70%
Epoch: 107, Loss: 0.5136, Train: 83.41%, Valid: 83.53%, Test: 84.08%, Best Valid: 84.25%, Best Test: 84.70%
Epoch: 108, Loss: 0.5059, Train: 82.92%, Valid: 83.75%, Test: 83.68%, Best Valid: 84.25%, Best Test: 84.70%
Epoch: 109, Loss: 0.5112, Train: 83.67%, Valid: 84.15%, Test: 84.04%, Best Valid: 84.25%, Best Test: 84.70%
Epoch: 110, Loss: 0.5030, Train: 84.70%, Valid: 84.80%, Test: 85.64%, Best Valid: 84.80%, Best Test: 85.64%
Epoch: 111, Loss: 0.4851, Train: 85.04%, Valid: 85.56%, Test: 85.93%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 112, Loss: 0.4868, Train: 82.78%, Valid: 83.09%, Test: 83.46%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 113, Loss: 0.4920, Train: 82.52%, Valid: 82.98%, Test: 83.28%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 114, Loss: 0.4839, Train: 83.02%, Valid: 83.78%, Test: 83.79%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 115, Loss: 0.4712, Train: 84.40%, Valid: 85.31%, Test: 85.28%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 116, Loss: 0.4673, Train: 84.56%, Valid: 85.16%, Test: 85.57%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 117, Loss: 0.4702, Train: 84.55%, Valid: 85.02%, Test: 85.50%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 118, Loss: 0.4656, Train: 84.00%, Valid: 84.69%, Test: 84.73%, Best Valid: 85.56%, Best Test: 85.93%
Epoch: 119, Loss: 0.4707, Train: 85.26%, Valid: 85.64%, Test: 85.64%, Best Valid: 85.64%, Best Test: 85.64%
Epoch: 120, Loss: 0.4543, Train: 85.42%, Valid: 85.78%, Test: 86.11%, Best Valid: 85.78%, Best Test: 86.11%
Epoch: 121, Loss: 0.4532, Train: 84.94%, Valid: 85.96%, Test: 85.90%, Best Valid: 85.96%, Best Test: 85.90%
Epoch: 122, Loss: 0.4481, Train: 84.32%, Valid: 84.98%, Test: 85.10%, Best Valid: 85.96%, Best Test: 85.90%
Epoch: 123, Loss: 0.4391, Train: 83.52%, Valid: 83.20%, Test: 84.37%, Best Valid: 85.96%, Best Test: 85.90%
Epoch: 124, Loss: 0.4417, Train: 85.84%, Valid: 85.75%, Test: 86.62%, Best Valid: 85.96%, Best Test: 85.90%
Epoch: 125, Loss: 0.4438, Train: 87.48%, Valid: 87.27%, Test: 88.19%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 126, Loss: 0.4319, Train: 87.09%, Valid: 86.58%, Test: 87.53%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 127, Loss: 0.4239, Train: 85.35%, Valid: 85.16%, Test: 85.21%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 128, Loss: 0.4320, Train: 82.11%, Valid: 82.69%, Test: 83.13%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 129, Loss: 0.4381, Train: 84.75%, Valid: 85.16%, Test: 86.26%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 130, Loss: 0.4501, Train: 87.36%, Valid: 86.91%, Test: 87.90%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 131, Loss: 0.4172, Train: 85.58%, Valid: 86.04%, Test: 86.30%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 132, Loss: 0.4138, Train: 84.69%, Valid: 85.20%, Test: 85.46%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 133, Loss: 0.4007, Train: 85.76%, Valid: 86.18%, Test: 86.70%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 134, Loss: 0.4109, Train: 87.07%, Valid: 86.87%, Test: 87.90%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 135, Loss: 0.4134, Train: 87.26%, Valid: 86.80%, Test: 87.90%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 136, Loss: 0.4015, Train: 86.26%, Valid: 86.80%, Test: 87.13%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 137, Loss: 0.3965, Train: 85.07%, Valid: 85.78%, Test: 85.71%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 138, Loss: 0.4108, Train: 86.55%, Valid: 86.80%, Test: 87.17%, Best Valid: 87.27%, Best Test: 88.19%
Epoch: 139, Loss: 0.3988, Train: 87.84%, Valid: 87.31%, Test: 88.48%, Best Valid: 87.31%, Best Test: 88.48%
Epoch: 140, Loss: 0.3896, Train: 88.11%, Valid: 87.42%, Test: 88.88%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 141, Loss: 0.4006, Train: 86.73%, Valid: 86.80%, Test: 87.50%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 142, Loss: 0.3893, Train: 86.10%, Valid: 86.69%, Test: 86.44%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 143, Loss: 0.3835, Train: 85.97%, Valid: 86.25%, Test: 86.59%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 144, Loss: 0.4041, Train: 87.47%, Valid: 87.13%, Test: 88.19%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 145, Loss: 0.3746, Train: 86.85%, Valid: 86.07%, Test: 87.79%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 146, Loss: 0.3965, Train: 87.49%, Valid: 87.02%, Test: 88.30%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 147, Loss: 0.3764, Train: 86.43%, Valid: 86.69%, Test: 87.42%, Best Valid: 87.42%, Best Test: 88.88%
Epoch: 148, Loss: 0.3861, Train: 87.58%, Valid: 87.75%, Test: 88.04%, Best Valid: 87.75%, Best Test: 88.04%
Epoch: 149, Loss: 0.3728, Train: 87.82%, Valid: 87.75%, Test: 88.73%, Best Valid: 87.75%, Best Test: 88.04%
Epoch: 150, Loss: 0.3780, Train: 87.66%, Valid: 87.60%, Test: 88.19%, Best Valid: 87.75%, Best Test: 88.04%
Epoch: 151, Loss: 0.3693, Train: 85.82%, Valid: 85.93%, Test: 86.55%, Best Valid: 87.75%, Best Test: 88.04%
Epoch: 152, Loss: 0.3784, Train: 86.98%, Valid: 87.24%, Test: 88.22%, Best Valid: 87.75%, Best Test: 88.04%
Epoch: 153, Loss: 0.3699, Train: 87.26%, Valid: 87.35%, Test: 88.48%, Best Valid: 87.75%, Best Test: 88.04%
Epoch: 154, Loss: 0.4057, Train: 88.50%, Valid: 88.18%, Test: 89.75%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 155, Loss: 0.3724, Train: 86.07%, Valid: 85.85%, Test: 87.10%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 156, Loss: 0.3983, Train: 83.74%, Valid: 84.29%, Test: 84.48%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 157, Loss: 0.4309, Train: 87.94%, Valid: 87.85%, Test: 88.51%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 158, Loss: 0.3577, Train: 87.44%, Valid: 87.24%, Test: 88.30%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 159, Loss: 0.4026, Train: 87.73%, Valid: 87.60%, Test: 88.37%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 160, Loss: 0.3748, Train: 84.73%, Valid: 85.02%, Test: 85.53%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 161, Loss: 0.4280, Train: 87.29%, Valid: 86.91%, Test: 87.93%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 162, Loss: 0.3594, Train: 87.38%, Valid: 87.35%, Test: 87.68%, Best Valid: 88.18%, Best Test: 89.75%
Epoch: 163, Loss: 0.3706, Train: 88.04%, Valid: 88.22%, Test: 89.02%, Best Valid: 88.22%, Best Test: 89.02%
Epoch: 164, Loss: 0.3674, Train: 87.61%, Valid: 87.24%, Test: 88.59%, Best Valid: 88.22%, Best Test: 89.02%
Epoch: 165, Loss: 0.3564, Train: 86.81%, Valid: 86.76%, Test: 87.39%, Best Valid: 88.22%, Best Test: 89.02%
Epoch: 166, Loss: 0.3660, Train: 87.89%, Valid: 87.64%, Test: 88.70%, Best Valid: 88.22%, Best Test: 89.02%
Epoch: 167, Loss: 0.3686, Train: 88.98%, Valid: 88.47%, Test: 89.46%, Best Valid: 88.47%, Best Test: 89.46%
Epoch: 168, Loss: 0.3595, Train: 88.97%, Valid: 88.69%, Test: 89.24%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 169, Loss: 0.3541, Train: 87.49%, Valid: 87.45%, Test: 88.37%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 170, Loss: 0.3607, Train: 87.40%, Valid: 87.24%, Test: 88.37%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 171, Loss: 0.3386, Train: 87.59%, Valid: 87.67%, Test: 88.40%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 172, Loss: 0.3494, Train: 88.09%, Valid: 87.93%, Test: 88.95%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 173, Loss: 0.3466, Train: 88.57%, Valid: 88.40%, Test: 89.17%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 174, Loss: 0.3302, Train: 88.66%, Valid: 88.36%, Test: 89.57%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 175, Loss: 0.3436, Train: 89.18%, Valid: 88.47%, Test: 89.42%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 176, Loss: 0.3429, Train: 88.83%, Valid: 88.22%, Test: 89.42%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 177, Loss: 0.3359, Train: 87.97%, Valid: 87.67%, Test: 88.77%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 178, Loss: 0.3316, Train: 87.57%, Valid: 87.27%, Test: 88.66%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 179, Loss: 0.3310, Train: 88.37%, Valid: 88.07%, Test: 89.75%, Best Valid: 88.69%, Best Test: 89.24%
Epoch: 180, Loss: 0.3320, Train: 89.71%, Valid: 88.95%, Test: 90.22%, Best Valid: 88.95%, Best Test: 90.22%
Epoch: 181, Loss: 0.3383, Train: 89.72%, Valid: 88.62%, Test: 89.79%, Best Valid: 88.95%, Best Test: 90.22%
Epoch: 182, Loss: 0.3376, Train: 88.26%, Valid: 87.53%, Test: 88.88%, Best Valid: 88.95%, Best Test: 90.22%
Epoch: 183, Loss: 0.3273, Train: 87.78%, Valid: 87.64%, Test: 88.88%, Best Valid: 88.95%, Best Test: 90.22%
Epoch: 184, Loss: 0.3300, Train: 88.60%, Valid: 88.25%, Test: 89.89%, Best Valid: 88.95%, Best Test: 90.22%
Epoch: 185, Loss: 0.3401, Train: 89.80%, Valid: 89.13%, Test: 90.73%, Best Valid: 89.13%, Best Test: 90.73%
Epoch: 186, Loss: 0.3265, Train: 88.35%, Valid: 88.22%, Test: 88.70%, Best Valid: 89.13%, Best Test: 90.73%
Epoch: 187, Loss: 0.3364, Train: 87.90%, Valid: 87.53%, Test: 88.62%, Best Valid: 89.13%, Best Test: 90.73%
Epoch: 188, Loss: 0.3293, Train: 88.92%, Valid: 88.47%, Test: 89.93%, Best Valid: 89.13%, Best Test: 90.73%
Epoch: 189, Loss: 0.3221, Train: 89.92%, Valid: 89.05%, Test: 90.73%, Best Valid: 89.13%, Best Test: 90.73%
Epoch: 190, Loss: 0.3206, Train: 89.75%, Valid: 89.27%, Test: 90.73%, Best Valid: 89.27%, Best Test: 90.73%
Epoch: 191, Loss: 0.3227, Train: 88.80%, Valid: 88.00%, Test: 89.39%, Best Valid: 89.27%, Best Test: 90.73%
Epoch: 192, Loss: 0.3246, Train: 87.64%, Valid: 87.16%, Test: 88.15%, Best Valid: 89.27%, Best Test: 90.73%
Epoch: 193, Loss: 0.3337, Train: 89.12%, Valid: 88.62%, Test: 90.19%, Best Valid: 89.27%, Best Test: 90.73%
Epoch: 194, Loss: 0.3173, Train: 90.26%, Valid: 89.56%, Test: 90.84%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 195, Loss: 0.3216, Train: 89.94%, Valid: 89.09%, Test: 90.88%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 196, Loss: 0.3157, Train: 89.04%, Valid: 88.51%, Test: 89.89%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 197, Loss: 0.3121, Train: 88.73%, Valid: 88.15%, Test: 89.13%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 198, Loss: 0.3118, Train: 89.23%, Valid: 88.29%, Test: 89.60%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 199, Loss: 0.3104, Train: 89.80%, Valid: 88.95%, Test: 90.29%, Best Valid: 89.56%, Best Test: 90.84%
start global attention!!!!!!
Epoch: 200, Loss: 2.3539, Train: 41.33%, Valid: 39.45%, Test: 42.02%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 201, Loss: 1.6586, Train: 67.86%, Valid: 65.75%, Test: 68.19%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 202, Loss: 1.3523, Train: 75.37%, Valid: 73.60%, Test: 75.79%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 203, Loss: 1.0662, Train: 83.46%, Valid: 81.13%, Test: 83.93%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 204, Loss: 0.8378, Train: 85.32%, Valid: 83.56%, Test: 85.42%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 205, Loss: 0.7116, Train: 84.83%, Valid: 82.98%, Test: 84.59%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 206, Loss: 0.6341, Train: 84.45%, Valid: 83.13%, Test: 84.30%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 207, Loss: 0.5734, Train: 85.52%, Valid: 84.80%, Test: 85.24%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 208, Loss: 0.5235, Train: 85.82%, Valid: 84.69%, Test: 85.57%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 209, Loss: 0.5213, Train: 88.29%, Valid: 87.16%, Test: 88.84%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 210, Loss: 0.4799, Train: 89.53%, Valid: 89.16%, Test: 90.11%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 211, Loss: 0.4481, Train: 89.84%, Valid: 89.42%, Test: 90.44%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 212, Loss: 0.4398, Train: 90.10%, Valid: 89.45%, Test: 90.69%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 213, Loss: 0.4149, Train: 89.94%, Valid: 89.27%, Test: 90.69%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 214, Loss: 0.4085, Train: 90.01%, Valid: 89.38%, Test: 91.02%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 215, Loss: 0.4096, Train: 89.20%, Valid: 88.40%, Test: 90.22%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 216, Loss: 0.4092, Train: 89.58%, Valid: 88.76%, Test: 90.08%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 217, Loss: 0.3919, Train: 89.70%, Valid: 88.62%, Test: 90.55%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 218, Loss: 0.4050, Train: 90.43%, Valid: 89.56%, Test: 90.91%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 219, Loss: 0.3818, Train: 88.10%, Valid: 88.07%, Test: 89.09%, Best Valid: 89.56%, Best Test: 90.84%
Epoch: 220, Loss: 0.3926, Train: 90.21%, Valid: 89.75%, Test: 91.09%, Best Valid: 89.75%, Best Test: 91.09%
Epoch: 221, Loss: 0.3732, Train: 89.56%, Valid: 88.36%, Test: 90.15%, Best Valid: 89.75%, Best Test: 91.09%
Epoch: 222, Loss: 0.3826, Train: 88.09%, Valid: 87.49%, Test: 88.40%, Best Valid: 89.75%, Best Test: 91.09%
Epoch: 223, Loss: 0.3764, Train: 89.42%, Valid: 89.02%, Test: 89.75%, Best Valid: 89.75%, Best Test: 91.09%
Epoch: 224, Loss: 0.3706, Train: 90.35%, Valid: 89.38%, Test: 90.84%, Best Valid: 89.75%, Best Test: 91.09%
Epoch: 225, Loss: 0.3642, Train: 90.69%, Valid: 89.75%, Test: 91.49%, Best Valid: 89.75%, Best Test: 91.09%
Epoch: 226, Loss: 0.3479, Train: 90.50%, Valid: 89.78%, Test: 90.73%, Best Valid: 89.78%, Best Test: 90.73%
Epoch: 227, Loss: 0.3501, Train: 90.74%, Valid: 89.85%, Test: 91.09%, Best Valid: 89.85%, Best Test: 91.09%
Epoch: 228, Loss: 0.3365, Train: 90.38%, Valid: 89.31%, Test: 90.66%, Best Valid: 89.85%, Best Test: 91.09%
Epoch: 229, Loss: 0.3465, Train: 90.64%, Valid: 90.04%, Test: 91.09%, Best Valid: 90.04%, Best Test: 91.09%
Epoch: 230, Loss: 0.3415, Train: 90.73%, Valid: 89.60%, Test: 91.35%, Best Valid: 90.04%, Best Test: 91.09%
Epoch: 231, Loss: 0.3439, Train: 90.86%, Valid: 89.71%, Test: 91.20%, Best Valid: 90.04%, Best Test: 91.09%
Epoch: 232, Loss: 0.3327, Train: 90.60%, Valid: 89.24%, Test: 90.80%, Best Valid: 90.04%, Best Test: 91.09%
Epoch: 233, Loss: 0.3383, Train: 90.60%, Valid: 89.24%, Test: 90.66%, Best Valid: 90.04%, Best Test: 91.09%
Epoch: 234, Loss: 0.3389, Train: 91.09%, Valid: 90.11%, Test: 91.42%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 235, Loss: 0.3316, Train: 90.70%, Valid: 89.85%, Test: 91.06%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 236, Loss: 0.3240, Train: 90.15%, Valid: 89.05%, Test: 90.19%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 237, Loss: 0.3246, Train: 91.04%, Valid: 90.11%, Test: 91.24%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 238, Loss: 0.3150, Train: 90.78%, Valid: 89.67%, Test: 91.02%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 239, Loss: 0.3148, Train: 90.76%, Valid: 89.49%, Test: 91.09%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 240, Loss: 0.3219, Train: 90.41%, Valid: 89.35%, Test: 90.77%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 241, Loss: 0.3227, Train: 91.00%, Valid: 89.78%, Test: 90.88%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 242, Loss: 0.3192, Train: 90.87%, Valid: 89.49%, Test: 91.09%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 243, Loss: 0.3125, Train: 89.92%, Valid: 88.65%, Test: 89.86%, Best Valid: 90.11%, Best Test: 91.42%
Epoch: 244, Loss: 0.3256, Train: 91.56%, Valid: 90.40%, Test: 91.75%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 245, Loss: 0.3119, Train: 91.39%, Valid: 89.78%, Test: 91.35%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 246, Loss: 0.3267, Train: 89.49%, Valid: 88.29%, Test: 89.39%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 247, Loss: 0.3151, Train: 89.25%, Valid: 87.93%, Test: 89.09%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 248, Loss: 0.3182, Train: 91.26%, Valid: 90.15%, Test: 91.20%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 249, Loss: 0.3064, Train: 91.04%, Valid: 89.24%, Test: 91.24%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 250, Loss: 0.3218, Train: 90.34%, Valid: 89.27%, Test: 90.66%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 251, Loss: 0.3046, Train: 88.69%, Valid: 87.75%, Test: 89.02%, Best Valid: 90.40%, Best Test: 91.75%
Epoch: 252, Loss: 0.3266, Train: 91.71%, Valid: 90.84%, Test: 91.75%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 253, Loss: 0.3031, Train: 90.85%, Valid: 89.09%, Test: 90.99%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 254, Loss: 0.3179, Train: 91.18%, Valid: 90.25%, Test: 91.09%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 255, Loss: 0.3126, Train: 89.20%, Valid: 88.47%, Test: 89.17%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 256, Loss: 0.3254, Train: 90.35%, Valid: 89.05%, Test: 90.88%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 257, Loss: 0.3215, Train: 91.53%, Valid: 90.22%, Test: 91.82%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 258, Loss: 0.3092, Train: 91.30%, Valid: 89.71%, Test: 90.80%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 259, Loss: 0.3196, Train: 90.57%, Valid: 89.64%, Test: 90.37%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 260, Loss: 0.3026, Train: 89.75%, Valid: 88.84%, Test: 89.79%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 261, Loss: 0.3084, Train: 90.68%, Valid: 89.38%, Test: 90.77%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 262, Loss: 0.3337, Train: 91.44%, Valid: 90.29%, Test: 91.60%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 263, Loss: 0.2996, Train: 90.38%, Valid: 89.42%, Test: 90.26%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 264, Loss: 0.3249, Train: 91.83%, Valid: 90.80%, Test: 91.42%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 265, Loss: 0.3045, Train: 91.12%, Valid: 90.00%, Test: 91.38%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 266, Loss: 0.2994, Train: 89.94%, Valid: 88.76%, Test: 90.59%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 267, Loss: 0.3091, Train: 90.22%, Valid: 88.95%, Test: 90.33%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 268, Loss: 0.2982, Train: 90.92%, Valid: 90.22%, Test: 91.09%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 269, Loss: 0.3052, Train: 91.66%, Valid: 90.36%, Test: 91.35%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 270, Loss: 0.3081, Train: 91.10%, Valid: 89.75%, Test: 91.02%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 271, Loss: 0.2975, Train: 90.33%, Valid: 88.84%, Test: 90.44%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 272, Loss: 0.2976, Train: 91.16%, Valid: 89.78%, Test: 91.53%, Best Valid: 90.84%, Best Test: 91.75%
Epoch: 273, Loss: 0.2950, Train: 92.29%, Valid: 91.27%, Test: 92.26%, Best Valid: 91.27%, Best Test: 92.26%
Epoch: 274, Loss: 0.2880, Train: 91.37%, Valid: 90.22%, Test: 91.46%, Best Valid: 91.27%, Best Test: 92.26%
Epoch: 275, Loss: 0.2879, Train: 91.09%, Valid: 90.15%, Test: 91.02%, Best Valid: 91.27%, Best Test: 92.26%
Epoch: 276, Loss: 0.3035, Train: 91.96%, Valid: 91.35%, Test: 91.82%, Best Valid: 91.35%, Best Test: 91.82%
Epoch: 277, Loss: 0.2866, Train: 91.64%, Valid: 90.15%, Test: 91.86%, Best Valid: 91.35%, Best Test: 91.82%
Epoch: 278, Loss: 0.2916, Train: 90.98%, Valid: 89.67%, Test: 91.24%, Best Valid: 91.35%, Best Test: 91.82%
Epoch: 279, Loss: 0.2841, Train: 91.60%, Valid: 90.29%, Test: 91.42%, Best Valid: 91.35%, Best Test: 91.82%
Epoch: 280, Loss: 0.2771, Train: 91.75%, Valid: 90.73%, Test: 91.49%, Best Valid: 91.35%, Best Test: 91.82%
Epoch: 281, Loss: 0.2838, Train: 92.22%, Valid: 91.45%, Test: 92.18%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 282, Loss: 0.2832, Train: 91.92%, Valid: 90.98%, Test: 92.11%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 283, Loss: 0.2810, Train: 91.33%, Valid: 89.67%, Test: 91.42%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 284, Loss: 0.2882, Train: 90.38%, Valid: 89.42%, Test: 90.84%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 285, Loss: 0.2821, Train: 92.10%, Valid: 90.91%, Test: 91.97%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 286, Loss: 0.2686, Train: 92.33%, Valid: 91.45%, Test: 92.33%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 287, Loss: 0.2817, Train: 91.48%, Valid: 90.18%, Test: 91.46%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 288, Loss: 0.2960, Train: 91.55%, Valid: 90.15%, Test: 91.42%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 289, Loss: 0.2804, Train: 91.83%, Valid: 90.69%, Test: 91.71%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 290, Loss: 0.2888, Train: 92.06%, Valid: 90.55%, Test: 92.26%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 291, Loss: 0.2799, Train: 91.84%, Valid: 90.51%, Test: 91.82%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 292, Loss: 0.2799, Train: 92.38%, Valid: 91.38%, Test: 92.08%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 293, Loss: 0.2778, Train: 92.27%, Valid: 91.31%, Test: 91.97%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 294, Loss: 0.2786, Train: 91.49%, Valid: 90.04%, Test: 91.42%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 295, Loss: 0.2686, Train: 91.87%, Valid: 90.00%, Test: 91.93%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 296, Loss: 0.2699, Train: 92.78%, Valid: 91.42%, Test: 92.33%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 297, Loss: 0.2788, Train: 92.28%, Valid: 90.91%, Test: 91.89%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 298, Loss: 0.2710, Train: 91.77%, Valid: 90.47%, Test: 91.75%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 299, Loss: 0.2697, Train: 92.24%, Valid: 91.02%, Test: 91.68%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 300, Loss: 0.2782, Train: 92.00%, Valid: 90.62%, Test: 91.60%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 301, Loss: 0.2655, Train: 91.96%, Valid: 90.51%, Test: 91.86%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 302, Loss: 0.2753, Train: 92.58%, Valid: 91.24%, Test: 92.37%, Best Valid: 91.45%, Best Test: 92.18%
Epoch: 303, Loss: 0.2717, Train: 92.90%, Valid: 91.78%, Test: 92.48%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 304, Loss: 0.2696, Train: 92.15%, Valid: 90.98%, Test: 91.89%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 305, Loss: 0.2612, Train: 91.76%, Valid: 90.62%, Test: 91.82%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 306, Loss: 0.2683, Train: 92.74%, Valid: 91.53%, Test: 92.11%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 307, Loss: 0.2639, Train: 92.58%, Valid: 90.95%, Test: 92.04%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 308, Loss: 0.2727, Train: 90.95%, Valid: 89.71%, Test: 90.95%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 309, Loss: 0.2701, Train: 92.10%, Valid: 91.13%, Test: 91.86%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 310, Loss: 0.2688, Train: 92.67%, Valid: 91.53%, Test: 92.22%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 311, Loss: 0.2658, Train: 92.85%, Valid: 91.60%, Test: 92.22%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 312, Loss: 0.2528, Train: 92.34%, Valid: 90.65%, Test: 91.93%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 313, Loss: 0.2687, Train: 92.12%, Valid: 90.95%, Test: 92.11%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 314, Loss: 0.2622, Train: 92.01%, Valid: 90.87%, Test: 91.71%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 315, Loss: 0.2645, Train: 92.43%, Valid: 91.16%, Test: 92.37%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 316, Loss: 0.2621, Train: 92.78%, Valid: 91.27%, Test: 92.80%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 317, Loss: 0.2670, Train: 92.44%, Valid: 90.95%, Test: 92.55%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 318, Loss: 0.2569, Train: 91.59%, Valid: 90.11%, Test: 91.49%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 319, Loss: 0.2668, Train: 92.28%, Valid: 91.05%, Test: 91.97%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 320, Loss: 0.2608, Train: 92.23%, Valid: 90.95%, Test: 91.97%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 321, Loss: 0.2704, Train: 92.56%, Valid: 91.09%, Test: 91.93%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 322, Loss: 0.2639, Train: 91.92%, Valid: 90.04%, Test: 91.20%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 323, Loss: 0.2626, Train: 92.93%, Valid: 91.35%, Test: 92.84%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 324, Loss: 0.2670, Train: 92.89%, Valid: 91.67%, Test: 92.48%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 325, Loss: 0.2547, Train: 92.27%, Valid: 90.84%, Test: 92.08%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 326, Loss: 0.2620, Train: 92.39%, Valid: 91.20%, Test: 91.71%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 327, Loss: 0.2555, Train: 92.53%, Valid: 90.76%, Test: 91.75%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 328, Loss: 0.2678, Train: 90.98%, Valid: 89.53%, Test: 90.37%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 329, Loss: 0.2666, Train: 92.53%, Valid: 90.76%, Test: 92.33%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 330, Loss: 0.2552, Train: 93.18%, Valid: 91.42%, Test: 92.48%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 331, Loss: 0.2586, Train: 92.96%, Valid: 91.49%, Test: 92.44%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 332, Loss: 0.2614, Train: 91.93%, Valid: 90.29%, Test: 91.57%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 333, Loss: 0.2488, Train: 91.87%, Valid: 90.25%, Test: 91.68%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 334, Loss: 0.2485, Train: 92.58%, Valid: 90.73%, Test: 92.15%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 335, Loss: 0.2591, Train: 92.11%, Valid: 90.58%, Test: 91.68%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 336, Loss: 0.2616, Train: 92.55%, Valid: 91.02%, Test: 91.97%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 337, Loss: 0.2544, Train: 93.02%, Valid: 91.20%, Test: 92.40%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 338, Loss: 0.2465, Train: 92.52%, Valid: 90.73%, Test: 92.29%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 339, Loss: 0.2497, Train: 92.29%, Valid: 90.69%, Test: 92.18%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 340, Loss: 0.2530, Train: 92.19%, Valid: 90.55%, Test: 92.04%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 341, Loss: 0.2488, Train: 93.07%, Valid: 91.49%, Test: 92.48%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 342, Loss: 0.2522, Train: 92.40%, Valid: 90.91%, Test: 91.89%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 343, Loss: 0.2592, Train: 93.08%, Valid: 91.27%, Test: 92.66%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 344, Loss: 0.2472, Train: 92.97%, Valid: 90.91%, Test: 92.58%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 345, Loss: 0.2549, Train: 90.73%, Valid: 89.24%, Test: 90.33%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 346, Loss: 0.2580, Train: 92.96%, Valid: 91.20%, Test: 92.33%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 347, Loss: 0.2394, Train: 93.31%, Valid: 91.27%, Test: 92.29%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 348, Loss: 0.2701, Train: 92.56%, Valid: 91.27%, Test: 91.93%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 349, Loss: 0.2593, Train: 91.98%, Valid: 90.73%, Test: 91.09%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 350, Loss: 0.2565, Train: 92.90%, Valid: 91.16%, Test: 92.08%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 351, Loss: 0.2462, Train: 93.36%, Valid: 91.31%, Test: 92.51%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 352, Loss: 0.2535, Train: 92.49%, Valid: 91.09%, Test: 92.00%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 353, Loss: 0.2491, Train: 91.95%, Valid: 90.69%, Test: 91.09%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 354, Loss: 0.2558, Train: 93.32%, Valid: 91.75%, Test: 92.40%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 355, Loss: 0.2442, Train: 93.29%, Valid: 90.76%, Test: 92.48%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 356, Loss: 0.2660, Train: 91.60%, Valid: 90.15%, Test: 91.17%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 357, Loss: 0.2427, Train: 90.85%, Valid: 89.67%, Test: 90.40%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 358, Loss: 0.2535, Train: 93.50%, Valid: 91.64%, Test: 92.51%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 359, Loss: 0.2426, Train: 93.37%, Valid: 91.38%, Test: 92.66%, Best Valid: 91.78%, Best Test: 92.48%
Epoch: 360, Loss: 0.2586, Train: 93.52%, Valid: 91.82%, Test: 92.73%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 361, Loss: 0.2462, Train: 92.70%, Valid: 91.02%, Test: 92.15%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 362, Loss: 0.2454, Train: 92.57%, Valid: 90.73%, Test: 91.82%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 363, Loss: 0.2499, Train: 93.36%, Valid: 91.35%, Test: 92.48%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 364, Loss: 0.2381, Train: 92.93%, Valid: 91.38%, Test: 92.18%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 365, Loss: 0.2475, Train: 92.79%, Valid: 91.24%, Test: 92.11%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 366, Loss: 0.2456, Train: 93.13%, Valid: 91.13%, Test: 92.58%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 367, Loss: 0.2478, Train: 93.39%, Valid: 91.16%, Test: 92.95%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 368, Loss: 0.2432, Train: 93.33%, Valid: 91.45%, Test: 92.69%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 369, Loss: 0.2352, Train: 92.89%, Valid: 91.09%, Test: 92.18%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 370, Loss: 0.2416, Train: 92.91%, Valid: 91.20%, Test: 92.00%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 371, Loss: 0.2405, Train: 93.39%, Valid: 91.27%, Test: 92.58%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 372, Loss: 0.2468, Train: 93.42%, Valid: 91.27%, Test: 92.84%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 373, Loss: 0.2325, Train: 93.54%, Valid: 91.02%, Test: 92.69%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 374, Loss: 0.2388, Train: 93.35%, Valid: 91.09%, Test: 92.69%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 375, Loss: 0.2324, Train: 93.02%, Valid: 90.73%, Test: 92.11%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 376, Loss: 0.2439, Train: 93.54%, Valid: 91.67%, Test: 92.44%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 377, Loss: 0.2355, Train: 93.67%, Valid: 91.60%, Test: 92.84%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 378, Loss: 0.2444, Train: 93.03%, Valid: 90.80%, Test: 92.22%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 379, Loss: 0.2319, Train: 92.86%, Valid: 91.05%, Test: 92.26%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 380, Loss: 0.2311, Train: 93.55%, Valid: 91.78%, Test: 92.95%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 381, Loss: 0.2348, Train: 93.50%, Valid: 91.67%, Test: 92.69%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 382, Loss: 0.2352, Train: 93.64%, Valid: 91.49%, Test: 93.06%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 383, Loss: 0.2334, Train: 93.86%, Valid: 91.67%, Test: 93.17%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 384, Loss: 0.2324, Train: 93.71%, Valid: 91.20%, Test: 92.84%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 385, Loss: 0.2342, Train: 92.76%, Valid: 90.76%, Test: 92.04%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 386, Loss: 0.2338, Train: 93.21%, Valid: 91.05%, Test: 92.48%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 387, Loss: 0.2296, Train: 93.94%, Valid: 91.82%, Test: 93.06%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 388, Loss: 0.2328, Train: 93.89%, Valid: 91.60%, Test: 93.38%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 389, Loss: 0.2325, Train: 93.70%, Valid: 91.49%, Test: 93.17%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 390, Loss: 0.2284, Train: 93.33%, Valid: 91.27%, Test: 92.69%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 391, Loss: 0.2269, Train: 93.06%, Valid: 91.09%, Test: 92.33%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 392, Loss: 0.2415, Train: 93.81%, Valid: 91.20%, Test: 92.73%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 393, Loss: 0.2288, Train: 93.65%, Valid: 91.42%, Test: 92.98%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 394, Loss: 0.2359, Train: 92.39%, Valid: 90.76%, Test: 91.57%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 395, Loss: 0.2387, Train: 93.37%, Valid: 91.35%, Test: 92.73%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 396, Loss: 0.2249, Train: 93.59%, Valid: 91.45%, Test: 92.88%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 397, Loss: 0.2429, Train: 93.75%, Valid: 91.49%, Test: 92.95%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 398, Loss: 0.2261, Train: 92.35%, Valid: 90.29%, Test: 91.06%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 399, Loss: 0.2485, Train: 92.98%, Valid: 90.95%, Test: 91.89%, Best Valid: 91.82%, Best Test: 92.73%
Epoch: 400, Loss: 0.2349, Train: 94.11%, Valid: 92.25%, Test: 92.95%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 401, Loss: 0.2264, Train: 94.10%, Valid: 92.04%, Test: 93.35%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 402, Loss: 0.2303, Train: 94.10%, Valid: 91.60%, Test: 93.49%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 403, Loss: 0.2355, Train: 92.99%, Valid: 90.73%, Test: 92.29%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 404, Loss: 0.2348, Train: 92.87%, Valid: 90.91%, Test: 92.15%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 405, Loss: 0.2325, Train: 93.73%, Valid: 91.71%, Test: 92.77%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 406, Loss: 0.2302, Train: 94.23%, Valid: 91.53%, Test: 93.42%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 407, Loss: 0.2250, Train: 93.94%, Valid: 91.35%, Test: 92.98%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 408, Loss: 0.2349, Train: 93.42%, Valid: 90.84%, Test: 92.58%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 409, Loss: 0.2323, Train: 93.53%, Valid: 91.31%, Test: 92.66%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 410, Loss: 0.2226, Train: 93.83%, Valid: 91.38%, Test: 92.84%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 411, Loss: 0.2270, Train: 93.90%, Valid: 91.56%, Test: 93.06%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 412, Loss: 0.2227, Train: 93.81%, Valid: 91.35%, Test: 92.95%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 413, Loss: 0.2247, Train: 93.77%, Valid: 91.53%, Test: 92.84%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 414, Loss: 0.2148, Train: 93.61%, Valid: 91.53%, Test: 92.80%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 415, Loss: 0.2235, Train: 93.84%, Valid: 91.31%, Test: 92.98%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 416, Loss: 0.2277, Train: 94.17%, Valid: 91.78%, Test: 93.09%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 417, Loss: 0.2174, Train: 93.96%, Valid: 91.71%, Test: 92.95%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 418, Loss: 0.2251, Train: 93.70%, Valid: 91.53%, Test: 92.84%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 419, Loss: 0.2243, Train: 93.84%, Valid: 91.38%, Test: 92.88%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 420, Loss: 0.2199, Train: 93.79%, Valid: 91.16%, Test: 92.84%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 421, Loss: 0.2220, Train: 93.86%, Valid: 91.27%, Test: 92.84%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 422, Loss: 0.2201, Train: 93.84%, Valid: 91.53%, Test: 92.69%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 423, Loss: 0.2182, Train: 93.98%, Valid: 91.85%, Test: 93.06%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 424, Loss: 0.2203, Train: 94.17%, Valid: 91.96%, Test: 93.35%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 425, Loss: 0.2165, Train: 94.23%, Valid: 91.56%, Test: 93.31%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 426, Loss: 0.2187, Train: 94.11%, Valid: 91.42%, Test: 92.98%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 427, Loss: 0.2112, Train: 94.11%, Valid: 91.82%, Test: 93.13%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 428, Loss: 0.2147, Train: 94.09%, Valid: 91.89%, Test: 93.09%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 429, Loss: 0.2148, Train: 94.13%, Valid: 91.75%, Test: 93.09%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 430, Loss: 0.2172, Train: 94.23%, Valid: 91.75%, Test: 93.49%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 431, Loss: 0.2153, Train: 94.18%, Valid: 91.85%, Test: 93.42%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 432, Loss: 0.2165, Train: 94.33%, Valid: 92.00%, Test: 93.24%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 433, Loss: 0.2140, Train: 94.09%, Valid: 91.78%, Test: 93.20%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 434, Loss: 0.2156, Train: 94.18%, Valid: 91.56%, Test: 93.09%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 435, Loss: 0.2147, Train: 94.00%, Valid: 91.45%, Test: 93.17%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 436, Loss: 0.2126, Train: 93.98%, Valid: 91.42%, Test: 93.02%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 437, Loss: 0.2093, Train: 94.13%, Valid: 91.89%, Test: 93.20%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 438, Loss: 0.2132, Train: 94.52%, Valid: 92.04%, Test: 93.46%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 439, Loss: 0.2158, Train: 94.34%, Valid: 91.71%, Test: 93.46%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 440, Loss: 0.2080, Train: 94.09%, Valid: 91.45%, Test: 93.24%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 441, Loss: 0.2076, Train: 94.16%, Valid: 91.78%, Test: 93.31%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 442, Loss: 0.2102, Train: 94.34%, Valid: 91.93%, Test: 93.31%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 443, Loss: 0.2170, Train: 94.19%, Valid: 91.53%, Test: 93.38%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 444, Loss: 0.2102, Train: 94.17%, Valid: 91.45%, Test: 93.06%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 445, Loss: 0.2087, Train: 94.28%, Valid: 91.71%, Test: 93.57%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 446, Loss: 0.2199, Train: 94.61%, Valid: 91.96%, Test: 93.13%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 447, Loss: 0.2154, Train: 94.02%, Valid: 91.78%, Test: 92.73%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 448, Loss: 0.2113, Train: 94.02%, Valid: 91.56%, Test: 92.84%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 449, Loss: 0.2109, Train: 94.47%, Valid: 91.71%, Test: 93.82%, Best Valid: 92.25%, Best Test: 92.95%
Epoch: 450, Loss: 0.2126, Train: 94.80%, Valid: 92.40%, Test: 93.93%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 451, Loss: 0.2120, Train: 94.30%, Valid: 91.75%, Test: 93.60%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 452, Loss: 0.2065, Train: 93.98%, Valid: 91.45%, Test: 93.06%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 453, Loss: 0.2096, Train: 94.27%, Valid: 91.60%, Test: 93.13%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 454, Loss: 0.2065, Train: 94.30%, Valid: 91.35%, Test: 93.35%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 455, Loss: 0.2115, Train: 93.89%, Valid: 90.91%, Test: 92.88%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 456, Loss: 0.2122, Train: 93.94%, Valid: 91.31%, Test: 92.91%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 457, Loss: 0.2089, Train: 94.47%, Valid: 92.18%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 458, Loss: 0.2056, Train: 94.63%, Valid: 92.07%, Test: 93.75%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 459, Loss: 0.2170, Train: 94.24%, Valid: 91.60%, Test: 93.28%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 460, Loss: 0.2167, Train: 94.05%, Valid: 91.24%, Test: 93.17%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 461, Loss: 0.2048, Train: 94.32%, Valid: 91.60%, Test: 93.53%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 462, Loss: 0.2091, Train: 94.51%, Valid: 91.64%, Test: 93.68%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 463, Loss: 0.2130, Train: 94.64%, Valid: 91.64%, Test: 93.46%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 464, Loss: 0.2046, Train: 94.40%, Valid: 91.60%, Test: 93.13%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 465, Loss: 0.2063, Train: 94.30%, Valid: 91.71%, Test: 92.98%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 466, Loss: 0.2064, Train: 94.34%, Valid: 91.75%, Test: 93.13%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 467, Loss: 0.2058, Train: 94.34%, Valid: 91.56%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 468, Loss: 0.2031, Train: 94.46%, Valid: 91.38%, Test: 93.82%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 469, Loss: 0.2056, Train: 94.86%, Valid: 92.11%, Test: 94.00%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 470, Loss: 0.2097, Train: 94.46%, Valid: 91.75%, Test: 93.68%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 471, Loss: 0.2015, Train: 94.05%, Valid: 91.35%, Test: 92.77%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 472, Loss: 0.2070, Train: 94.46%, Valid: 91.89%, Test: 93.42%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 473, Loss: 0.2067, Train: 94.72%, Valid: 91.93%, Test: 93.49%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 474, Loss: 0.2071, Train: 94.47%, Valid: 91.64%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 475, Loss: 0.1991, Train: 94.52%, Valid: 91.71%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 476, Loss: 0.2045, Train: 94.86%, Valid: 92.18%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 477, Loss: 0.2043, Train: 94.79%, Valid: 91.93%, Test: 93.82%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 478, Loss: 0.2032, Train: 94.35%, Valid: 90.98%, Test: 93.35%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 479, Loss: 0.2033, Train: 94.32%, Valid: 91.13%, Test: 93.49%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 480, Loss: 0.2036, Train: 94.55%, Valid: 91.56%, Test: 93.09%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 481, Loss: 0.2106, Train: 94.44%, Valid: 91.85%, Test: 92.73%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 482, Loss: 0.2059, Train: 94.80%, Valid: 91.96%, Test: 93.46%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 483, Loss: 0.2003, Train: 94.67%, Valid: 91.53%, Test: 94.00%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 484, Loss: 0.2066, Train: 94.51%, Valid: 91.24%, Test: 93.42%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 485, Loss: 0.2035, Train: 94.58%, Valid: 91.53%, Test: 93.35%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 486, Loss: 0.1959, Train: 94.78%, Valid: 91.89%, Test: 93.17%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 487, Loss: 0.2021, Train: 94.79%, Valid: 91.93%, Test: 93.38%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 488, Loss: 0.1988, Train: 94.39%, Valid: 91.31%, Test: 93.38%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 489, Loss: 0.1957, Train: 94.55%, Valid: 91.27%, Test: 93.46%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 490, Loss: 0.1996, Train: 94.85%, Valid: 92.18%, Test: 93.78%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 491, Loss: 0.1960, Train: 94.57%, Valid: 91.89%, Test: 93.28%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 492, Loss: 0.2221, Train: 94.68%, Valid: 91.56%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 493, Loss: 0.1974, Train: 94.58%, Valid: 91.20%, Test: 93.49%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 494, Loss: 0.2059, Train: 94.84%, Valid: 91.85%, Test: 93.75%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 495, Loss: 0.2065, Train: 94.81%, Valid: 92.40%, Test: 93.49%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 496, Loss: 0.1984, Train: 94.66%, Valid: 92.00%, Test: 93.28%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 497, Loss: 0.2011, Train: 94.61%, Valid: 91.75%, Test: 93.38%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 498, Loss: 0.2011, Train: 94.62%, Valid: 91.38%, Test: 93.24%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 499, Loss: 0.1998, Train: 94.98%, Valid: 91.89%, Test: 93.60%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 500, Loss: 0.2015, Train: 95.12%, Valid: 92.11%, Test: 93.53%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 501, Loss: 0.1956, Train: 94.90%, Valid: 92.18%, Test: 93.42%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 502, Loss: 0.1990, Train: 94.68%, Valid: 91.53%, Test: 93.35%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 503, Loss: 0.1917, Train: 94.30%, Valid: 91.27%, Test: 93.13%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 504, Loss: 0.1889, Train: 94.70%, Valid: 91.75%, Test: 93.57%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 505, Loss: 0.2081, Train: 95.07%, Valid: 92.04%, Test: 93.53%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 506, Loss: 0.1932, Train: 95.13%, Valid: 92.11%, Test: 93.64%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 507, Loss: 0.2001, Train: 95.01%, Valid: 92.00%, Test: 93.78%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 508, Loss: 0.1932, Train: 94.11%, Valid: 91.27%, Test: 92.77%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 509, Loss: 0.2021, Train: 94.11%, Valid: 91.45%, Test: 92.80%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 510, Loss: 0.1938, Train: 95.12%, Valid: 92.25%, Test: 93.64%, Best Valid: 92.40%, Best Test: 93.93%
Epoch: 511, Loss: 0.1939, Train: 95.31%, Valid: 92.47%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 512, Loss: 0.1948, Train: 94.95%, Valid: 91.89%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 513, Loss: 0.1916, Train: 94.68%, Valid: 91.60%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 514, Loss: 0.1957, Train: 94.89%, Valid: 91.78%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 515, Loss: 0.1984, Train: 95.35%, Valid: 92.33%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 516, Loss: 0.1953, Train: 95.36%, Valid: 92.29%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 517, Loss: 0.1909, Train: 94.87%, Valid: 91.75%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 518, Loss: 0.1985, Train: 94.50%, Valid: 91.56%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 519, Loss: 0.1988, Train: 94.81%, Valid: 91.82%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 520, Loss: 0.1983, Train: 95.36%, Valid: 91.85%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 521, Loss: 0.1904, Train: 94.96%, Valid: 91.67%, Test: 93.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 522, Loss: 0.1908, Train: 94.93%, Valid: 91.78%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 523, Loss: 0.1947, Train: 95.10%, Valid: 91.71%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 524, Loss: 0.1971, Train: 95.22%, Valid: 92.00%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 525, Loss: 0.1904, Train: 95.18%, Valid: 91.82%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 526, Loss: 0.2012, Train: 95.32%, Valid: 92.22%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 527, Loss: 0.1944, Train: 95.38%, Valid: 92.04%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 528, Loss: 0.1990, Train: 95.13%, Valid: 91.85%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 529, Loss: 0.1948, Train: 94.59%, Valid: 91.42%, Test: 92.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 530, Loss: 0.1971, Train: 94.45%, Valid: 91.53%, Test: 92.73%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 531, Loss: 0.2004, Train: 94.98%, Valid: 91.67%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 532, Loss: 0.1984, Train: 95.16%, Valid: 91.67%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 533, Loss: 0.1978, Train: 94.91%, Valid: 91.53%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 534, Loss: 0.1956, Train: 94.82%, Valid: 91.82%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 535, Loss: 0.1890, Train: 95.41%, Valid: 92.18%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 536, Loss: 0.1932, Train: 95.43%, Valid: 92.40%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 537, Loss: 0.1916, Train: 95.26%, Valid: 92.04%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 538, Loss: 0.1943, Train: 94.79%, Valid: 91.67%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 539, Loss: 0.1862, Train: 94.87%, Valid: 91.78%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 540, Loss: 0.1837, Train: 95.41%, Valid: 92.29%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 541, Loss: 0.1882, Train: 95.42%, Valid: 92.18%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 542, Loss: 0.1821, Train: 95.22%, Valid: 91.78%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 543, Loss: 0.2000, Train: 95.06%, Valid: 91.53%, Test: 93.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 544, Loss: 0.1928, Train: 95.16%, Valid: 92.00%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 545, Loss: 0.1892, Train: 95.50%, Valid: 92.33%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 546, Loss: 0.1924, Train: 95.37%, Valid: 92.18%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 547, Loss: 0.1848, Train: 95.12%, Valid: 91.82%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 548, Loss: 0.1832, Train: 95.08%, Valid: 91.38%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 549, Loss: 0.1808, Train: 95.29%, Valid: 91.89%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 550, Loss: 0.1894, Train: 95.50%, Valid: 92.40%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 551, Loss: 0.1848, Train: 95.52%, Valid: 92.33%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 552, Loss: 0.1869, Train: 95.43%, Valid: 92.29%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 553, Loss: 0.1842, Train: 94.96%, Valid: 91.35%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 554, Loss: 0.1881, Train: 95.09%, Valid: 91.45%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 555, Loss: 0.1868, Train: 95.30%, Valid: 91.64%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 556, Loss: 0.1850, Train: 95.48%, Valid: 92.15%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 557, Loss: 0.1831, Train: 95.56%, Valid: 92.29%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 558, Loss: 0.1830, Train: 95.47%, Valid: 92.22%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 559, Loss: 0.1887, Train: 95.35%, Valid: 91.89%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 560, Loss: 0.1813, Train: 95.29%, Valid: 91.67%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 561, Loss: 0.1869, Train: 95.47%, Valid: 92.00%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 562, Loss: 0.1893, Train: 95.62%, Valid: 92.18%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 563, Loss: 0.1826, Train: 95.53%, Valid: 92.00%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 564, Loss: 0.1822, Train: 95.48%, Valid: 91.78%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 565, Loss: 0.1816, Train: 95.31%, Valid: 91.75%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 566, Loss: 0.1777, Train: 95.56%, Valid: 92.07%, Test: 94.15%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 567, Loss: 0.1824, Train: 95.58%, Valid: 92.15%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 568, Loss: 0.1807, Train: 95.25%, Valid: 91.93%, Test: 93.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 569, Loss: 0.1867, Train: 95.25%, Valid: 91.75%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 570, Loss: 0.1874, Train: 95.47%, Valid: 91.49%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 571, Loss: 0.1811, Train: 95.52%, Valid: 91.64%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 572, Loss: 0.1863, Train: 95.25%, Valid: 91.31%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 573, Loss: 0.1779, Train: 95.31%, Valid: 91.75%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 574, Loss: 0.1827, Train: 95.44%, Valid: 92.18%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 575, Loss: 0.1779, Train: 95.52%, Valid: 92.22%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 576, Loss: 0.1787, Train: 95.62%, Valid: 92.15%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 577, Loss: 0.1856, Train: 95.39%, Valid: 91.71%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 578, Loss: 0.1799, Train: 95.27%, Valid: 91.56%, Test: 93.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 579, Loss: 0.1763, Train: 95.50%, Valid: 91.89%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 580, Loss: 0.1858, Train: 95.73%, Valid: 92.44%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 581, Loss: 0.1815, Train: 95.60%, Valid: 91.93%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 582, Loss: 0.1711, Train: 95.47%, Valid: 91.82%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 583, Loss: 0.1867, Train: 95.55%, Valid: 92.07%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 584, Loss: 0.1787, Train: 95.33%, Valid: 91.89%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 585, Loss: 0.1865, Train: 95.58%, Valid: 91.85%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 586, Loss: 0.1855, Train: 95.83%, Valid: 92.11%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 587, Loss: 0.1827, Train: 95.77%, Valid: 92.00%, Test: 94.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 588, Loss: 0.1819, Train: 95.59%, Valid: 92.18%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 589, Loss: 0.1856, Train: 95.30%, Valid: 91.75%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 590, Loss: 0.1895, Train: 95.62%, Valid: 92.22%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 591, Loss: 0.1841, Train: 95.70%, Valid: 91.67%, Test: 94.15%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 592, Loss: 0.1816, Train: 95.43%, Valid: 91.42%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 593, Loss: 0.1779, Train: 95.12%, Valid: 91.53%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 594, Loss: 0.1861, Train: 95.48%, Valid: 92.00%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 595, Loss: 0.1788, Train: 95.86%, Valid: 92.29%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 596, Loss: 0.1750, Train: 95.75%, Valid: 92.11%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 597, Loss: 0.1791, Train: 95.61%, Valid: 91.85%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 598, Loss: 0.1826, Train: 95.48%, Valid: 91.96%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 599, Loss: 0.1831, Train: 95.86%, Valid: 92.00%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 600, Loss: 0.1745, Train: 95.83%, Valid: 91.82%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 601, Loss: 0.1812, Train: 95.77%, Valid: 91.67%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 602, Loss: 0.1818, Train: 95.54%, Valid: 91.75%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 603, Loss: 0.1822, Train: 95.37%, Valid: 91.31%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 604, Loss: 0.1713, Train: 95.38%, Valid: 91.53%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 605, Loss: 0.1818, Train: 95.48%, Valid: 91.67%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 606, Loss: 0.1785, Train: 95.72%, Valid: 92.00%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 607, Loss: 0.1771, Train: 95.53%, Valid: 91.75%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 608, Loss: 0.1732, Train: 95.96%, Valid: 92.18%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 609, Loss: 0.1793, Train: 95.88%, Valid: 92.07%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 610, Loss: 0.1706, Train: 95.69%, Valid: 91.82%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 611, Loss: 0.1699, Train: 95.36%, Valid: 91.24%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 612, Loss: 0.1749, Train: 95.39%, Valid: 91.71%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 613, Loss: 0.1713, Train: 95.88%, Valid: 91.96%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 614, Loss: 0.1717, Train: 95.89%, Valid: 91.75%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 615, Loss: 0.1764, Train: 95.82%, Valid: 91.60%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 616, Loss: 0.1770, Train: 95.73%, Valid: 91.53%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 617, Loss: 0.1726, Train: 95.67%, Valid: 91.75%, Test: 93.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 618, Loss: 0.1744, Train: 95.89%, Valid: 91.96%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 619, Loss: 0.1748, Train: 95.86%, Valid: 91.89%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 620, Loss: 0.1703, Train: 95.65%, Valid: 91.45%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 621, Loss: 0.1695, Train: 95.69%, Valid: 91.31%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 622, Loss: 0.1736, Train: 96.02%, Valid: 91.53%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 623, Loss: 0.1710, Train: 95.98%, Valid: 91.60%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 624, Loss: 0.1758, Train: 95.95%, Valid: 91.49%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 625, Loss: 0.1699, Train: 95.83%, Valid: 91.82%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 626, Loss: 0.1647, Train: 95.94%, Valid: 92.04%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 627, Loss: 0.1750, Train: 96.09%, Valid: 92.22%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 628, Loss: 0.1670, Train: 95.93%, Valid: 91.78%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 629, Loss: 0.1784, Train: 95.65%, Valid: 91.64%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 630, Loss: 0.1757, Train: 96.02%, Valid: 91.89%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 631, Loss: 0.1686, Train: 96.19%, Valid: 92.04%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 632, Loss: 0.1756, Train: 95.96%, Valid: 91.93%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 633, Loss: 0.1686, Train: 95.64%, Valid: 91.67%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 634, Loss: 0.1761, Train: 95.93%, Valid: 91.64%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 635, Loss: 0.1689, Train: 95.92%, Valid: 91.78%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 636, Loss: 0.1812, Train: 96.17%, Valid: 92.11%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 637, Loss: 0.1696, Train: 95.88%, Valid: 91.60%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 638, Loss: 0.1693, Train: 95.55%, Valid: 91.35%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 639, Loss: 0.1807, Train: 95.94%, Valid: 91.67%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 640, Loss: 0.1720, Train: 96.23%, Valid: 92.07%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 641, Loss: 0.1779, Train: 96.09%, Valid: 92.11%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 642, Loss: 0.1721, Train: 95.49%, Valid: 91.16%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 643, Loss: 0.1720, Train: 95.71%, Valid: 91.35%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 644, Loss: 0.1705, Train: 95.98%, Valid: 91.45%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 645, Loss: 0.1749, Train: 96.19%, Valid: 91.85%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 646, Loss: 0.1765, Train: 95.96%, Valid: 91.89%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 647, Loss: 0.1652, Train: 95.67%, Valid: 91.13%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 648, Loss: 0.1681, Train: 95.59%, Valid: 91.35%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 649, Loss: 0.1749, Train: 96.09%, Valid: 92.07%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 650, Loss: 0.1640, Train: 96.06%, Valid: 92.07%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 651, Loss: 0.1681, Train: 95.75%, Valid: 91.53%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 652, Loss: 0.1658, Train: 95.86%, Valid: 91.64%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 653, Loss: 0.1689, Train: 95.79%, Valid: 91.35%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 654, Loss: 0.1768, Train: 96.01%, Valid: 91.64%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 655, Loss: 0.1661, Train: 96.24%, Valid: 92.00%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 656, Loss: 0.1648, Train: 95.98%, Valid: 91.45%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 657, Loss: 0.1824, Train: 96.07%, Valid: 91.82%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 658, Loss: 0.1651, Train: 96.04%, Valid: 92.07%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 659, Loss: 0.1661, Train: 95.79%, Valid: 91.67%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 660, Loss: 0.1727, Train: 96.04%, Valid: 91.93%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 661, Loss: 0.1654, Train: 95.84%, Valid: 91.64%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 662, Loss: 0.1696, Train: 95.93%, Valid: 91.71%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 663, Loss: 0.1697, Train: 96.29%, Valid: 91.67%, Test: 94.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 664, Loss: 0.1632, Train: 95.98%, Valid: 91.78%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 665, Loss: 0.1747, Train: 96.04%, Valid: 91.82%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 666, Loss: 0.1720, Train: 96.16%, Valid: 91.85%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 667, Loss: 0.1630, Train: 95.90%, Valid: 91.78%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 668, Loss: 0.1637, Train: 96.11%, Valid: 91.78%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 669, Loss: 0.1646, Train: 96.29%, Valid: 92.11%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 670, Loss: 0.1690, Train: 96.19%, Valid: 92.15%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 671, Loss: 0.1708, Train: 96.24%, Valid: 92.22%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 672, Loss: 0.1640, Train: 96.18%, Valid: 91.71%, Test: 94.40%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 673, Loss: 0.1670, Train: 95.98%, Valid: 91.56%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 674, Loss: 0.1710, Train: 95.88%, Valid: 91.75%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 675, Loss: 0.1658, Train: 96.04%, Valid: 91.78%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 676, Loss: 0.1630, Train: 96.13%, Valid: 91.82%, Test: 94.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 677, Loss: 0.1661, Train: 96.12%, Valid: 91.85%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 678, Loss: 0.1711, Train: 96.00%, Valid: 91.38%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 679, Loss: 0.1595, Train: 95.69%, Valid: 91.16%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 680, Loss: 0.1641, Train: 96.09%, Valid: 92.00%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 681, Loss: 0.1603, Train: 96.06%, Valid: 91.89%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 682, Loss: 0.1654, Train: 96.10%, Valid: 91.53%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 683, Loss: 0.1605, Train: 95.84%, Valid: 91.64%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 684, Loss: 0.1579, Train: 95.92%, Valid: 91.42%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 685, Loss: 0.1597, Train: 96.04%, Valid: 91.53%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 686, Loss: 0.1628, Train: 96.15%, Valid: 91.85%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 687, Loss: 0.1606, Train: 96.15%, Valid: 91.67%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 688, Loss: 0.1644, Train: 95.94%, Valid: 91.31%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 689, Loss: 0.1663, Train: 95.93%, Valid: 91.71%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 690, Loss: 0.1646, Train: 95.94%, Valid: 91.75%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 691, Loss: 0.1563, Train: 96.00%, Valid: 91.56%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 692, Loss: 0.1563, Train: 96.09%, Valid: 91.53%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 693, Loss: 0.1628, Train: 96.09%, Valid: 91.64%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 694, Loss: 0.1612, Train: 96.23%, Valid: 91.96%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 695, Loss: 0.1600, Train: 96.30%, Valid: 91.75%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 696, Loss: 0.1632, Train: 96.16%, Valid: 91.60%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 697, Loss: 0.1529, Train: 96.00%, Valid: 91.31%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 698, Loss: 0.1630, Train: 95.95%, Valid: 91.60%, Test: 94.26%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 699, Loss: 0.1577, Train: 96.21%, Valid: 91.82%, Test: 94.15%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 700, Loss: 0.1606, Train: 96.17%, Valid: 91.82%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 701, Loss: 0.1666, Train: 96.22%, Valid: 91.71%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 702, Loss: 0.1583, Train: 96.05%, Valid: 91.31%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 703, Loss: 0.1603, Train: 96.10%, Valid: 91.38%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 704, Loss: 0.1550, Train: 96.29%, Valid: 91.89%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 705, Loss: 0.1625, Train: 96.10%, Valid: 91.75%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 706, Loss: 0.1638, Train: 96.01%, Valid: 91.45%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 707, Loss: 0.1658, Train: 96.30%, Valid: 91.67%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 708, Loss: 0.1613, Train: 96.17%, Valid: 91.71%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 709, Loss: 0.1623, Train: 96.23%, Valid: 91.27%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 710, Loss: 0.1580, Train: 95.89%, Valid: 91.42%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 711, Loss: 0.1672, Train: 96.23%, Valid: 91.56%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 712, Loss: 0.1633, Train: 96.02%, Valid: 91.53%, Test: 93.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 713, Loss: 0.1647, Train: 95.96%, Valid: 91.75%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 714, Loss: 0.1634, Train: 96.39%, Valid: 91.93%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 715, Loss: 0.1608, Train: 95.86%, Valid: 91.75%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 716, Loss: 0.1770, Train: 96.02%, Valid: 91.71%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 717, Loss: 0.1652, Train: 96.17%, Valid: 91.38%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 718, Loss: 0.1579, Train: 96.02%, Valid: 91.67%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 719, Loss: 0.1605, Train: 96.27%, Valid: 91.67%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 720, Loss: 0.1579, Train: 96.42%, Valid: 91.85%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 721, Loss: 0.1580, Train: 96.12%, Valid: 91.64%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 722, Loss: 0.1606, Train: 96.02%, Valid: 91.49%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 723, Loss: 0.1582, Train: 96.16%, Valid: 91.16%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 724, Loss: 0.1578, Train: 96.12%, Valid: 91.27%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 725, Loss: 0.1668, Train: 96.23%, Valid: 91.42%, Test: 93.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 726, Loss: 0.1545, Train: 96.18%, Valid: 91.24%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 727, Loss: 0.1571, Train: 96.22%, Valid: 91.53%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 728, Loss: 0.1599, Train: 96.19%, Valid: 91.38%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 729, Loss: 0.1592, Train: 96.30%, Valid: 91.42%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 730, Loss: 0.1552, Train: 95.88%, Valid: 90.98%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 731, Loss: 0.1568, Train: 95.88%, Valid: 91.24%, Test: 93.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 732, Loss: 0.1568, Train: 96.12%, Valid: 91.35%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 733, Loss: 0.1606, Train: 96.25%, Valid: 91.89%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 734, Loss: 0.1575, Train: 96.11%, Valid: 91.27%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 735, Loss: 0.1564, Train: 95.96%, Valid: 90.76%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 736, Loss: 0.1547, Train: 96.17%, Valid: 91.20%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 737, Loss: 0.1517, Train: 96.35%, Valid: 91.35%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 738, Loss: 0.1646, Train: 96.10%, Valid: 90.98%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 739, Loss: 0.1499, Train: 95.96%, Valid: 91.16%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 740, Loss: 0.1579, Train: 96.18%, Valid: 91.56%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 741, Loss: 0.1540, Train: 96.41%, Valid: 91.64%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 742, Loss: 0.1489, Train: 96.34%, Valid: 91.49%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 743, Loss: 0.1541, Train: 96.13%, Valid: 91.24%, Test: 93.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 744, Loss: 0.1545, Train: 96.36%, Valid: 91.24%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 745, Loss: 0.1532, Train: 96.53%, Valid: 91.53%, Test: 94.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 746, Loss: 0.1512, Train: 96.49%, Valid: 91.56%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 747, Loss: 0.1451, Train: 96.27%, Valid: 91.27%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 748, Loss: 0.1427, Train: 96.18%, Valid: 91.20%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 749, Loss: 0.1539, Train: 96.47%, Valid: 91.45%, Test: 94.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 750, Loss: 0.1566, Train: 96.55%, Valid: 91.56%, Test: 94.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 751, Loss: 0.1465, Train: 96.42%, Valid: 91.45%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 752, Loss: 0.1538, Train: 96.36%, Valid: 91.20%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 753, Loss: 0.1458, Train: 96.41%, Valid: 91.56%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 754, Loss: 0.1488, Train: 96.61%, Valid: 91.71%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 755, Loss: 0.1565, Train: 96.55%, Valid: 91.60%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 756, Loss: 0.1483, Train: 96.47%, Valid: 91.20%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 757, Loss: 0.1503, Train: 96.34%, Valid: 91.16%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 758, Loss: 0.1486, Train: 96.22%, Valid: 91.09%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 759, Loss: 0.1481, Train: 96.41%, Valid: 90.95%, Test: 93.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 760, Loss: 0.1524, Train: 96.49%, Valid: 91.16%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 761, Loss: 0.1525, Train: 96.29%, Valid: 91.09%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 762, Loss: 0.1476, Train: 96.40%, Valid: 91.13%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 763, Loss: 0.1523, Train: 96.61%, Valid: 91.71%, Test: 93.86%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 764, Loss: 0.1557, Train: 96.63%, Valid: 91.78%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 765, Loss: 0.1593, Train: 96.38%, Valid: 91.27%, Test: 93.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 766, Loss: 0.1514, Train: 96.16%, Valid: 91.20%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 767, Loss: 0.1637, Train: 96.57%, Valid: 91.35%, Test: 93.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 768, Loss: 0.1515, Train: 96.41%, Valid: 91.42%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 769, Loss: 0.1543, Train: 96.58%, Valid: 91.64%, Test: 94.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 770, Loss: 0.1468, Train: 96.42%, Valid: 91.38%, Test: 93.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 771, Loss: 0.1594, Train: 96.21%, Valid: 91.31%, Test: 93.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 772, Loss: 0.1476, Train: 96.24%, Valid: 91.24%, Test: 93.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 773, Loss: 0.1555, Train: 96.49%, Valid: 91.56%, Test: 94.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 774, Loss: 0.1462, Train: 96.41%, Valid: 91.93%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 775, Loss: 0.1586, Train: 96.57%, Valid: 91.82%, Test: 93.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 776, Loss: 0.1588, Train: 94.09%, Valid: 89.53%, Test: 91.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 777, Loss: 0.1619, Train: 95.98%, Valid: 91.49%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 778, Loss: 0.2238, Train: 90.62%, Valid: 85.89%, Test: 88.33%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 779, Loss: 0.2743, Train: 95.73%, Valid: 90.69%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 780, Loss: 0.2087, Train: 95.83%, Valid: 90.40%, Test: 92.51%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 781, Loss: 0.1853, Train: 96.15%, Valid: 91.16%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 782, Loss: 0.1892, Train: 94.63%, Valid: 89.82%, Test: 91.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 783, Loss: 0.2033, Train: 96.28%, Valid: 91.16%, Test: 93.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 784, Loss: 0.1837, Train: 95.50%, Valid: 90.29%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 785, Loss: 0.1790, Train: 95.46%, Valid: 90.40%, Test: 92.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 786, Loss: 0.1886, Train: 96.05%, Valid: 91.27%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 787, Loss: 0.2009, Train: 92.21%, Valid: 87.93%, Test: 89.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 788, Loss: 0.2286, Train: 94.80%, Valid: 89.85%, Test: 92.08%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 789, Loss: 0.2400, Train: 86.09%, Valid: 82.22%, Test: 81.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 790, Loss: 0.5020, Train: 91.31%, Valid: 87.35%, Test: 88.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 791, Loss: 0.4410, Train: 72.85%, Valid: 69.96%, Test: 70.45%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 792, Loss: 1.0841, Train: 31.77%, Valid: 29.82%, Test: 29.59%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 793, Loss: 1.8902, Train: 46.25%, Valid: 44.95%, Test: 46.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 794, Loss: 2.3417, Train: 16.66%, Valid: 15.27%, Test: 15.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 795, Loss: 2.6233, Train: 16.76%, Valid: 16.91%, Test: 16.47%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 796, Loss: 2.2184, Train: 17.06%, Valid: 17.85%, Test: 17.67%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 797, Loss: 2.1738, Train: 48.83%, Valid: 47.24%, Test: 48.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 798, Loss: 2.1714, Train: 37.63%, Valid: 36.11%, Test: 38.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 799, Loss: 1.9689, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 800, Loss: 1.9633, Train: 37.61%, Valid: 36.18%, Test: 38.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 801, Loss: 1.8930, Train: 39.32%, Valid: 38.47%, Test: 39.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 802, Loss: 1.7480, Train: 41.85%, Valid: 41.16%, Test: 42.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 803, Loss: 1.6423, Train: 42.66%, Valid: 41.53%, Test: 43.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 804, Loss: 1.6382, Train: 47.96%, Valid: 46.62%, Test: 47.26%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 805, Loss: 1.7256, Train: 41.86%, Valid: 41.20%, Test: 42.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 806, Loss: 1.5853, Train: 41.83%, Valid: 40.98%, Test: 42.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 807, Loss: 1.5506, Train: 47.21%, Valid: 46.33%, Test: 47.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 808, Loss: 1.5618, Train: 47.86%, Valid: 47.05%, Test: 48.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 809, Loss: 1.5351, Train: 46.61%, Valid: 45.75%, Test: 46.67%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 810, Loss: 1.5078, Train: 48.04%, Valid: 47.13%, Test: 48.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 811, Loss: 1.4830, Train: 48.12%, Valid: 46.95%, Test: 47.76%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 812, Loss: 1.5137, Train: 51.27%, Valid: 49.31%, Test: 51.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 813, Loss: 1.4826, Train: 49.44%, Valid: 48.18%, Test: 49.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 814, Loss: 1.4909, Train: 50.37%, Valid: 48.22%, Test: 51.69%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 815, Loss: 1.4624, Train: 49.45%, Valid: 47.38%, Test: 50.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 816, Loss: 1.4431, Train: 50.75%, Valid: 49.02%, Test: 52.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 817, Loss: 1.4336, Train: 51.56%, Valid: 49.75%, Test: 52.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 818, Loss: 1.4152, Train: 51.91%, Valid: 50.00%, Test: 52.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 819, Loss: 1.4177, Train: 52.02%, Valid: 50.47%, Test: 52.67%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 820, Loss: 1.3877, Train: 52.61%, Valid: 50.29%, Test: 52.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 821, Loss: 1.3847, Train: 53.75%, Valid: 51.27%, Test: 53.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 822, Loss: 1.4157, Train: 52.85%, Valid: 51.42%, Test: 53.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 823, Loss: 1.3837, Train: 57.11%, Valid: 54.95%, Test: 57.14%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 824, Loss: 1.3821, Train: 54.48%, Valid: 52.76%, Test: 54.67%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 825, Loss: 1.3918, Train: 47.75%, Valid: 45.71%, Test: 46.67%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 826, Loss: 1.4534, Train: 53.70%, Valid: 52.11%, Test: 54.27%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 827, Loss: 1.4277, Train: 55.38%, Valid: 52.62%, Test: 54.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 828, Loss: 1.4233, Train: 57.01%, Valid: 55.53%, Test: 58.23%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 829, Loss: 1.3265, Train: 53.76%, Valid: 52.58%, Test: 54.23%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 830, Loss: 1.3647, Train: 54.04%, Valid: 51.78%, Test: 53.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 831, Loss: 1.3369, Train: 54.32%, Valid: 51.85%, Test: 53.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 832, Loss: 1.3193, Train: 55.21%, Valid: 53.49%, Test: 54.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 833, Loss: 1.3238, Train: 56.84%, Valid: 54.87%, Test: 56.74%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 834, Loss: 1.2715, Train: 60.50%, Valid: 58.40%, Test: 60.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 835, Loss: 1.2814, Train: 61.77%, Valid: 59.82%, Test: 61.21%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 836, Loss: 1.2517, Train: 56.84%, Valid: 55.78%, Test: 58.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 837, Loss: 1.2481, Train: 60.90%, Valid: 59.38%, Test: 62.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 838, Loss: 1.2360, Train: 62.74%, Valid: 61.53%, Test: 62.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 839, Loss: 1.2288, Train: 59.20%, Valid: 58.15%, Test: 59.61%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 840, Loss: 1.2096, Train: 59.76%, Valid: 58.04%, Test: 60.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 841, Loss: 1.2105, Train: 60.51%, Valid: 58.51%, Test: 60.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 842, Loss: 1.1854, Train: 60.72%, Valid: 58.80%, Test: 61.07%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 843, Loss: 1.1746, Train: 59.71%, Valid: 59.05%, Test: 59.76%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 844, Loss: 1.1738, Train: 61.10%, Valid: 59.56%, Test: 61.43%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 845, Loss: 1.1451, Train: 63.18%, Valid: 61.20%, Test: 64.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 846, Loss: 1.1449, Train: 61.68%, Valid: 60.36%, Test: 62.70%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 847, Loss: 1.1092, Train: 61.50%, Valid: 60.58%, Test: 62.30%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 848, Loss: 1.1229, Train: 66.40%, Valid: 64.65%, Test: 66.23%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 849, Loss: 1.1564, Train: 61.88%, Valid: 61.05%, Test: 62.34%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 850, Loss: 1.1132, Train: 60.78%, Valid: 60.04%, Test: 61.25%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 851, Loss: 1.1476, Train: 63.51%, Valid: 62.00%, Test: 64.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 852, Loss: 1.0580, Train: 64.76%, Valid: 63.02%, Test: 65.61%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 853, Loss: 1.0865, Train: 64.27%, Valid: 62.47%, Test: 65.25%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 854, Loss: 1.0845, Train: 63.20%, Valid: 61.20%, Test: 63.21%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 855, Loss: 1.0487, Train: 63.50%, Valid: 61.78%, Test: 63.14%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 856, Loss: 1.0603, Train: 64.82%, Valid: 62.44%, Test: 65.36%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 857, Loss: 1.0085, Train: 64.22%, Valid: 61.96%, Test: 65.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 858, Loss: 1.0359, Train: 67.58%, Valid: 66.00%, Test: 67.36%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 859, Loss: 0.9747, Train: 65.99%, Valid: 64.58%, Test: 65.43%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 860, Loss: 1.0435, Train: 67.47%, Valid: 66.36%, Test: 67.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 861, Loss: 0.9730, Train: 65.22%, Valid: 63.09%, Test: 66.16%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 862, Loss: 0.9776, Train: 65.64%, Valid: 63.35%, Test: 66.81%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 863, Loss: 0.9666, Train: 68.54%, Valid: 66.98%, Test: 68.56%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 864, Loss: 0.9333, Train: 68.28%, Valid: 66.91%, Test: 68.34%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 865, Loss: 0.9375, Train: 67.30%, Valid: 65.89%, Test: 67.50%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 866, Loss: 0.9297, Train: 67.40%, Valid: 65.49%, Test: 67.54%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 867, Loss: 0.8947, Train: 67.73%, Valid: 65.16%, Test: 68.45%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 868, Loss: 0.9074, Train: 68.06%, Valid: 65.93%, Test: 68.45%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 869, Loss: 0.9002, Train: 70.12%, Valid: 68.47%, Test: 70.12%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 870, Loss: 0.8784, Train: 73.07%, Valid: 71.75%, Test: 71.90%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 871, Loss: 0.8948, Train: 72.95%, Valid: 71.89%, Test: 71.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 872, Loss: 0.8809, Train: 70.32%, Valid: 68.62%, Test: 70.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 873, Loss: 0.8464, Train: 68.55%, Valid: 66.40%, Test: 68.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 874, Loss: 0.8728, Train: 65.70%, Valid: 63.75%, Test: 66.41%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 875, Loss: 0.8784, Train: 71.94%, Valid: 70.33%, Test: 71.97%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 876, Loss: 0.8927, Train: 71.45%, Valid: 69.13%, Test: 71.54%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 877, Loss: 0.8199, Train: 71.62%, Valid: 70.91%, Test: 70.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 878, Loss: 0.8569, Train: 75.92%, Valid: 75.09%, Test: 74.99%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 879, Loss: 0.8336, Train: 73.35%, Valid: 71.02%, Test: 72.85%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 880, Loss: 0.8404, Train: 77.43%, Valid: 76.15%, Test: 76.63%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 881, Loss: 0.8087, Train: 70.59%, Valid: 68.62%, Test: 70.96%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 882, Loss: 0.8333, Train: 69.08%, Valid: 67.24%, Test: 69.43%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 883, Loss: 0.8064, Train: 71.75%, Valid: 69.82%, Test: 71.94%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 884, Loss: 0.8022, Train: 76.96%, Valid: 75.42%, Test: 76.30%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 885, Loss: 0.7921, Train: 78.31%, Valid: 76.65%, Test: 77.68%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 886, Loss: 0.7773, Train: 75.68%, Valid: 73.89%, Test: 76.12%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 887, Loss: 0.8039, Train: 76.25%, Valid: 73.75%, Test: 76.26%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 888, Loss: 0.7644, Train: 79.04%, Valid: 78.11%, Test: 78.70%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 889, Loss: 0.7531, Train: 76.85%, Valid: 75.75%, Test: 77.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 890, Loss: 0.7289, Train: 75.09%, Valid: 73.49%, Test: 75.43%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 891, Loss: 0.7134, Train: 76.44%, Valid: 74.98%, Test: 76.52%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 892, Loss: 0.7091, Train: 79.81%, Valid: 78.22%, Test: 78.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 893, Loss: 0.7190, Train: 78.61%, Valid: 76.36%, Test: 79.03%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 894, Loss: 0.7154, Train: 80.54%, Valid: 78.62%, Test: 80.92%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 895, Loss: 0.6868, Train: 80.34%, Valid: 78.69%, Test: 80.41%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 896, Loss: 0.6785, Train: 79.93%, Valid: 77.45%, Test: 80.55%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 897, Loss: 0.6961, Train: 77.72%, Valid: 75.56%, Test: 78.15%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 898, Loss: 0.6711, Train: 77.81%, Valid: 75.64%, Test: 78.23%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 899, Loss: 0.6546, Train: 82.60%, Valid: 79.78%, Test: 82.99%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 900, Loss: 0.6407, Train: 83.41%, Valid: 80.69%, Test: 83.61%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 901, Loss: 0.6296, Train: 82.41%, Valid: 80.33%, Test: 82.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 902, Loss: 0.6266, Train: 82.40%, Valid: 79.96%, Test: 82.12%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 903, Loss: 0.6257, Train: 82.44%, Valid: 79.82%, Test: 82.19%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 904, Loss: 0.6132, Train: 82.34%, Valid: 78.62%, Test: 81.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 905, Loss: 0.5994, Train: 84.14%, Valid: 80.65%, Test: 83.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 906, Loss: 0.5762, Train: 84.96%, Valid: 82.18%, Test: 85.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 907, Loss: 0.6077, Train: 84.81%, Valid: 82.04%, Test: 84.99%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 908, Loss: 0.5623, Train: 84.51%, Valid: 81.49%, Test: 84.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 909, Loss: 0.5754, Train: 83.17%, Valid: 80.55%, Test: 82.59%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 910, Loss: 0.5583, Train: 85.93%, Valid: 82.98%, Test: 84.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 911, Loss: 0.5639, Train: 85.74%, Valid: 82.36%, Test: 85.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 912, Loss: 0.5539, Train: 86.57%, Valid: 83.38%, Test: 86.40%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 913, Loss: 0.5480, Train: 86.10%, Valid: 83.38%, Test: 86.01%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 914, Loss: 0.5538, Train: 85.38%, Valid: 82.40%, Test: 86.08%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 915, Loss: 0.5366, Train: 86.52%, Valid: 83.35%, Test: 86.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 916, Loss: 0.5157, Train: 86.28%, Valid: 83.24%, Test: 85.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 917, Loss: 0.5182, Train: 85.02%, Valid: 82.40%, Test: 84.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 918, Loss: 0.5128, Train: 85.72%, Valid: 82.58%, Test: 85.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 919, Loss: 0.5109, Train: 86.27%, Valid: 82.98%, Test: 86.30%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 920, Loss: 0.5214, Train: 87.57%, Valid: 84.80%, Test: 87.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 921, Loss: 0.5063, Train: 88.21%, Valid: 85.05%, Test: 87.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 922, Loss: 0.5063, Train: 86.15%, Valid: 83.42%, Test: 86.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 923, Loss: 0.4944, Train: 87.15%, Valid: 83.82%, Test: 86.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 924, Loss: 0.5074, Train: 87.60%, Valid: 84.87%, Test: 87.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 925, Loss: 0.5020, Train: 89.08%, Valid: 86.84%, Test: 88.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 926, Loss: 0.4981, Train: 88.83%, Valid: 86.00%, Test: 88.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 927, Loss: 0.4937, Train: 87.24%, Valid: 84.04%, Test: 87.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 928, Loss: 0.5165, Train: 88.80%, Valid: 85.53%, Test: 87.75%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 929, Loss: 0.4859, Train: 88.10%, Valid: 86.40%, Test: 87.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 930, Loss: 0.4946, Train: 88.32%, Valid: 86.73%, Test: 87.50%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 931, Loss: 0.5140, Train: 89.23%, Valid: 86.22%, Test: 88.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 932, Loss: 0.4557, Train: 90.22%, Valid: 86.29%, Test: 89.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 933, Loss: 0.4595, Train: 90.11%, Valid: 87.24%, Test: 89.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 934, Loss: 0.4745, Train: 89.66%, Valid: 87.13%, Test: 89.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 935, Loss: 0.4471, Train: 89.10%, Valid: 86.76%, Test: 88.37%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 936, Loss: 0.4269, Train: 89.13%, Valid: 86.80%, Test: 88.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 937, Loss: 0.4376, Train: 90.64%, Valid: 87.78%, Test: 89.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 938, Loss: 0.4295, Train: 89.94%, Valid: 86.95%, Test: 89.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 939, Loss: 0.4487, Train: 90.20%, Valid: 87.20%, Test: 89.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 940, Loss: 0.4279, Train: 90.73%, Valid: 87.85%, Test: 90.11%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 941, Loss: 0.3976, Train: 91.82%, Valid: 89.27%, Test: 91.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 942, Loss: 0.4216, Train: 90.62%, Valid: 88.84%, Test: 90.00%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 943, Loss: 0.3991, Train: 89.44%, Valid: 87.31%, Test: 89.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 944, Loss: 0.4036, Train: 90.62%, Valid: 87.60%, Test: 90.15%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 945, Loss: 0.4004, Train: 91.94%, Valid: 89.35%, Test: 90.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 946, Loss: 0.3770, Train: 90.72%, Valid: 88.84%, Test: 89.82%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 947, Loss: 0.4265, Train: 92.22%, Valid: 89.60%, Test: 91.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 948, Loss: 0.3996, Train: 92.09%, Valid: 89.49%, Test: 91.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 949, Loss: 0.3970, Train: 91.63%, Valid: 89.20%, Test: 91.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 950, Loss: 0.3722, Train: 91.53%, Valid: 89.24%, Test: 91.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 951, Loss: 0.3721, Train: 92.44%, Valid: 90.25%, Test: 91.64%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 952, Loss: 0.3618, Train: 92.66%, Valid: 90.11%, Test: 91.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 953, Loss: 0.3750, Train: 92.36%, Valid: 89.75%, Test: 91.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 954, Loss: 0.3537, Train: 92.45%, Valid: 89.75%, Test: 91.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 955, Loss: 0.3616, Train: 92.28%, Valid: 89.45%, Test: 91.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 956, Loss: 0.3625, Train: 92.34%, Valid: 89.60%, Test: 91.53%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 957, Loss: 0.3541, Train: 91.48%, Valid: 88.98%, Test: 90.59%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 958, Loss: 0.3565, Train: 92.72%, Valid: 90.22%, Test: 91.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 959, Loss: 0.3426, Train: 92.91%, Valid: 90.29%, Test: 91.78%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 960, Loss: 0.3575, Train: 91.94%, Valid: 89.49%, Test: 91.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 961, Loss: 0.3444, Train: 92.74%, Valid: 90.44%, Test: 92.08%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 962, Loss: 0.3370, Train: 93.32%, Valid: 90.73%, Test: 92.29%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 963, Loss: 0.3303, Train: 93.10%, Valid: 90.58%, Test: 92.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 964, Loss: 0.3325, Train: 91.39%, Valid: 89.42%, Test: 90.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 965, Loss: 0.3563, Train: 92.83%, Valid: 90.40%, Test: 91.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 966, Loss: 0.3220, Train: 92.41%, Valid: 89.56%, Test: 91.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 967, Loss: 0.3696, Train: 92.10%, Valid: 89.49%, Test: 91.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 968, Loss: 0.3446, Train: 91.76%, Valid: 89.35%, Test: 90.44%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 969, Loss: 0.3425, Train: 93.26%, Valid: 90.84%, Test: 92.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 970, Loss: 0.3388, Train: 92.50%, Valid: 89.27%, Test: 91.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 971, Loss: 0.3517, Train: 93.59%, Valid: 90.62%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 972, Loss: 0.3308, Train: 92.30%, Valid: 89.85%, Test: 90.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 973, Loss: 0.3290, Train: 92.39%, Valid: 90.07%, Test: 91.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 974, Loss: 0.3341, Train: 93.03%, Valid: 90.87%, Test: 91.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 975, Loss: 0.3137, Train: 93.03%, Valid: 90.22%, Test: 92.04%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 976, Loss: 0.3286, Train: 93.23%, Valid: 90.33%, Test: 92.08%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 977, Loss: 0.3116, Train: 92.79%, Valid: 90.07%, Test: 91.71%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 978, Loss: 0.3168, Train: 93.09%, Valid: 90.36%, Test: 91.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 979, Loss: 0.3190, Train: 93.55%, Valid: 90.98%, Test: 92.37%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 980, Loss: 0.3094, Train: 93.48%, Valid: 91.20%, Test: 91.89%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 981, Loss: 0.3137, Train: 93.71%, Valid: 90.87%, Test: 92.55%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 982, Loss: 0.3155, Train: 93.16%, Valid: 90.25%, Test: 92.22%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 983, Loss: 0.3098, Train: 93.49%, Valid: 90.36%, Test: 92.26%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 984, Loss: 0.3024, Train: 93.39%, Valid: 91.24%, Test: 92.18%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 985, Loss: 0.3181, Train: 93.84%, Valid: 91.35%, Test: 92.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 986, Loss: 0.3009, Train: 93.63%, Valid: 90.65%, Test: 92.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 987, Loss: 0.2972, Train: 93.30%, Valid: 90.51%, Test: 91.93%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 988, Loss: 0.2972, Train: 93.63%, Valid: 90.76%, Test: 92.33%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 989, Loss: 0.2983, Train: 93.87%, Valid: 91.02%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 990, Loss: 0.3001, Train: 93.99%, Valid: 91.02%, Test: 92.69%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 991, Loss: 0.2809, Train: 93.70%, Valid: 90.80%, Test: 92.48%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 992, Loss: 0.2936, Train: 93.82%, Valid: 90.65%, Test: 92.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 993, Loss: 0.2798, Train: 93.94%, Valid: 90.69%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 994, Loss: 0.2985, Train: 94.13%, Valid: 91.16%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 995, Loss: 0.2866, Train: 94.11%, Valid: 91.09%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 996, Loss: 0.2884, Train: 94.15%, Valid: 90.91%, Test: 92.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 997, Loss: 0.2766, Train: 94.12%, Valid: 91.13%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 998, Loss: 0.2785, Train: 94.36%, Valid: 91.38%, Test: 92.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 999, Loss: 0.3016, Train: 94.34%, Valid: 91.49%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1000, Loss: 0.2790, Train: 94.33%, Valid: 91.05%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1001, Loss: 0.2869, Train: 93.90%, Valid: 90.87%, Test: 92.55%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1002, Loss: 0.2786, Train: 94.47%, Valid: 91.53%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1003, Loss: 0.2795, Train: 94.26%, Valid: 90.98%, Test: 92.55%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1004, Loss: 0.2800, Train: 94.26%, Valid: 91.27%, Test: 92.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1005, Loss: 0.2769, Train: 94.01%, Valid: 90.95%, Test: 92.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1006, Loss: 0.2816, Train: 93.35%, Valid: 90.36%, Test: 91.60%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1007, Loss: 0.2818, Train: 94.39%, Valid: 91.49%, Test: 92.44%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1008, Loss: 0.2785, Train: 94.52%, Valid: 91.78%, Test: 92.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1009, Loss: 0.2626, Train: 94.39%, Valid: 91.60%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1010, Loss: 0.2681, Train: 94.39%, Valid: 91.49%, Test: 92.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1011, Loss: 0.2750, Train: 94.16%, Valid: 91.16%, Test: 92.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1012, Loss: 0.2658, Train: 94.44%, Valid: 91.27%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1013, Loss: 0.2590, Train: 94.78%, Valid: 91.96%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1014, Loss: 0.2649, Train: 94.67%, Valid: 91.82%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1015, Loss: 0.2636, Train: 94.58%, Valid: 91.67%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1016, Loss: 0.2658, Train: 94.53%, Valid: 91.67%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1017, Loss: 0.2580, Train: 94.42%, Valid: 91.78%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1018, Loss: 0.2617, Train: 94.47%, Valid: 91.64%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1019, Loss: 0.2621, Train: 94.50%, Valid: 91.56%, Test: 92.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1020, Loss: 0.2629, Train: 94.38%, Valid: 91.09%, Test: 92.69%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1021, Loss: 0.2631, Train: 94.36%, Valid: 91.24%, Test: 92.44%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1022, Loss: 0.2524, Train: 94.68%, Valid: 91.60%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1023, Loss: 0.2573, Train: 94.82%, Valid: 91.71%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1024, Loss: 0.2527, Train: 94.67%, Valid: 91.85%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1025, Loss: 0.2580, Train: 94.28%, Valid: 91.13%, Test: 92.55%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1026, Loss: 0.2598, Train: 93.87%, Valid: 90.98%, Test: 92.08%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1027, Loss: 0.2662, Train: 94.30%, Valid: 91.38%, Test: 92.37%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1028, Loss: 0.2629, Train: 94.62%, Valid: 91.67%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1029, Loss: 0.2550, Train: 94.98%, Valid: 91.64%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1030, Loss: 0.2505, Train: 94.81%, Valid: 91.45%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1031, Loss: 0.2597, Train: 94.70%, Valid: 91.27%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1032, Loss: 0.2601, Train: 94.74%, Valid: 91.45%, Test: 92.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1033, Loss: 0.2527, Train: 94.46%, Valid: 91.42%, Test: 92.44%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1034, Loss: 0.2593, Train: 94.72%, Valid: 91.71%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1035, Loss: 0.2485, Train: 94.49%, Valid: 91.64%, Test: 92.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1036, Loss: 0.2576, Train: 94.51%, Valid: 91.20%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1037, Loss: 0.2501, Train: 94.93%, Valid: 91.71%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1038, Loss: 0.2510, Train: 94.73%, Valid: 91.49%, Test: 92.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1039, Loss: 0.2447, Train: 94.57%, Valid: 91.31%, Test: 92.62%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1040, Loss: 0.2493, Train: 94.38%, Valid: 90.91%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1041, Loss: 0.2466, Train: 94.34%, Valid: 91.09%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1042, Loss: 0.2419, Train: 94.73%, Valid: 91.75%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1043, Loss: 0.2457, Train: 94.87%, Valid: 91.60%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1044, Loss: 0.2459, Train: 94.59%, Valid: 91.64%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1045, Loss: 0.2515, Train: 94.13%, Valid: 91.20%, Test: 92.29%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1046, Loss: 0.2559, Train: 94.67%, Valid: 91.38%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1047, Loss: 0.2414, Train: 95.10%, Valid: 91.78%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1048, Loss: 0.2504, Train: 95.19%, Valid: 91.82%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1049, Loss: 0.2442, Train: 95.16%, Valid: 91.71%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1050, Loss: 0.2419, Train: 94.80%, Valid: 91.38%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1051, Loss: 0.2290, Train: 94.69%, Valid: 91.27%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1052, Loss: 0.2518, Train: 95.06%, Valid: 91.53%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1053, Loss: 0.2356, Train: 95.10%, Valid: 91.60%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1054, Loss: 0.2280, Train: 95.08%, Valid: 91.78%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1055, Loss: 0.2419, Train: 95.13%, Valid: 91.85%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1056, Loss: 0.2286, Train: 94.67%, Valid: 91.42%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1057, Loss: 0.2315, Train: 94.63%, Valid: 91.42%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1058, Loss: 0.2516, Train: 95.32%, Valid: 92.15%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1059, Loss: 0.2355, Train: 95.39%, Valid: 91.78%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1060, Loss: 0.2491, Train: 95.38%, Valid: 91.93%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1061, Loss: 0.2388, Train: 94.87%, Valid: 91.45%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1062, Loss: 0.2420, Train: 94.63%, Valid: 91.35%, Test: 92.37%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1063, Loss: 0.2338, Train: 94.78%, Valid: 91.71%, Test: 92.51%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1064, Loss: 0.2326, Train: 95.10%, Valid: 91.64%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1065, Loss: 0.2293, Train: 95.04%, Valid: 91.35%, Test: 92.73%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1066, Loss: 0.2278, Train: 95.09%, Valid: 91.38%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1067, Loss: 0.2312, Train: 95.38%, Valid: 92.00%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1068, Loss: 0.2324, Train: 95.22%, Valid: 91.93%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1069, Loss: 0.2238, Train: 95.02%, Valid: 91.78%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1070, Loss: 0.2315, Train: 95.06%, Valid: 91.64%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1071, Loss: 0.2220, Train: 95.27%, Valid: 91.89%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1072, Loss: 0.2253, Train: 95.25%, Valid: 91.64%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1073, Loss: 0.2247, Train: 95.26%, Valid: 91.56%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1074, Loss: 0.2292, Train: 95.46%, Valid: 92.04%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1075, Loss: 0.2189, Train: 95.26%, Valid: 91.93%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1076, Loss: 0.2287, Train: 95.07%, Valid: 91.67%, Test: 92.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1077, Loss: 0.2266, Train: 94.79%, Valid: 91.20%, Test: 92.55%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1078, Loss: 0.2294, Train: 95.08%, Valid: 91.60%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1079, Loss: 0.2177, Train: 95.42%, Valid: 92.18%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1080, Loss: 0.2103, Train: 95.38%, Valid: 92.07%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1081, Loss: 0.2238, Train: 95.50%, Valid: 92.11%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1082, Loss: 0.2195, Train: 95.35%, Valid: 92.04%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1083, Loss: 0.2287, Train: 95.30%, Valid: 91.89%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1084, Loss: 0.2189, Train: 95.31%, Valid: 91.89%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1085, Loss: 0.2254, Train: 95.53%, Valid: 92.11%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1086, Loss: 0.2121, Train: 95.53%, Valid: 92.07%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1087, Loss: 0.2126, Train: 95.43%, Valid: 91.89%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1088, Loss: 0.2158, Train: 95.47%, Valid: 92.15%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1089, Loss: 0.2081, Train: 95.56%, Valid: 92.11%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1090, Loss: 0.2143, Train: 95.54%, Valid: 92.04%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1091, Loss: 0.2249, Train: 95.58%, Valid: 92.15%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1092, Loss: 0.2113, Train: 95.67%, Valid: 92.18%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1093, Loss: 0.2148, Train: 95.73%, Valid: 92.04%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1094, Loss: 0.2204, Train: 95.60%, Valid: 92.00%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1095, Loss: 0.2183, Train: 95.50%, Valid: 91.89%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1096, Loss: 0.2145, Train: 95.26%, Valid: 91.93%, Test: 92.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1097, Loss: 0.2068, Train: 95.27%, Valid: 92.04%, Test: 92.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1098, Loss: 0.2150, Train: 95.32%, Valid: 91.85%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1099, Loss: 0.1985, Train: 95.42%, Valid: 91.82%, Test: 92.80%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1100, Loss: 0.2152, Train: 95.50%, Valid: 92.00%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1101, Loss: 0.2181, Train: 95.44%, Valid: 91.82%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1102, Loss: 0.2043, Train: 95.49%, Valid: 91.82%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1103, Loss: 0.2083, Train: 95.20%, Valid: 91.60%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1104, Loss: 0.2088, Train: 95.10%, Valid: 91.42%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1105, Loss: 0.2120, Train: 95.22%, Valid: 91.78%, Test: 92.58%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1106, Loss: 0.2147, Train: 95.37%, Valid: 91.85%, Test: 92.77%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1107, Loss: 0.2160, Train: 95.66%, Valid: 92.04%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1108, Loss: 0.2031, Train: 95.58%, Valid: 91.67%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1109, Loss: 0.2115, Train: 95.77%, Valid: 91.78%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1110, Loss: 0.2101, Train: 95.83%, Valid: 92.00%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1111, Loss: 0.2062, Train: 95.56%, Valid: 92.04%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1112, Loss: 0.2053, Train: 95.65%, Valid: 92.04%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1113, Loss: 0.2064, Train: 95.69%, Valid: 92.15%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1114, Loss: 0.2001, Train: 95.92%, Valid: 92.22%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1115, Loss: 0.2046, Train: 95.76%, Valid: 92.00%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1116, Loss: 0.2008, Train: 95.59%, Valid: 91.89%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1117, Loss: 0.2076, Train: 95.60%, Valid: 92.00%, Test: 92.84%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1118, Loss: 0.2037, Train: 95.33%, Valid: 91.85%, Test: 92.73%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1119, Loss: 0.2188, Train: 95.58%, Valid: 92.04%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1120, Loss: 0.1995, Train: 95.84%, Valid: 92.07%, Test: 93.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1121, Loss: 0.1994, Train: 95.92%, Valid: 92.07%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1122, Loss: 0.1970, Train: 95.90%, Valid: 92.11%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1123, Loss: 0.2054, Train: 95.92%, Valid: 92.07%, Test: 92.91%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1124, Loss: 0.2029, Train: 95.72%, Valid: 92.15%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1125, Loss: 0.2011, Train: 95.66%, Valid: 92.04%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1126, Loss: 0.1970, Train: 95.62%, Valid: 92.15%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1127, Loss: 0.1990, Train: 95.65%, Valid: 92.25%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1128, Loss: 0.2038, Train: 95.86%, Valid: 92.29%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1129, Loss: 0.1971, Train: 95.92%, Valid: 92.00%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1130, Loss: 0.1961, Train: 95.90%, Valid: 91.89%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1131, Loss: 0.2055, Train: 95.92%, Valid: 91.96%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1132, Loss: 0.2027, Train: 95.87%, Valid: 92.18%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1133, Loss: 0.1977, Train: 95.87%, Valid: 92.18%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1134, Loss: 0.1981, Train: 95.88%, Valid: 92.00%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1135, Loss: 0.2007, Train: 96.00%, Valid: 92.25%, Test: 93.49%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1136, Loss: 0.1910, Train: 96.06%, Valid: 92.07%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1137, Loss: 0.1981, Train: 95.99%, Valid: 92.04%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1138, Loss: 0.2003, Train: 95.99%, Valid: 91.93%, Test: 92.88%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1139, Loss: 0.1874, Train: 95.82%, Valid: 92.04%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1140, Loss: 0.1887, Train: 95.78%, Valid: 92.00%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1141, Loss: 0.1953, Train: 95.84%, Valid: 92.25%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1142, Loss: 0.1968, Train: 95.88%, Valid: 92.33%, Test: 93.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1143, Loss: 0.1945, Train: 95.87%, Valid: 92.04%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1144, Loss: 0.1872, Train: 95.54%, Valid: 91.96%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1145, Loss: 0.1939, Train: 95.89%, Valid: 92.11%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1146, Loss: 0.1892, Train: 95.70%, Valid: 91.96%, Test: 93.02%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1147, Loss: 0.1975, Train: 95.78%, Valid: 92.18%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1148, Loss: 0.1955, Train: 95.31%, Valid: 91.64%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1149, Loss: 0.1938, Train: 95.38%, Valid: 91.53%, Test: 92.66%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1150, Loss: 0.1967, Train: 95.98%, Valid: 91.89%, Test: 93.28%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1151, Loss: 0.2058, Train: 96.00%, Valid: 92.25%, Test: 93.31%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1152, Loss: 0.1937, Train: 95.69%, Valid: 91.93%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1153, Loss: 0.1924, Train: 95.65%, Valid: 91.78%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1154, Loss: 0.1996, Train: 95.90%, Valid: 92.22%, Test: 93.20%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1155, Loss: 0.1868, Train: 96.10%, Valid: 92.07%, Test: 93.38%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1156, Loss: 0.1978, Train: 95.98%, Valid: 91.75%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1157, Loss: 0.1970, Train: 96.01%, Valid: 91.89%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1158, Loss: 0.1886, Train: 96.17%, Valid: 92.36%, Test: 93.46%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1159, Loss: 0.1915, Train: 95.92%, Valid: 92.15%, Test: 93.17%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1160, Loss: 0.1982, Train: 95.87%, Valid: 92.29%, Test: 93.35%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1161, Loss: 0.1888, Train: 95.96%, Valid: 92.15%, Test: 93.09%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1162, Loss: 0.1893, Train: 96.01%, Valid: 92.07%, Test: 93.06%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1163, Loss: 0.1840, Train: 95.83%, Valid: 91.67%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1164, Loss: 0.1878, Train: 95.86%, Valid: 91.78%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1165, Loss: 0.1846, Train: 96.07%, Valid: 92.33%, Test: 93.24%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1166, Loss: 0.1882, Train: 96.00%, Valid: 92.11%, Test: 93.42%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1167, Loss: 0.1945, Train: 96.04%, Valid: 91.96%, Test: 93.57%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1168, Loss: 0.1931, Train: 95.81%, Valid: 91.75%, Test: 93.13%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1169, Loss: 0.1916, Train: 95.66%, Valid: 91.64%, Test: 92.69%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1170, Loss: 0.1909, Train: 95.90%, Valid: 91.93%, Test: 92.95%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1171, Loss: 0.1864, Train: 95.87%, Valid: 92.15%, Test: 92.98%, Best Valid: 92.47%, Best Test: 93.75%
Epoch: 1172, Loss: 0.1838, Train: 95.99%, Valid: 92.55%, Test: 93.46%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1173, Loss: 0.1811, Train: 95.93%, Valid: 91.93%, Test: 93.71%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1174, Loss: 0.1924, Train: 95.88%, Valid: 91.85%, Test: 93.38%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1175, Loss: 0.1883, Train: 96.23%, Valid: 92.15%, Test: 93.17%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1176, Loss: 0.1829, Train: 95.99%, Valid: 92.11%, Test: 93.13%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1177, Loss: 0.1822, Train: 96.07%, Valid: 91.60%, Test: 93.06%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1178, Loss: 0.1870, Train: 96.11%, Valid: 91.71%, Test: 92.91%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1179, Loss: 0.1906, Train: 96.16%, Valid: 92.07%, Test: 93.46%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1180, Loss: 0.1748, Train: 95.94%, Valid: 92.15%, Test: 93.31%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1181, Loss: 0.1875, Train: 95.87%, Valid: 91.93%, Test: 93.28%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1182, Loss: 0.1890, Train: 96.19%, Valid: 91.78%, Test: 93.31%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1183, Loss: 0.1749, Train: 96.13%, Valid: 91.71%, Test: 93.06%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1184, Loss: 0.1806, Train: 96.04%, Valid: 91.64%, Test: 93.35%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1185, Loss: 0.1887, Train: 96.28%, Valid: 92.15%, Test: 93.28%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1186, Loss: 0.1839, Train: 96.07%, Valid: 91.96%, Test: 93.49%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1187, Loss: 0.1785, Train: 95.79%, Valid: 91.89%, Test: 93.46%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1188, Loss: 0.1848, Train: 95.86%, Valid: 91.96%, Test: 93.38%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1189, Loss: 0.1850, Train: 95.99%, Valid: 92.15%, Test: 93.46%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1190, Loss: 0.1942, Train: 96.18%, Valid: 92.07%, Test: 93.31%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1191, Loss: 0.1851, Train: 96.32%, Valid: 92.11%, Test: 93.17%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1192, Loss: 0.1888, Train: 96.18%, Valid: 91.78%, Test: 92.77%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1193, Loss: 0.1859, Train: 96.13%, Valid: 91.85%, Test: 92.98%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1194, Loss: 0.1791, Train: 96.21%, Valid: 92.29%, Test: 93.17%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1195, Loss: 0.1820, Train: 96.25%, Valid: 92.33%, Test: 93.38%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1196, Loss: 0.1925, Train: 96.34%, Valid: 92.36%, Test: 93.46%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1197, Loss: 0.1764, Train: 96.42%, Valid: 92.00%, Test: 93.28%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1198, Loss: 0.1810, Train: 96.18%, Valid: 91.82%, Test: 92.95%, Best Valid: 92.55%, Best Test: 93.46%
Epoch: 1199, Loss: 0.1777, Train: 96.10%, Valid: 91.82%, Test: 92.80%, Best Valid: 92.55%, Best Test: 93.46%
Run 01:
Highest Train: 96.63
Highest Valid: 92.55
Highest Test: 94.40
Chosen epoch: 1172
Final Train: 95.99
Final Test: 93.46
All runs:
Highest Train: 96.63 ± nan
Highest Test: 94.40 ± nan
Highest Valid: 92.55 ± nan
  Final Train: 95.99 ± nan
   Final Test: 93.46 ± nan
Saving results to results/amazon-computer/poly.csv
{"author_command_finished": "train-amazon-computer", "optimizer_steps": 1200}

```
### 诊断输出（stderr）
> 本阶段退出码为 0，执行成功；stderr 也可能包含提示或警告。
```
Downloading https://github.com/shchur/gnn-benchmark/raw/master/data/npz/amazon_electronics_computers.npz
Processing...
Done!
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:80: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  checkpoint = torch.load(model_path)
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:51: UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less than the reduction factor (input numel divided by output numel). (Triggered internally at C:\actions-runner\_work\pytorch\pytorch\builder\windows\pytorch\aten\src\ATen\native\ReduceOps.cpp:1823.)
  print(f'Highest Train: {r.mean():.2f} ± {r.std():.2f}')
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:53: UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less than the reduction factor (input numel divided by output numel). (Triggered internally at C:\actions-runner\_work\pytorch\pytorch\builder\windows\pytorch\aten\src\ATen\native\ReduceOps.cpp:1823.)
  print(f'Highest Test: {r.mean():.2f} ± {r.std():.2f}')
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:55: UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less than the reduction factor (input numel divided by output numel). (Triggered internally at C:\actions-runner\_work\pytorch\pytorch\builder\windows\pytorch\aten\src\ATen\native\ReduceOps.cpp:1823.)
  print(f'Highest Valid: {r.mean():.2f} ± {r.std():.2f}')
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:57: UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less than the reduction factor (input numel divided by output numel). (Triggered internally at C:\actions-runner\_work\pytorch\pytorch\builder\windows\pytorch\aten\src\ATen\native\ReduceOps.cpp:1823.)
  print(f'  Final Train: {r.mean():.2f} ± {r.std():.2f}')
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:59: UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less than the reduction factor (input numel divided by output numel). (Triggered internally at C:\actions-runner\_work\pytorch\pytorch\builder\windows\pytorch\aten\src\ATen\native\ReduceOps.cpp:1823.)
  print(f'   Final Test: {r.mean():.2f} ± {r.std():.2f}')
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_ea130e9fb6cc4e69842bfc48763ba705\repo\logger.py:94: UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less than the reduction factor (input numel divided by output numel). (Triggered internally at C:\actions-runner\_work\pytorch\pytorch\builder\windows\pytorch\aten\src\ATen\native\ReduceOps.cpp:1823.)
  f"{results.mean():.2f} $\pm$ {results.std():.2f} \n")

```

## 5. 运行结果
- **复现状态**: 作者仓库代码运行完成（未进行论文数值审核）
- **分析**: 无
- **判定原因**: 原作者命令已自然返回，实际训练更新和所属进程结束已核验；尚未判定论文数值复现。
- **作者命令结束记录**: train-amazon-computer；自然返回：是；实际优化器更新：1200
- **执行级别**: 原作者命令运行完成

### 原作者数据加载观测

以下记录核对原加载器及其输入文件，官方参考数据与完整训练协议尚未独立核对。

- **加载观测已核对**: computers；Amazon；框架 torch\_geometric.datasets ；观测 1 次
- **原生规模**: 节点 13752；边 491722；特征 767

| 输入文件 | 类型 | 字节数 | SHA-256 |
| --- | --- | --- | --- |
| data.pt | processed | 50170388 | f0978f97e76f0c34f5e824ebfc40acbc592d7e95b926325b124f1b01ec21362d |
| amazon\_electronics\_computers.npz | raw | 31921488 | 736ba1d9fd85eac2da83a5ad25c463f04b0031a6ca01563f90a7099d9e8ffb2c |


### 作者输出与论文宣称对比

论文指标配对未通过来源校验；保留实际指标，代码运行已完成。

本表使用作者程序输出，尚未独立复算。数值对比不影响代码完成状态。
实际输出中的指标保留在下方证据表；未将其他数据集或基线指标作为参考。
未完成原因：Reference standard deviation needs its exact PDF value quotation; Reference standard deviation needs its exact PDF value quotation


### 实际指标证据
| 指标 | 实测值 | 单位 | 数据划分 | 阶段 | 来源 |
|------|------|------|----------|------|------|
| loss | 0.1777 | 未标注 | 未标注 | 未标注 | train-amazon-computer:stdout:1237 |
| accuracy | 95.99 | 未标注 | train | train | train-amazon-computer:stdout:1249 |
| accuracy | 93.46 | 未标注 | test | final | train-amazon-computer:stdout:1250 |

## 6. 智能优化
- **优化状态**: 未触发(运行已冻结作者实验协议)

## 7. 运行与用量统计
- **总步骤数**: 31
- **成功步数**: 10
- **错误步数**: 0
- **执行时长**: 5905.89 秒
- **LLM 调用次数**: 6 （用于用量审计；全文阅读不设总调用预算）

---
*报告由 AutoReproducer 自动生成*

---

> 📎 **完整执行输出附件**: `Polynormer_Polynomial-Express_20261019_100146_execution.txt`（同一目录下，未被截断）
