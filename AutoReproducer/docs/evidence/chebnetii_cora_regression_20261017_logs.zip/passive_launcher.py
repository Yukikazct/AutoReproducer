"""Passive sidecar for the exact original ChebNetII Cora regression only."""
import hashlib,json,runpy,sys
from pathlib import Path
control=Path(sys.argv[1]).resolve(); workspace=control/'repo'
records={'splits':[],'runs':[]}
utils=str(workspace/'main/utils.py'); training=str(workspace/'main/training.py')
def tensor_hash(value):
 return hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
def profile(frame,event,result):
 if event!='return':return
 file=frame.f_code.co_filename.replace('\\','/').casefold()
 if file==utils.replace('\\','/').casefold() and frame.f_code.co_name=='random_splits_citation':
  data=result; masks={key:getattr(data,key) for key in ('train_mask','val_mask','test_mask')}
  records['splits'].append({'counts':{k:int(v.sum().item()) for k,v in masks.items()},
   'mask_sha256':{k:tensor_hash(v) for k,v in masks.items()},'nodes':int(data.num_nodes),
   'train_per_class':[int(((data.y==c)&masks['train_mask']).sum().item()) for c in range(7)],
   'disjoint':not bool(((masks['train_mask']&masks['val_mask'])|(masks['train_mask']&masks['test_mask'])|(masks['val_mask']&masks['test_mask'])).any()),
   'tensor_sha256':{k:tensor_hash(getattr(data,k)) for k in ('x','y','edge_index')}})
 elif file==training.replace('\\','/').casefold() and frame.f_code.co_name=='RunExp' and isinstance(result,tuple):
  args=vars(frame.f_locals['args']).copy()
  records['runs'].append({'seed':args['seed'],'arguments':args,'epochs_completed':len(result[3]),
   'test_accuracy':float(result[0]),'validation_accuracy':float(result[1])})
 else:return
 (control/'passive_observation.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
sys.argv=[str(workspace/'_autorepro_capture/observe_author.py'),'train_cora']
sys.path.insert(0,str(workspace/'_autorepro_capture'))
sys.setprofile(profile)
try:runpy.run_path(sys.argv[0],run_name='__main__')
finally:
 sys.setprofile(None)
 (control/'passive_observation.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
