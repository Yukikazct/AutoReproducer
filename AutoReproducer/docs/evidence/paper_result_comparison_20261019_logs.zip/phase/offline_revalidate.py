"""Revalidate preserved real model proposals without another API request."""
import argparse
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--product-root', type=Path, default=BASE / 'candidate')
parser.add_argument('--output', required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.product_root.resolve()))
from src.author_claim_comparison import _validated_rows
from src.holdout_registry import digest, product_hashes

files = product_hashes(args.product_root.resolve())
freeze = {'files': files, 'source_sha256': digest(files)}
cases = []
for tag in ('pyg_replay_04', 'polynormer_replay_05', 'pygsd_replay_05'):
    source = BASE / tag
    original = json.loads((source / 'result_before_report.json').read_text('utf-8'))
    meta = original['data']['analysis_replay']
    comparison = json.loads((source / 'author_claim_comparison.json').read_text('utf-8'))
    packet = json.loads((source / 'source_packet.json').read_text('utf-8'))
    accepted, citations, attempts = {}, {}, []
    for attempt in comparison['extraction_attempts']:
        if 'proposal' in attempt:
            errors = _validated_rows(attempt['proposal'], packet, Path(meta['original_run']) / 'repo',
                                     comparison['metric_records'], accepted, citations)
            attempts.append({'attempt': attempt['attempt'], 'validation_errors': errors})
    assert len(accepted) == len(comparison['comparisons'])
    previous = {row['actual']['id']: row for row in comparison['comparisons']}
    for identifier, row in accepted.items():
        old = previous[identifier]
        assert row['difference'] == old['difference']
        assert row['actual']['value'] == old['actual']['value']
        assert row['reference']['value'] == old['reference']['value']
        assert row['status'] == 'reference_only'
        assert row['reference']['column_evidence']['status'] == 'verified'
    cases.append({'case': tag, 'attempts': attempts, 'comparisons': list(accepted.values()),
                  'citations': list(citations.values())})
assert freeze['files'] == product_hashes(args.product_root.resolve())
report = {'evaluation_type': 'offline_revalidation_of_retained_real_api_proposals',
          'new_api_calls': 0, 'training_rerun': False, 'independent_acceptance': False,
          'candidate_product_sha256': freeze['source_sha256'], 'files': freeze['files'], 'cases': cases}
target = BASE / args.output
with target.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps({'cases': len(cases), 'product_sha256': freeze['source_sha256'],
                  'rows': sum(len(case['comparisons']) for case in cases),
                  'differences_unchanged': True, 'api_calls': 0, 'training_rerun': False}))
