# 论文复现与优化报告
<!-- autoreproducer-report-format: 2 -->

**生成时间**: 2026-10-19 21:06:13
**工具**: AutoReproducer v0.2.0

## 1. 论文信息
- **标题**: PyTorch Geometric Signed Directed: A Software Package on Graph Neural Networks for Signed and Directed Graphs
- **方法**: PyGSD：作为 PyTorch Geometric 扩展库的软件包，提供面向符号图与有向图的 GNN 层与完整模型、合成数据生成器、真实数据加载器、节点/边划分器，以及任务相关的损失函数与评测指标（链接预测、节点分类、节点聚类）。
- **数据集**: 
- **声明指标**: {}

- **论文全文阅读**: 完成；103815/103815 字符；1/1 批
- **阅读完成依据**: 连续覆盖全部提取文本，所有批次均返回有效结果；汇总笔记用于定位，实验判定引用原文。

## 2. 资源定位
- **代码仓库**: https://github.com/SherylHYX/pytorch_geometric_signed_directed
- **数据集**: 未找到
- **置信度**: 0.95
- **仓库关联证据**: 直接获取并运行所选仓库；不进行论文匹配审核。
- **发现来源**: pinned_git_direct_execution
- **执行范围**: 定位仓库是资源发现结果；是否运行仓库由下方执行对象和实际步骤确认。
- **PDF 仓库来源**: pdf_annotation，第 1 页
- **原文仓库链接**: https://github.com/SherylHYX/pytorch_geometric_signed_directed
- **证据类型**: repository_link
- **原文上下文**: well as task-specific evaluation metrics and loss functions for signed and directed networks. As an extension library for PyG, our proposed software is maintained with open-source releases, detailed documentation, continuous integration, unit tests and code coverage checks. The GitHub repository of the library is https: //github.com/SherylHYX/pytorch\_geometric\_signed\_directed .
- **来源 PDF SHA-256**: `3902ece975f46934320629ecdcf5b85c5bdd32a9f3bd9b864c3737bcba997fbc`
- **从论文中提取URL**: 10 个
  - https://github.com/alan-turing-institute/signet
  - https://www.researchgate.net/publication/346968575_The_Activity_
  - https://finance.yahoo.com/
  - http://www.cs.cmu.edu/afs/cs.cmu.edu/project/theo-11/www/wwkb/
  - https://github.com/benedekrozemberczki/SGCN

### 官方仓库实验来源
- **实验定义**: 依据本次 PDF 与固定作者源码生成的实验计划
- **论文版本/参考位置**: 
- **固定源码版本**: `2968b55b3378a01ade9f391e194f0077e2c6ee3b`
- **实验定义SHA-256**: `078675e58b4e5f506414202810c6861e24cf3ff2bd25d024aab60a3ad97fad49`
- **独立运行目录**: `D:\code\AutoReproducer\AutoReproducer\.tmp\comparison_20261019\pygsd_replay_06`
- **参数**: {}
- **真实数据SHA-256**: `806c640c1dbd1721d7af01609d02c66626011e5baf621632a3363a2d247e1bb2`
- **数据切分**: 由原文引用冻结的作者实验划分
- **协议说明**: 核验原作者完整命令的实际运行和进程结束；尚未验收论文数值。

- **作者协议来源**: 
- **实现版本说明**: 

### 本次 PDF 与作者源码确定的运行计划

- **运行范围**: 所选作者入口及其原始参数。
- **结束条件**: 全部所选命令正常返回、退出码为 0，所属进程已结束并清理。
- **运行结果**: 记录作者输出和实际训练更新；不进行论文、协议或数值审核。

**原始作者命令**

- train\_sgcn\_bitcoin\_alpha，目录：.
```json
["python", "examples/run_link_sign_prediction.py", "--dataset", "bitcoin_alpha", "--model", "SGCN"]
```

## 3. 环境配置
- **Python版本**: 3.12
- **依赖数**: 14
- **环境适配**: 基于作者依赖与源码导入选择的项目 CPU 兼容环境；不是论文原始运行环境的等价声明。

### 训练解释器尝试

- CPython 3.12：isolated\_existing

### 自动环境恢复

- **运行环境**: 使用兼容的标准 Python 运行预设
- **实际依赖检查**: 2/2 次通过（导入、版本与原生运算）
- **磁盘统计**: 未测量（安装与执行后读取实际大小，不展示模型估值）

### requirements.txt
```
--extra-index-url https://download.pytorch.org/whl/cpu
aiohttp==3.10.10
fsspec==2024.10.0
jinja2==3.1.6
networkx==2.8.8
numpy==1.26.4
psutil==6.1.0
pyparsing==3.2.0
requests==2.32.3
scikit-learn==1.5.2
scipy==1.14.1
torch==2.5.1+cpu
torch-geometric==2.6.1
tqdm==4.67.1

```

## 4. 代码执行
- **执行对象**: 固定版本作者仓库中的实验入口（多文件）
- **执行状态**: ✅ 成功
  - full: ✅ 通过 (退出码 0)

### 官方仓库执行命令

- **train_sgcn_bitcoin_alpha** · cwd: `D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_118a7298ddfc4a64a3778d46b4d72bb7\repo`
```json
["D:\\code\\AutoReproducer\\AutoReproducer\\.tmp\\pdf_selfrepair_20261019\\data\\training_python\\envs\\cpython-3.12\\Scripts\\python.exe", "-u", "_autorepro_capture/observe_author.py", "train_sgcn_bitcoin_alpha"]
```
- 完整日志: `D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_118a7298ddfc4a64a3778d46b4d72bb7\.autorepro_repository_runs\4d5591a122334b4f95b1cee0c26025fd\train_sgcn_bitcoin_alpha.stdout.log`

### 执行输出(full)
```
Namespace(dataset='bitcoin_alpha', epochs=500, lr=0.01, weight_decay=0.001, model='SGCN', seed=2021, in_dim=20, out_dim=20, eval_step=10, patience=10, runs=5)
SGCN(
  (conv1): SGCNConv(20, 10, first_aggr=True)
  (convs): ModuleList(
    (0): SGCNConv(10, 10, first_aggr=False)
  )
  (lsp_loss): Link_Sign_Entropy_Loss(
    (lin): Linear(in_features=40, out_features=3, bias=True)
  )
  (structure_loss): Sign_Structure_Loss()
)
Val Time: 0.251s, Epoch: 009, Loss: 1.1008, AUC: 0.8191, F1: 0.9673, MacroF1: 0.4901, MicroF1: 0.9368
Val Time: 0.195s, Epoch: 019, Loss: 1.0899, AUC: 0.8255, F1: 0.9673, MacroF1: 0.4901, MicroF1: 0.9368
Val Time: 0.196s, Epoch: 029, Loss: 1.0752, AUC: 0.8382, F1: 0.9689, MacroF1: 0.5654, MicroF1: 0.9401
Val Time: 0.193s, Epoch: 039, Loss: 1.0453, AUC: 0.8459, F1: 0.9707, MacroF1: 0.6348, MicroF1: 0.9438
Val Time: 0.191s, Epoch: 049, Loss: 1.0066, AUC: 0.8403, F1: 0.9704, MacroF1: 0.6511, MicroF1: 0.9434
Val Time: 0.190s, Epoch: 059, Loss: 0.9548, AUC: 0.8444, F1: 0.9704, MacroF1: 0.6511, MicroF1: 0.9434
Val Time: 0.197s, Epoch: 069, Loss: 0.9113, AUC: 0.8433, F1: 0.9702, MacroF1: 0.6502, MicroF1: 0.9430
Val Time: 0.224s, Epoch: 079, Loss: 0.8645, AUC: 0.8462, F1: 0.9693, MacroF1: 0.6466, MicroF1: 0.9413
Val Time: 0.236s, Epoch: 089, Loss: 0.8248, AUC: 0.8456, F1: 0.9700, MacroF1: 0.6525, MicroF1: 0.9425
Val Time: 0.198s, Epoch: 099, Loss: 0.7944, AUC: 0.8462, F1: 0.9706, MacroF1: 0.6705, MicroF1: 0.9438
Val Time: 0.213s, Epoch: 109, Loss: 0.7731, AUC: 0.8490, F1: 0.9706, MacroF1: 0.6705, MicroF1: 0.9438
Val Time: 0.214s, Epoch: 119, Loss: 0.7495, AUC: 0.8489, F1: 0.9712, MacroF1: 0.6792, MicroF1: 0.9450
Val Time: 0.202s, Epoch: 129, Loss: 0.7321, AUC: 0.8515, F1: 0.9708, MacroF1: 0.6772, MicroF1: 0.9442
Val Time: 0.241s, Epoch: 139, Loss: 0.7189, AUC: 0.8519, F1: 0.9706, MacroF1: 0.6762, MicroF1: 0.9438
Val Time: 0.227s, Epoch: 149, Loss: 0.7101, AUC: 0.8540, F1: 0.9710, MacroF1: 0.6809, MicroF1: 0.9446
Val Time: 0.231s, Epoch: 159, Loss: 0.6971, AUC: 0.8548, F1: 0.9712, MacroF1: 0.6819, MicroF1: 0.9450
Val Time: 0.218s, Epoch: 169, Loss: 0.6910, AUC: 0.8539, F1: 0.9714, MacroF1: 0.6802, MicroF1: 0.9454
Val Time: 0.224s, Epoch: 179, Loss: 0.6783, AUC: 0.8556, F1: 0.9703, MacroF1: 0.6752, MicroF1: 0.9434
Val Time: 0.278s, Epoch: 189, Loss: 0.6726, AUC: 0.8568, F1: 0.9712, MacroF1: 0.6792, MicroF1: 0.9450
Val Time: 0.241s, Epoch: 199, Loss: 0.6726, AUC: 0.8556, F1: 0.9704, MacroF1: 0.6695, MicroF1: 0.9434
Val Time: 0.196s, Epoch: 209, Loss: 0.6711, AUC: 0.8594, F1: 0.9705, MacroF1: 0.6790, MicroF1: 0.9438
Val Time: 0.175s, Epoch: 219, Loss: 0.6693, AUC: 0.8574, F1: 0.9703, MacroF1: 0.6724, MicroF1: 0.9434
Val Time: 0.201s, Epoch: 229, Loss: 0.6596, AUC: 0.8584, F1: 0.9708, MacroF1: 0.6743, MicroF1: 0.9442
Val Time: 0.209s, Epoch: 239, Loss: 0.6607, AUC: 0.8580, F1: 0.9706, MacroF1: 0.6705, MicroF1: 0.9438
Val Time: 0.229s, Epoch: 249, Loss: 0.6517, AUC: 0.8595, F1: 0.9712, MacroF1: 0.6792, MicroF1: 0.9450
Val Time: 0.230s, Epoch: 259, Loss: 0.6485, AUC: 0.8588, F1: 0.9708, MacroF1: 0.6772, MicroF1: 0.9442
Val Time: 0.209s, Epoch: 269, Loss: 0.6538, AUC: 0.8569, F1: 0.9712, MacroF1: 0.6763, MicroF1: 0.9450
Val Time: 0.206s, Epoch: 279, Loss: 0.6473, AUC: 0.8566, F1: 0.9712, MacroF1: 0.6763, MicroF1: 0.9450
Val Time: 0.204s, Epoch: 289, Loss: 0.6442, AUC: 0.8600, F1: 0.9719, MacroF1: 0.6822, MicroF1: 0.9463
Val Time: 0.232s, Epoch: 299, Loss: 0.6437, AUC: 0.8596, F1: 0.9714, MacroF1: 0.6830, MicroF1: 0.9454
Val Time: 0.226s, Epoch: 309, Loss: 0.6436, AUC: 0.8593, F1: 0.9712, MacroF1: 0.6763, MicroF1: 0.9450
Val Time: 0.205s, Epoch: 319, Loss: 0.6384, AUC: 0.8599, F1: 0.9712, MacroF1: 0.6819, MicroF1: 0.9450
Val Time: 0.203s, Epoch: 329, Loss: 0.6380, AUC: 0.8610, F1: 0.9712, MacroF1: 0.6763, MicroF1: 0.9450
Val Time: 0.166s, Epoch: 339, Loss: 0.6390, AUC: 0.8578, F1: 0.9714, MacroF1: 0.6830, MicroF1: 0.9454
Val Time: 0.200s, Epoch: 349, Loss: 0.6388, AUC: 0.8566, F1: 0.9719, MacroF1: 0.6850, MicroF1: 0.9463
Val Time: 0.203s, Epoch: 359, Loss: 0.6416, AUC: 0.8602, F1: 0.9712, MacroF1: 0.6819, MicroF1: 0.9450
Val Time: 0.197s, Epoch: 369, Loss: 0.6391, AUC: 0.8590, F1: 0.9717, MacroF1: 0.6840, MicroF1: 0.9458
Val Time: 0.208s, Epoch: 379, Loss: 0.6386, AUC: 0.8603, F1: 0.9717, MacroF1: 0.6840, MicroF1: 0.9458
Val Time: 0.155s, Epoch: 389, Loss: 0.6337, AUC: 0.8592, F1: 0.9714, MacroF1: 0.6830, MicroF1: 0.9454
Val Time: 0.197s, Epoch: 399, Loss: 0.6402, AUC: 0.8598, F1: 0.9719, MacroF1: 0.6850, MicroF1: 0.9463
Val Time: 0.160s, Epoch: 409, Loss: 0.6359, AUC: 0.8596, F1: 0.9719, MacroF1: 0.6850, MicroF1: 0.9463
Val Time: 0.200s, Epoch: 419, Loss: 0.6352, AUC: 0.8594, F1: 0.9710, MacroF1: 0.6782, MicroF1: 0.9446
Test Result: Epoch: 329, Loss: 0.6352, AUC: 0.8879, F1: 0.9710, MacroF1: 0.6809, MicroF1: 0.9446
Namespace(dataset='bitcoin_alpha', epochs=500, lr=0.01, weight_decay=0.001, model='SGCN', seed=2021, in_dim=20, out_dim=20, eval_step=10, patience=10, runs=5)
SGCN(
  (conv1): SGCNConv(20, 10, first_aggr=True)
  (convs): ModuleList(
    (0): SGCNConv(10, 10, first_aggr=False)
  )
  (lsp_loss): Link_Sign_Entropy_Loss(
    (lin): Linear(in_features=40, out_features=3, bias=True)
  )
  (structure_loss): Sign_Structure_Loss()
)
Val Time: 0.187s, Epoch: 009, Loss: 1.0986, AUC: 0.7727, F1: 0.9671, MacroF1: 0.4836, MicroF1: 0.9363
Val Time: 0.169s, Epoch: 019, Loss: 1.0890, AUC: 0.7975, F1: 0.9671, MacroF1: 0.4836, MicroF1: 0.9363
Val Time: 0.183s, Epoch: 029, Loss: 1.0701, AUC: 0.8151, F1: 0.9674, MacroF1: 0.5519, MicroF1: 0.9372
Val Time: 0.212s, Epoch: 039, Loss: 1.0303, AUC: 0.8223, F1: 0.9690, MacroF1: 0.6208, MicroF1: 0.9405
Val Time: 0.202s, Epoch: 049, Loss: 0.9699, AUC: 0.8313, F1: 0.9696, MacroF1: 0.6442, MicroF1: 0.9417
Val Time: 0.213s, Epoch: 059, Loss: 0.9146, AUC: 0.8320, F1: 0.9702, MacroF1: 0.6565, MicroF1: 0.9430
Val Time: 0.192s, Epoch: 069, Loss: 0.8596, AUC: 0.8396, F1: 0.9697, MacroF1: 0.6515, MicroF1: 0.9421
Val Time: 0.220s, Epoch: 079, Loss: 0.8170, AUC: 0.8382, F1: 0.9702, MacroF1: 0.6565, MicroF1: 0.9430
Val Time: 0.220s, Epoch: 089, Loss: 0.7923, AUC: 0.8391, F1: 0.9700, MacroF1: 0.6525, MicroF1: 0.9425
Val Time: 0.234s, Epoch: 099, Loss: 0.7687, AUC: 0.8403, F1: 0.9702, MacroF1: 0.6596, MicroF1: 0.9430
Val Time: 0.251s, Epoch: 109, Loss: 0.7392, AUC: 0.8398, F1: 0.9702, MacroF1: 0.6596, MicroF1: 0.9430
Val Time: 0.171s, Epoch: 119, Loss: 0.7271, AUC: 0.8389, F1: 0.9697, MacroF1: 0.6515, MicroF1: 0.9421
Val Time: 0.217s, Epoch: 129, Loss: 0.7150, AUC: 0.8379, F1: 0.9700, MacroF1: 0.6525, MicroF1: 0.9425
Val Time: 0.198s, Epoch: 139, Loss: 0.7104, AUC: 0.8363, F1: 0.9699, MacroF1: 0.6587, MicroF1: 0.9425
Val Time: 0.208s, Epoch: 149, Loss: 0.6943, AUC: 0.8351, F1: 0.9700, MacroF1: 0.6525, MicroF1: 0.9425
Val Time: 0.165s, Epoch: 159, Loss: 0.6857, AUC: 0.8330, F1: 0.9699, MacroF1: 0.6587, MicroF1: 0.9425
Val Time: 0.198s, Epoch: 169, Loss: 0.6740, AUC: 0.8345, F1: 0.9700, MacroF1: 0.6525, MicroF1: 0.9425
Val Time: 0.177s, Epoch: 179, Loss: 0.6755, AUC: 0.8356, F1: 0.9704, MacroF1: 0.6575, MicroF1: 0.9434
Val Time: 0.178s, Epoch: 189, Loss: 0.6675, AUC: 0.8359, F1: 0.9706, MacroF1: 0.6615, MicroF1: 0.9438
Test Result: Epoch: 099, Loss: 0.6675, AUC: 0.8683, F1: 0.9669, MacroF1: 0.6668, MicroF1: 0.9372
Namespace(dataset='bitcoin_alpha', epochs=500, lr=0.01, weight_decay=0.001, model='SGCN', seed=2021, in_dim=20, out_dim=20, eval_step=10, patience=10, runs=5)
SGCN(
  (conv1): SGCNConv(20, 10, first_aggr=True)
  (convs): ModuleList(
    (0): SGCNConv(10, 10, first_aggr=False)
  )
  (lsp_loss): Link_Sign_Entropy_Loss(
    (lin): Linear(in_features=40, out_features=3, bias=True)
  )
  (structure_loss): Sign_Structure_Loss()
)
Val Time: 0.188s, Epoch: 009, Loss: 1.0971, AUC: 0.7618, F1: 0.9671, MacroF1: 0.4836, MicroF1: 0.9363
Val Time: 0.184s, Epoch: 019, Loss: 1.0879, AUC: 0.7933, F1: 0.9673, MacroF1: 0.4901, MicroF1: 0.9368
Val Time: 0.184s, Epoch: 029, Loss: 1.0652, AUC: 0.8149, F1: 0.9681, MacroF1: 0.5484, MicroF1: 0.9384
Val Time: 0.102s, Epoch: 039, Loss: 1.0219, AUC: 0.8295, F1: 0.9683, MacroF1: 0.6111, MicroF1: 0.9392
Val Time: 0.105s, Epoch: 049, Loss: 0.9610, AUC: 0.8354, F1: 0.9695, MacroF1: 0.6474, MicroF1: 0.9417
Val Time: 0.113s, Epoch: 059, Loss: 0.9063, AUC: 0.8322, F1: 0.9710, MacroF1: 0.6695, MicroF1: 0.9446
Val Time: 0.120s, Epoch: 069, Loss: 0.8533, AUC: 0.8365, F1: 0.9719, MacroF1: 0.6822, MicroF1: 0.9463
Val Time: 0.107s, Epoch: 079, Loss: 0.8171, AUC: 0.8430, F1: 0.9717, MacroF1: 0.6812, MicroF1: 0.9458
Val Time: 0.113s, Epoch: 089, Loss: 0.7888, AUC: 0.8454, F1: 0.9712, MacroF1: 0.6792, MicroF1: 0.9450
Val Time: 0.103s, Epoch: 099, Loss: 0.7629, AUC: 0.8490, F1: 0.9710, MacroF1: 0.6837, MicroF1: 0.9446
Val Time: 0.100s, Epoch: 109, Loss: 0.7478, AUC: 0.8519, F1: 0.9710, MacroF1: 0.6809, MicroF1: 0.9446
Val Time: 0.103s, Epoch: 119, Loss: 0.7251, AUC: 0.8534, F1: 0.9710, MacroF1: 0.6782, MicroF1: 0.9446
Val Time: 0.107s, Epoch: 129, Loss: 0.7126, AUC: 0.8521, F1: 0.9714, MacroF1: 0.6884, MicroF1: 0.9454
Val Time: 0.107s, Epoch: 139, Loss: 0.7031, AUC: 0.8535, F1: 0.9716, MacroF1: 0.6894, MicroF1: 0.9458
Val Time: 0.110s, Epoch: 149, Loss: 0.6921, AUC: 0.8561, F1: 0.9718, MacroF1: 0.6957, MicroF1: 0.9463
Val Time: 0.115s, Epoch: 159, Loss: 0.6912, AUC: 0.8560, F1: 0.9712, MacroF1: 0.6847, MicroF1: 0.9450
Val Time: 0.108s, Epoch: 169, Loss: 0.6846, AUC: 0.8548, F1: 0.9716, MacroF1: 0.6921, MicroF1: 0.9458
Val Time: 0.115s, Epoch: 179, Loss: 0.6732, AUC: 0.8565, F1: 0.9707, MacroF1: 0.6854, MicroF1: 0.9442
Val Time: 0.115s, Epoch: 189, Loss: 0.6733, AUC: 0.8535, F1: 0.9712, MacroF1: 0.6874, MicroF1: 0.9450
Val Time: 0.119s, Epoch: 199, Loss: 0.6704, AUC: 0.8563, F1: 0.9712, MacroF1: 0.6874, MicroF1: 0.9450
Val Time: 0.114s, Epoch: 209, Loss: 0.6705, AUC: 0.8561, F1: 0.9710, MacroF1: 0.6864, MicroF1: 0.9446
Val Time: 0.102s, Epoch: 219, Loss: 0.6618, AUC: 0.8554, F1: 0.9705, MacroF1: 0.6817, MicroF1: 0.9438
Val Time: 0.116s, Epoch: 229, Loss: 0.6632, AUC: 0.8578, F1: 0.9712, MacroF1: 0.6874, MicroF1: 0.9450
Val Time: 0.107s, Epoch: 239, Loss: 0.6618, AUC: 0.8558, F1: 0.9703, MacroF1: 0.6780, MicroF1: 0.9434
Val Time: 0.113s, Epoch: 249, Loss: 0.6513, AUC: 0.8579, F1: 0.9709, MacroF1: 0.6890, MicroF1: 0.9446
Val Time: 0.133s, Epoch: 259, Loss: 0.6534, AUC: 0.8561, F1: 0.9705, MacroF1: 0.6790, MicroF1: 0.9438
Val Time: 0.112s, Epoch: 269, Loss: 0.6539, AUC: 0.8571, F1: 0.9705, MacroF1: 0.6817, MicroF1: 0.9438
Val Time: 0.112s, Epoch: 279, Loss: 0.6517, AUC: 0.8563, F1: 0.9707, MacroF1: 0.6854, MicroF1: 0.9442
Val Time: 0.105s, Epoch: 289, Loss: 0.6515, AUC: 0.8564, F1: 0.9699, MacroF1: 0.6788, MicroF1: 0.9425
Val Time: 0.105s, Epoch: 299, Loss: 0.6500, AUC: 0.8555, F1: 0.9705, MacroF1: 0.6817, MicroF1: 0.9438
Val Time: 0.108s, Epoch: 309, Loss: 0.6462, AUC: 0.8561, F1: 0.9705, MacroF1: 0.6844, MicroF1: 0.9438
Val Time: 0.115s, Epoch: 319, Loss: 0.6468, AUC: 0.8561, F1: 0.9703, MacroF1: 0.6860, MicroF1: 0.9434
Val Time: 0.109s, Epoch: 329, Loss: 0.6390, AUC: 0.8547, F1: 0.9712, MacroF1: 0.6900, MicroF1: 0.9450
Val Time: 0.109s, Epoch: 339, Loss: 0.6470, AUC: 0.8578, F1: 0.9705, MacroF1: 0.6844, MicroF1: 0.9438
Test Result: Epoch: 249, Loss: 0.6470, AUC: 0.8581, F1: 0.9703, MacroF1: 0.6807, MicroF1: 0.9434
Namespace(dataset='bitcoin_alpha', epochs=500, lr=0.01, weight_decay=0.001, model='SGCN', seed=2021, in_dim=20, out_dim=20, eval_step=10, patience=10, runs=5)
SGCN(
  (conv1): SGCNConv(20, 10, first_aggr=True)
  (convs): ModuleList(
    (0): SGCNConv(10, 10, first_aggr=False)
  )
  (lsp_loss): Link_Sign_Entropy_Loss(
    (lin): Linear(in_features=40, out_features=3, bias=True)
  )
  (structure_loss): Sign_Structure_Loss()
)
Val Time: 0.119s, Epoch: 009, Loss: 1.1013, AUC: 0.8449, F1: 0.9671, MacroF1: 0.4836, MicroF1: 0.9363
Val Time: 0.105s, Epoch: 019, Loss: 1.0893, AUC: 0.8627, F1: 0.9682, MacroF1: 0.5155, MicroF1: 0.9384
Val Time: 0.112s, Epoch: 029, Loss: 1.0721, AUC: 0.8670, F1: 0.9696, MacroF1: 0.5720, MicroF1: 0.9413
Val Time: 0.111s, Epoch: 039, Loss: 1.0384, AUC: 0.8697, F1: 0.9722, MacroF1: 0.6684, MicroF1: 0.9467
Val Time: 0.100s, Epoch: 049, Loss: 0.9818, AUC: 0.8733, F1: 0.9725, MacroF1: 0.7015, MicroF1: 0.9475
Val Time: 0.117s, Epoch: 059, Loss: 0.9278, AUC: 0.8804, F1: 0.9733, MacroF1: 0.7133, MicroF1: 0.9492
Val Time: 0.116s, Epoch: 069, Loss: 0.8766, AUC: 0.8820, F1: 0.9731, MacroF1: 0.7146, MicroF1: 0.9487
Val Time: 0.109s, Epoch: 079, Loss: 0.8451, AUC: 0.8797, F1: 0.9726, MacroF1: 0.7148, MicroF1: 0.9479
Val Time: 0.115s, Epoch: 089, Loss: 0.8083, AUC: 0.8807, F1: 0.9742, MacroF1: 0.7295, MicroF1: 0.9508
Val Time: 0.102s, Epoch: 099, Loss: 0.7820, AUC: 0.8820, F1: 0.9737, MacroF1: 0.7227, MicroF1: 0.9500
Val Time: 0.110s, Epoch: 109, Loss: 0.7629, AUC: 0.8822, F1: 0.9733, MacroF1: 0.7204, MicroF1: 0.9492
Val Time: 0.103s, Epoch: 119, Loss: 0.7482, AUC: 0.8813, F1: 0.9742, MacroF1: 0.7295, MicroF1: 0.9508
Val Time: 0.110s, Epoch: 129, Loss: 0.7350, AUC: 0.8831, F1: 0.9744, MacroF1: 0.7329, MicroF1: 0.9512
Val Time: 0.118s, Epoch: 139, Loss: 0.7196, AUC: 0.8839, F1: 0.9735, MacroF1: 0.7192, MicroF1: 0.9496
Val Time: 0.102s, Epoch: 149, Loss: 0.7118, AUC: 0.8813, F1: 0.9739, MacroF1: 0.7284, MicroF1: 0.9504
Val Time: 0.108s, Epoch: 159, Loss: 0.6990, AUC: 0.8845, F1: 0.9739, MacroF1: 0.7284, MicroF1: 0.9504
Val Time: 0.127s, Epoch: 169, Loss: 0.6905, AUC: 0.8878, F1: 0.9735, MacroF1: 0.7238, MicroF1: 0.9496
Val Time: 0.103s, Epoch: 179, Loss: 0.6824, AUC: 0.8872, F1: 0.9737, MacroF1: 0.7250, MicroF1: 0.9500
Val Time: 0.105s, Epoch: 189, Loss: 0.6810, AUC: 0.8877, F1: 0.9737, MacroF1: 0.7272, MicroF1: 0.9500
Val Time: 0.113s, Epoch: 199, Loss: 0.6755, AUC: 0.8888, F1: 0.9735, MacroF1: 0.7215, MicroF1: 0.9496
Val Time: 0.101s, Epoch: 209, Loss: 0.6699, AUC: 0.8881, F1: 0.9737, MacroF1: 0.7272, MicroF1: 0.9500
Val Time: 0.114s, Epoch: 219, Loss: 0.6673, AUC: 0.8902, F1: 0.9744, MacroF1: 0.7372, MicroF1: 0.9512
Val Time: 0.118s, Epoch: 229, Loss: 0.6687, AUC: 0.8905, F1: 0.9737, MacroF1: 0.7294, MicroF1: 0.9500
Val Time: 0.111s, Epoch: 239, Loss: 0.6599, AUC: 0.8897, F1: 0.9744, MacroF1: 0.7350, MicroF1: 0.9512
Val Time: 0.101s, Epoch: 249, Loss: 0.6580, AUC: 0.8893, F1: 0.9744, MacroF1: 0.7350, MicroF1: 0.9512
Val Time: 0.105s, Epoch: 259, Loss: 0.6565, AUC: 0.8906, F1: 0.9733, MacroF1: 0.7204, MicroF1: 0.9492
Val Time: 0.117s, Epoch: 269, Loss: 0.6637, AUC: 0.8905, F1: 0.9737, MacroF1: 0.7294, MicroF1: 0.9500
Val Time: 0.097s, Epoch: 279, Loss: 0.6569, AUC: 0.8894, F1: 0.9737, MacroF1: 0.7294, MicroF1: 0.9500
Val Time: 0.097s, Epoch: 289, Loss: 0.6541, AUC: 0.8905, F1: 0.9741, MacroF1: 0.7339, MicroF1: 0.9508
Val Time: 0.102s, Epoch: 299, Loss: 0.6557, AUC: 0.8903, F1: 0.9737, MacroF1: 0.7272, MicroF1: 0.9500
Val Time: 0.098s, Epoch: 309, Loss: 0.6539, AUC: 0.8893, F1: 0.9733, MacroF1: 0.7227, MicroF1: 0.9492
Val Time: 0.098s, Epoch: 319, Loss: 0.6544, AUC: 0.8923, F1: 0.9741, MacroF1: 0.7339, MicroF1: 0.9508
Val Time: 0.101s, Epoch: 329, Loss: 0.6526, AUC: 0.8909, F1: 0.9746, MacroF1: 0.7384, MicroF1: 0.9516
Val Time: 0.098s, Epoch: 339, Loss: 0.6489, AUC: 0.8911, F1: 0.9731, MacroF1: 0.7216, MicroF1: 0.9487
Val Time: 0.103s, Epoch: 349, Loss: 0.6511, AUC: 0.8910, F1: 0.9737, MacroF1: 0.7272, MicroF1: 0.9500
Val Time: 0.105s, Epoch: 359, Loss: 0.6483, AUC: 0.8924, F1: 0.9739, MacroF1: 0.7284, MicroF1: 0.9504
Val Time: 0.104s, Epoch: 369, Loss: 0.6511, AUC: 0.8919, F1: 0.9741, MacroF1: 0.7339, MicroF1: 0.9508
Val Time: 0.096s, Epoch: 379, Loss: 0.6459, AUC: 0.8918, F1: 0.9744, MacroF1: 0.7372, MicroF1: 0.9512
Val Time: 0.109s, Epoch: 389, Loss: 0.6479, AUC: 0.8914, F1: 0.9744, MacroF1: 0.7350, MicroF1: 0.9512
Val Time: 0.108s, Epoch: 399, Loss: 0.6470, AUC: 0.8900, F1: 0.9741, MacroF1: 0.7339, MicroF1: 0.9508
Val Time: 0.099s, Epoch: 409, Loss: 0.6413, AUC: 0.8924, F1: 0.9735, MacroF1: 0.7215, MicroF1: 0.9496
Val Time: 0.103s, Epoch: 419, Loss: 0.6453, AUC: 0.8915, F1: 0.9739, MacroF1: 0.7306, MicroF1: 0.9504
Val Time: 0.107s, Epoch: 429, Loss: 0.6485, AUC: 0.8903, F1: 0.9741, MacroF1: 0.7360, MicroF1: 0.9508
Val Time: 0.117s, Epoch: 439, Loss: 0.6450, AUC: 0.8909, F1: 0.9739, MacroF1: 0.7284, MicroF1: 0.9504
Val Time: 0.108s, Epoch: 449, Loss: 0.6451, AUC: 0.8915, F1: 0.9737, MacroF1: 0.7272, MicroF1: 0.9500
Test Result: Epoch: 359, Loss: 0.6451, AUC: 0.8753, F1: 0.9727, MacroF1: 0.7051, MicroF1: 0.9479
Namespace(dataset='bitcoin_alpha', epochs=500, lr=0.01, weight_decay=0.001, model='SGCN', seed=2021, in_dim=20, out_dim=20, eval_step=10, patience=10, runs=5)
SGCN(
  (conv1): SGCNConv(20, 10, first_aggr=True)
  (convs): ModuleList(
    (0): SGCNConv(10, 10, first_aggr=False)
  )
  (lsp_loss): Link_Sign_Entropy_Loss(
    (lin): Linear(in_features=40, out_features=3, bias=True)
  )
  (structure_loss): Sign_Structure_Loss()
)
Val Time: 0.101s, Epoch: 009, Loss: 1.0978, AUC: 0.7981, F1: 0.9671, MacroF1: 0.4836, MicroF1: 0.9363
Val Time: 0.107s, Epoch: 019, Loss: 1.0859, AUC: 0.8194, F1: 0.9679, MacroF1: 0.5093, MicroF1: 0.9380
Val Time: 0.101s, Epoch: 029, Loss: 1.0629, AUC: 0.8405, F1: 0.9699, MacroF1: 0.6086, MicroF1: 0.9421
Val Time: 0.100s, Epoch: 039, Loss: 1.0186, AUC: 0.8567, F1: 0.9732, MacroF1: 0.6885, MicroF1: 0.9487
Val Time: 0.099s, Epoch: 049, Loss: 0.9592, AUC: 0.8610, F1: 0.9744, MacroF1: 0.7261, MicroF1: 0.9512
Val Time: 0.111s, Epoch: 059, Loss: 0.9061, AUC: 0.8651, F1: 0.9746, MacroF1: 0.7318, MicroF1: 0.9516
Val Time: 0.116s, Epoch: 069, Loss: 0.8667, AUC: 0.8692, F1: 0.9733, MacroF1: 0.7181, MicroF1: 0.9492
Val Time: 0.104s, Epoch: 079, Loss: 0.8241, AUC: 0.8670, F1: 0.9740, MacroF1: 0.7167, MicroF1: 0.9504
Val Time: 0.104s, Epoch: 089, Loss: 0.7992, AUC: 0.8673, F1: 0.9735, MacroF1: 0.7169, MicroF1: 0.9496
Val Time: 0.105s, Epoch: 099, Loss: 0.7694, AUC: 0.8690, F1: 0.9740, MacroF1: 0.7215, MicroF1: 0.9504
Val Time: 0.106s, Epoch: 109, Loss: 0.7526, AUC: 0.8671, F1: 0.9746, MacroF1: 0.7273, MicroF1: 0.9516
Val Time: 0.108s, Epoch: 119, Loss: 0.7364, AUC: 0.8709, F1: 0.9735, MacroF1: 0.7215, MicroF1: 0.9496
Val Time: 0.107s, Epoch: 129, Loss: 0.7230, AUC: 0.8718, F1: 0.9739, MacroF1: 0.7284, MicroF1: 0.9504
Val Time: 0.113s, Epoch: 139, Loss: 0.7124, AUC: 0.8694, F1: 0.9735, MacroF1: 0.7169, MicroF1: 0.9496
Val Time: 0.107s, Epoch: 149, Loss: 0.6995, AUC: 0.8690, F1: 0.9738, MacroF1: 0.7204, MicroF1: 0.9500
Val Time: 0.101s, Epoch: 159, Loss: 0.6944, AUC: 0.8699, F1: 0.9740, MacroF1: 0.7191, MicroF1: 0.9504
Val Time: 0.101s, Epoch: 169, Loss: 0.6892, AUC: 0.8694, F1: 0.9737, MacroF1: 0.7227, MicroF1: 0.9500
Val Time: 0.106s, Epoch: 179, Loss: 0.6763, AUC: 0.8682, F1: 0.9735, MacroF1: 0.7192, MicroF1: 0.9496
Val Time: 0.109s, Epoch: 189, Loss: 0.6697, AUC: 0.8729, F1: 0.9746, MacroF1: 0.7318, MicroF1: 0.9516
Val Time: 0.106s, Epoch: 199, Loss: 0.6677, AUC: 0.8697, F1: 0.9744, MacroF1: 0.7307, MicroF1: 0.9512
Val Time: 0.115s, Epoch: 209, Loss: 0.6677, AUC: 0.8689, F1: 0.9742, MacroF1: 0.7250, MicroF1: 0.9508
Val Time: 0.111s, Epoch: 219, Loss: 0.6584, AUC: 0.8688, F1: 0.9738, MacroF1: 0.7180, MicroF1: 0.9500
Val Time: 0.107s, Epoch: 229, Loss: 0.6594, AUC: 0.8700, F1: 0.9733, MacroF1: 0.7157, MicroF1: 0.9492
Val Time: 0.109s, Epoch: 239, Loss: 0.6521, AUC: 0.8677, F1: 0.9742, MacroF1: 0.7250, MicroF1: 0.9508
Val Time: 0.108s, Epoch: 249, Loss: 0.6591, AUC: 0.8700, F1: 0.9740, MacroF1: 0.7215, MicroF1: 0.9504
Val Time: 0.102s, Epoch: 259, Loss: 0.6454, AUC: 0.8685, F1: 0.9740, MacroF1: 0.7261, MicroF1: 0.9504
Val Time: 0.106s, Epoch: 269, Loss: 0.6478, AUC: 0.8690, F1: 0.9744, MacroF1: 0.7307, MicroF1: 0.9512
Val Time: 0.100s, Epoch: 279, Loss: 0.6464, AUC: 0.8707, F1: 0.9742, MacroF1: 0.7273, MicroF1: 0.9508
Test Result: Epoch: 189, Loss: 0.6464, AUC: 0.8754, F1: 0.9702, MacroF1: 0.6961, MicroF1: 0.9434
SGCN: AUC: 0.8730 (0.0098) 
SGCN: F1: 0.9702 (0.0019) 
SGCN: MacroF1: 0.6859 (0.0133) 
SGCN: MicroF1: 0.9433 (0.0035) 
{"author_command_finished": "train_sgcn_bitcoin_alpha", "optimizer_steps": 1680}

```
### 诊断输出（stderr）
> 本阶段退出码为 0，执行成功；stderr 也可能包含提示或警告。
```
D:\code\AutoReproducer\AutoReproducer\.tmp\pdf_selfrepair_20261019\data\runs\repository_118a7298ddfc4a64a3778d46b4d72bb7\repo\torch_geometric_signed_directed\data\signed\SignedData.py:145: SyntaxWarning: invalid escape sequence '\m'
  :math:`\mathbf{A} <- \mathbf{D}^{-1/2} \mathbf{A}
Downloading https://github.com/SherylHYX/pytorch_geometric_signed_directed/raw/main/datasets/bitcoin_alpha.csv
Processing...
Done!

```

## 5. 运行结果
- **复现状态**: 作者仓库代码运行完成（已对比作者输出，尚未独立核验论文数值）
- **分析**: 无
- **判定原因**: 原作者命令已自然返回，实际训练更新和所属进程结束已核验；尚未判定论文数值复现。
- **作者命令结束记录**: train\_sgcn\_bitcoin\_alpha；自然返回：是；实际优化器更新：1680
- **执行级别**: 原作者命令运行完成

### 作者输出与论文宣称对比

已按作者输出与论文原文对比；这不替代独立复算或整篇论文验收。

本表使用作者程序输出，尚未独立复算。数值对比不影响代码完成状态。

| 指标 / 数据集 / 方法 | 论文宣称 | 作者运行输出 | 差值（实际 − 论文） | 结论 |
| --- | --- | --- | --- | --- |
| auc / Bitcoin-Alpha / SGCN | 87.5 ± 0.9%；均值，5 次 | 0.873 ± 0.0098（比例）；均值，5 次 | -0.2 个百分点；相对差异 -0.23% | 仅供参考，尚未验收 |
| f1\_macro / Bitcoin-Alpha / SGCN | 68.9 ± 0.9%；均值，5 次 | 0.6859 ± 0.0133（比例）；均值，5 次 | -0.31 个百分点；相对差异 -0.45% | 仅供参考，尚未验收 |

参考阈值为项目约定的 5% 相对误差，非论文提供的标准。

- **对比范围**: auc；论文划分 test / 实际划分 test
- **设置分析**: 所引设置相符；带引文的模型分析，不等于独立协议核验通过。
- **实验设置**: 论文与代码均为 Bitcoin-Alpha 上的 SGCN 链接符号预测，80% 训练/10% 验证/10% 测试边划分，5 次划分取均值与标准差；论文报告百分比，代码输出为分数（0.8730 对应 87.3%）。
- **实际来源**: train\_sgcn\_bitcoin\_alpha:stdout:229
- **论文列位置核验**: 已核验
- **已核验列路径**: Bitcoin-Alpha
- **列核验说明**: Complete same-page header and row identify one explicit value position
- **字段核对（论文）**: 单位：未知；划分：未知；统计方式：已核验；重复次数：未知
- **字段依据（论文：统计方式）**: pdf\_p25\_0；We run such train/validation/test splits five times to report the mean and standard deviation over the
- **字段核对（实际）**: 单位：已核验；划分：未知；统计方式：已核验；重复次数：未知
- **字段依据（实际：单位）**: repo\_16eb52a20da4\_0；auc\_score = metrics.roc\_auc\_score\(test\_y, pred\_p\[:, 1\]\)
- **字段依据（实际：统计方式）**: train\_sgcn\_bitcoin\_alpha:stdout:229；SGCN: AUC: 0.8730 \(0.0098\)
- **对比限制**: 论文单位尚无明确的对应原文证据
- **对比限制**: 论文划分尚无明确的对应原文证据
- **对比限制**: 论文重复次数尚无明确的对应原文证据
- **对比限制**: 实际划分尚无明确的对应原文证据
- **对比限制**: 实际重复次数尚无明确的对应原文证据
- **论文来源**: PDF 第 8、25 页
> SGCN \(87.5 ±0.9, 68.9 ±0.9\) \(88.8 ±0.7, 74.1 ±1.4\) \(84.7 ±0.4, 71.7 ±0.6\) \(79.8 ±0.2, 68.2 ±0.4\) \(87.5 ±0.4, 79.6 ±0.2\)
- **论文列标题**: Method Bitcoin-Alpha Bitcoin-OTC Wikirfa Slashdot Epinions
- **实际输出原文**: SGCN: AUC: 0.8730 \(0.0098\)

- **对比范围**: f1\_macro；论文划分 test / 实际划分 test
- **设置分析**: 所引设置相符；带引文的模型分析，不等于独立协议核验通过。
- **实验设置**: 论文与代码均为 Bitcoin-Alpha 上 SGCN 的 Macro-F1（macro 平均），5 次划分取均值与标准差；论文百分比与代码分数（0.6859 对应 68.59%）一致。
- **实际来源**: train\_sgcn\_bitcoin\_alpha:stdout:231
- **论文列位置核验**: 已核验
- **已核验列路径**: Bitcoin-Alpha
- **列核验说明**: Complete same-page header and row identify one explicit value position
- **字段核对（论文）**: 单位：已核验；划分：未知；统计方式：已核验；重复次数：未知
- **字段依据（论文：单位）**: pdf\_p8\_0；Macro-F1\) for signed networks \(%\).
- **字段依据（论文：统计方式）**: pdf\_p25\_0；We run such train/validation/test splits five times to report the mean and standard deviation over the
- **字段核对（实际）**: 单位：已核验；划分：未知；统计方式：已核验；重复次数：未知
- **字段依据（实际：单位）**: repo\_16eb52a20da4\_0；f1\_macro = metrics.f1\_score\(test\_y, pred, average='macro'\)
- **字段依据（实际：统计方式）**: train\_sgcn\_bitcoin\_alpha:stdout:231；SGCN: MacroF1: 0.6859 \(0.0133\)
- **对比限制**: 论文划分尚无明确的对应原文证据
- **对比限制**: 论文重复次数尚无明确的对应原文证据
- **对比限制**: 实际划分尚无明确的对应原文证据
- **对比限制**: 实际重复次数尚无明确的对应原文证据
- **论文来源**: PDF 第 8、25 页
> SGCN \(87.5 ±0.9, 68.9 ±0.9\) \(88.8 ±0.7, 74.1 ±1.4\) \(84.7 ±0.4, 71.7 ±0.6\) \(79.8 ±0.2, 68.2 ±0.4\) \(87.5 ±0.4, 79.6 ±0.2\)
- **论文列标题**: Method Bitcoin-Alpha Bitcoin-OTC Wikirfa Slashdot Epinions
- **实际输出原文**: SGCN: MacroF1: 0.6859 \(0.0133\)


### 实际指标证据
| 指标 | 实测值 | 单位 | 数据划分 | 阶段 | 来源 |
|------|------|------|----------|------|------|
| loss | 0.6464 | 未标注 | 未标注 | 未标注 | train\_sgcn\_bitcoin\_alpha:stdout:228 |
| auc | 0.873 ± 0.0098 | 未标注 | 未标注 | 未标注 | train\_sgcn\_bitcoin\_alpha:stdout:229 |
| f1\_score | 0.9702 ± 0.0019 | 未标注 | 未标注 | 未标注 | train\_sgcn\_bitcoin\_alpha:stdout:230 |
| f1\_macro | 0.6859 ± 0.0133 | 未标注 | 未标注 | 未标注 | train\_sgcn\_bitcoin\_alpha:stdout:231 |
| f1\_micro | 0.9433 ± 0.0035 | 未标注 | 未标注 | 未标注 | train\_sgcn\_bitcoin\_alpha:stdout:232 |

## 6. 智能优化
- **优化状态**: 未触发(运行已冻结作者实验协议)

## 7. 运行与用量统计
- **总步骤数**: 28
- **成功步数**: 10
- **错误步数**: 0
- **执行时长**: 317.45 秒
- **LLM 调用次数**: 6 （用于用量审计；全文阅读不设总调用预算）

---
*报告由 AutoReproducer 自动生成*

> 分析回归：复用已经完成的作者训练及同一 PDF 原始字节；未重新训练，不构成新论文独立验收。


---

> 📎 **完整执行输出附件**: `pygsd_replay_06_execution.txt`（同一目录下，未被截断）
