"""Read a saved trial through the real history UI without retraining it."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1] / "AutoReproducer"
sys.path.insert(0, str(ROOT))
from src.holdout_registry import verify_freeze
from playwright.sync_api import sync_playwright


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument("--port", type=int, default=8504)
    parser.add_argument("--require-frozen", action="store_true")
    args = parser.parse_args()
    runtime = ROOT / ".tmp/acceptance_pdf_browser_20261017/data/runtime"
    result = json.loads((runtime / (args.tag + "_full_result.json")).read_text("utf-8"))
    request = json.loads((runtime / (args.tag + "_request.json")).read_text("utf-8"))
    sid = result["session_id"]
    before = set(runtime.glob("progress_*.jsonl"))
    anchor = Path(result["report_path"])
    originals = [anchor, anchor.with_suffix(".result.json"),
                 Path(result["data"]["run_dir"]) / "result.json"]
    hashes = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}

    def frozen():
        if args.require_frozen:
            freeze = request["freeze"]
            return verify_freeze(ROOT, freeze, paper_id=freeze["paper"]["id"],
                                 pdf_sha256=request["pdf_sha256"],
                                 repository=freeze["paper"]["repository_url"], require_independent=True)
        return None

    eligibility = frozen()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel="chrome", headless=True)
        try:
            page = browser.new_page(accept_downloads=True, viewport={"width": 1440, "height": 1100})
            page.goto(f"http://localhost:{args.port}", wait_until="domcontentloaded")
            page.get_by_role("tab", name=re.compile("历史记录")).click()
            button = page.get_by_role("button", name="加载历史与存储", exact=True)
            if button.is_visible(timeout=3000):
                button.click()
            page.get_by_role("heading", name="历史复现会话", exact=True).wait_for(timeout=60000)
            row = page.get_by_test_id("stExpander").filter(has_text=sid)
            row.locator("summary").click()
            content = []
            for label, suffix in [("下载报告", ".md"), ("下载报告和图片（ZIP）", ".zip")]:
                with page.expect_download(timeout=30000) as received:
                    row.get_by_role("button", name=label, exact=True).click()
                output = runtime / (args.tag + "_history_downloaded_report" + suffix)
                received.value.save_as(str(output))
                content.append(output.read_bytes())
            expected = result["data"]["report"].replace("\r\n", "\n")
            assert content[0].decode("utf-8").replace("\r\n", "\n") == expected
            with zipfile.ZipFile(io.BytesIO(content[1])) as archive:
                assert archive.read(anchor.name) == content[0]
                attachment = anchor.with_name(anchor.stem + "_execution.txt")
                assert archive.read(attachment.name) == attachment.read_bytes()
            row.get_by_role("button", name="查看报告", exact=True).click()
            page.get_by_role("tab", name=re.compile("复现报告")).click()
            comparisons = (result["data"].get("validation") or {}).get("author_claim_comparison", {}).get("comparisons")
            table = None
            if comparisons:
                element = page.get_by_role("table").filter(has_text="论文宣称").filter(has_text="作者运行输出").first
                element.wait_for(timeout=30000)
                table = element.inner_text()
                assert "作者输出与论文宣称对比" in content[0].decode("utf-8")
            assert set(runtime.glob("progress_*.jsonl")) == before
            assert all(hashlib.sha256(p.read_bytes()).hexdigest() == digest for p, digest in hashes.items())
            frozen()
            page.screenshot(path=str(runtime / (args.tag + "_history_restored.png")), full_page=True)
            receipt = {"recorded_at": datetime.now(timezone.utc).isoformat(), "kind": "real_history_ui_restore",
                       "session_id": sid, "original_state": result["state"],
                       "product_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
                       "independent_claim": bool(args.require_frozen), "eligibility": eligibility,
                       "history_view_report": True, "comparison_table": table,
                       "markdown_matches_saved_result": True, "markdown_zip_identical": True,
                       "execution_attachment_identical": True, "no_new_task_created": True,
                       "original_result_and_report_unchanged": True}
            (runtime / (args.tag + "_history_acceptance.json")).write_text(
                json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
            print(json.dumps(receipt, ensure_ascii=False))
        finally:
            browser.close()


if __name__ == "__main__":
    main()
